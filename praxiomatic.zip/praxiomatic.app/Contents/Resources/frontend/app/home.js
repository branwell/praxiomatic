// Perspectives page (the home page): a tile for every perspective of every
// kind, in the user's order (new ones last), then a "+ New" card. It knows the
// kinds only through perspectiveLists, and the order from the registry
// (/api/perspectives). A tile opens on a single click, like a link (an
// exception to the Interaction Model's click-to-select, spec), and is dragged
// to reorder.

import { api } from "../shared/api.js";
import { openContextMenu } from "../shared/context-menu.js";
import { showError, clearError } from "../shared/ui.js";
import { perspectiveLists } from "./perspectives.js";

const tilesEl = document.getElementById("perspectives");

// The "+ New" card: a control, not a tile, always after the last tile.
const newCard = Object.assign(document.createElement("button"), {
  type: "button", className: "tile-new", textContent: "+ New",
});
newCard.setAttribute("aria-haspopup", "menu");

const menus = new WeakMap();

function renderTile(provider, item) {
  const tile = document.createElement("div");
  tile.className = "tile";
  tile.draggable = true;
  tile.dataset.id = item.id;
  tile.dataset.url = item.url;

  // The kind is shown by its icon alone; its name is the icon's label and tooltip.
  const kind = document.createElement("span");
  kind.className = "tile-kind";
  kind.setAttribute("role", "img");
  kind.setAttribute("aria-label", provider.kind);
  kind.title = provider.kind;
  kind.append(provider.icon("tile-icon"));

  const page = { remove: () => tile.remove(), showError };
  const custom = provider.tile?.(item, page);
  const title = document.createElement("div");
  title.className = "tile-title";
  if (custom) title.append(custom.title);
  else title.textContent = item.title;

  menus.set(tile, [{ label: "Open", action: () => openTile(tile) }, ...(custom?.menu ?? [])]);
  tile.append(title, kind);
  return tile;
}

function openTile(tile) {
  window.location.href = tile.dataset.url;
}

tilesEl.addEventListener("click", (event) => {
  const tile = event.target.closest(".tile");
  if (tile && !event.target.closest("input")) openTile(tile);
});
tilesEl.addEventListener("contextmenu", (event) => {
  const tile = event.target.closest(".tile");
  if (!tile || event.target.closest("input")) return;
  event.preventDefault();
  openContextMenu({ x: event.clientX, y: event.clientY, items: menus.get(tile) });
});

// While a tile's name is being edited it can't be dragged, so its text can be
// selected with the mouse.
tilesEl.addEventListener("focusin", (event) => {
  if (event.target.matches("input")) event.target.closest(".tile").draggable = false;
});
tilesEl.addEventListener("focusout", (event) => {
  if (event.target.matches("input")) event.target.closest(".tile").draggable = true;
});

// Each kind loads on its own, so one that fails still leaves the others listed.
// Tiles follow the registry's order; any it doesn't list go last.
async function loadTiles() {
  const [orderResult, ...results] = await Promise.allSettled([
    api("GET", "/api/perspectives"),
    ...perspectiveLists.map((provider) => provider.list()),
  ]);
  const entries = [];
  const failed = [];
  results.forEach((result, i) => {
    const provider = perspectiveLists[i];
    if (result.status === "fulfilled") {
      for (const item of result.value) entries.push({ provider, item });
    } else {
      failed.push(`${provider.kind}: ${result.reason.message}`);
    }
  });
  if (orderResult.status === "rejected") failed.push(`Order: ${orderResult.reason.message}`);
  const position = new Map((orderResult.value ?? []).map((p, i) => [p.id, i]));
  const at = (entry) => position.get(entry.item.id) ?? Infinity;
  entries.sort((a, b) => at(a) - at(b) || a.item.title.localeCompare(b.item.title));
  tilesEl.replaceChildren(...entries.map(({ provider, item }) => renderTile(provider, item)), newCard);
  if (failed.length > 0) showError(`Could not load some perspectives. ${failed.join(" ")}`);
}

// ---------------------------------------------------------------------------
// Reordering by drag and drop. A dashed placeholder shows where the tile will
// land, in reading order; dropping saves it there, and it goes back if saving
// fails. Dropping outside the tiles, or Escape, leaves it where it was.
// ---------------------------------------------------------------------------

const placeholder = document.createElement("div");
placeholder.className = "tile-placeholder";
placeholder.setAttribute("aria-hidden", "true");
let dragged = null;
let origin = null;

function tiles() {
  return [...tilesEl.querySelectorAll(".tile")];
}

// The first tile the pointer is before: on a row above it, or on its row and
// left of its middle.
function tileAfter(x, y) {
  return tiles().find((tile) => {
    if (tile === dragged) return false;
    const box = tile.getBoundingClientRect();
    return y < box.top || (y <= box.bottom && x < box.left + box.width / 2);
  }) ?? null;
}

tilesEl.addEventListener("dragstart", (event) => {
  const tile = event.target.closest?.(".tile");
  if (!tile) return;
  dragged = tile;
  origin = tile.nextElementSibling;
  event.dataTransfer.effectAllowed = "move";
  event.dataTransfer.setData("text/plain", tile.querySelector(".tile-title").textContent);
  // Change the page after the browser has captured the drag image.
  requestAnimationFrame(() => {
    if (dragged !== tile) return;
    tile.classList.add("dragging");
    if (!placeholder.isConnected) tilesEl.insertBefore(placeholder, origin);
  });
});

tilesEl.addEventListener("dragover", (event) => {
  if (!dragged) return;
  event.preventDefault();
  event.dataTransfer.dropEffect = "move";
  const next = tileAfter(event.clientX, event.clientY);
  // Past the last tile is still before the New card.
  const before = next ?? newCard;
  if (placeholder.nextElementSibling !== before || !placeholder.isConnected) tilesEl.insertBefore(placeholder, before);
});

tilesEl.addEventListener("drop", async (event) => {
  if (!dragged) return;
  event.preventDefault();
  const tile = dragged;
  const from = origin;
  placeholder.replaceWith(tile);
  resetDrag();
  if (tile.nextElementSibling === from) return;

  clearError();
  try {
    await api("POST", `/api/perspectives/${encodeURIComponent(tile.dataset.id)}/move`,
      { before_id: tile.nextElementSibling?.dataset.id ?? null });
  } catch (error) {
    tilesEl.insertBefore(tile, from);
    showError(`Could not move the perspective. ${error.message}`);
  }
});

// Fires after a drop, or when a drag is cancelled (e.g. dropped outside).
tilesEl.addEventListener("dragend", resetDrag);

function resetDrag() {
  placeholder.remove();
  dragged?.classList.remove("dragging");
  dragged = null;
  origin = null;
}

// ---------------------------------------------------------------------------
// New
// ---------------------------------------------------------------------------

async function create(provider) {
  clearError();
  newCard.disabled = true;
  try {
    window.location.href = await provider.create.run();
  } catch (error) {
    showError(`Could not create the ${provider.create.label}. ${error.message}`);
    newCard.disabled = false;
  }
}

newCard.addEventListener("click", () => {
  const rect = newCard.getBoundingClientRect();
  const items = perspectiveLists
    .filter((provider) => provider.create)
    .map((provider) => ({ label: provider.create.label, action: () => create(provider) }));
  openContextMenu({ x: rect.left, y: rect.bottom, items });
});

loadTiles();
