// The application's list of perspectives: the frontend's counterpart of
// backend/main.go, and the only frontend file that names them. Core
// (frontend/shared) knows no perspective, and perspectives don't know each
// other; a view offers what other perspectives can do through these lists.

import { graphPerspectiveList } from "../graph/perspective-list.js";
import { kanbanAddNodes } from "../kanban/add-nodes.js";
import { kanbanPerspectiveList } from "../kanban/perspective-list.js";
import { kanbanShowsNodes } from "../kanban/shows-nodes.js";

/**
 * A perspective that can show existing nodes, e.g. as Kanban cards. Views
 * list these in a node's right-click menu.
 * @typedef {object} AddNodes
 * @property {(count: number) => string} label The menu item for count nodes.
 * @property {(nodes: {id: string, title: string}[]) => Promise<void>} add
 *   Opens the perspective's own way of adding the nodes, and resolves once it
 *   is done or cancelled. Throws if it can't open (e.g. its data won't load).
 */

/** @type {AddNodes[]} */
export const addNodesTo = [kanbanAddNodes];

/**
 * A perspective that shows some of the nodes, e.g. as Kanban cards. Views can
 * highlight the nodes it shows.
 * @typedef {object} ShowsNodes
 * @property {string} name The perspective's name, e.g. "Kanban".
 * @property {() => Promise<string[]>} nodeIds The ids of the nodes it shows.
 *   Throws if they can't be loaded.
 */

/** @type {ShowsNodes[]} */
export const showsNodesIn = [kanbanShowsNodes];

/**
 * A kind of perspective, listed on the Perspectives page: its perspectives
 * (e.g. Kanban boards) are tiles there.
 * @typedef {object} PerspectiveList
 * @property {string} kind Its name, e.g. "Kanban board": its tiles' icon's
 *   tooltip and label.
 * @property {(className: string) => SVGSVGElement} icon Its tiles' icon.
 * @property {() => Promise<{id: string, title: string, url: string}[]>} list
 *   Its perspectives. Throws if they can't be loaded.
 * @property {{label: string, run: () => Promise<string>}} [create] An item in
 *   the page's New menu; run creates a perspective and resolves to its URL.
 * @property {(item: {id: string, title: string, url: string}, page: TilePage) => {title: HTMLElement, menu: import("../shared/context-menu.js").MenuItem[]}} [tile]
 *   A tile's title element (which may be renamable in place) and its menu
 *   items after Open. Without it, the title is plain text and Open is all.
 *
 * What the page offers a tile.
 * @typedef {object} TilePage
 * @property {() => void} remove Removes the tile, e.g. once deleted.
 * @property {(message: string) => void} showError Shows a page error.
 */

/** @type {PerspectiveList[]} */
export const perspectiveLists = [kanbanPerspectiveList, graphPerspectiveList];
