// Confirming before deleting nodes (spec: Interaction Model). Deleting a node
// also deletes its edges and everything perspectives show of it, such as
// Kanban cards, so the confirmation lists those effects. Core asks each
// perspective for its effects, so callers needn't know about the others.

import { api } from "./api.js";
import { confirmAction } from "./confirm.js";

/**
 * Asks before deleting nodes, listing what else will be deleted.
 * @param {object} options
 * @param {string[]} options.nodeIds
 * @param {string} options.title Dialog title, e.g. "Delete node".
 * @param {string} options.question e.g. 'Delete “Gamma”?'
 * @param {Object<string, number>} [options.alreadyCounted] Effects the question
 *   already covers, by singular name, e.g. { "Kanban card": 1 } when deleting
 *   a card; they're left out of the list.
 * @returns {Promise<boolean>} Whether the user confirmed.
 * @throws if the effects can't be loaded.
 */
export async function confirmNodeDelete({ nodeIds, title, question, alreadyCounted = {} }) {
  const query = nodeIds.map((id) => `id=${encodeURIComponent(id)}`).join("&");
  const { effects } = await api("GET", `/api/nodes/delete-effects?${query}`);
  const details = effects
    .map((e) => ({ ...e, count: e.count - (alreadyCounted[e.singular] ?? 0) }))
    .filter((e) => e.count > 0)
    .map((e) => `${e.count} ${e.count === 1 ? e.singular : e.plural} will also be deleted.`);
  return confirmAction({ title, message: `${question} This can't be undone.`, details });
}
