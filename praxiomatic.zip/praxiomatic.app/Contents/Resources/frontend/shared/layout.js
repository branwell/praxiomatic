// Places nodes that have no position yet with a short force-directed settle.
// Nodes that already have a position stay where they are and act as anchors;
// only new nodes move. Deterministic: the same graph settles the same way.

const IDEAL_DISTANCE = 200; // preferred distance between connected nodes
const GRAVITY = 1; // pull towards the centre, keeping unconnected nodes nearby
const ITERATIONS = 300;
const GOLDEN_ANGLE = Math.PI * (3 - Math.sqrt(5));

/**
 * Gives every node without a position (x == null) a position near its
 * neighbours and away from other nodes. Mutates the nodes.
 * @param {{id: string, x: number|null, y: number|null}[]} nodes
 * @param {{source_node_id: string, target_node_id: string}[]} edges
 * @returns {object[]} The nodes that were placed.
 */
export function placeNewNodes(nodes, edges) {
  const free = nodes.filter((n) => n.x == null || n.y == null);
  if (free.length === 0) return [];

  const byId = new Map(nodes.map((n) => [n.id, n]));
  const neighbours = new Map(nodes.map((n) => [n.id, []]));
  for (const e of edges) {
    const a = byId.get(e.source_node_id);
    const b = byId.get(e.target_node_id);
    if (!a || !b) continue;
    neighbours.get(a.id).push(b);
    neighbours.get(b.id).push(a);
  }

  // Start on a spiral around the placed nodes' centre (or the origin), so no
  // two new nodes start on top of each other.
  const placed = nodes.filter((n) => n.x != null && n.y != null);
  const centre = placed.length
    ? { x: average(placed, "x"), y: average(placed, "y") }
    : { x: 0, y: 0 };
  const startRadius = placed.length ? spread(placed, centre) + IDEAL_DISTANCE : 0;
  free.forEach((n, i) => {
    const r = startRadius + IDEAL_DISTANCE * Math.sqrt(i + 0.5);
    n.x = centre.x + r * Math.cos(i * GOLDEN_ANGLE);
    n.y = centre.y + r * Math.sin(i * GOLDEN_ANGLE);
  });

  // Fruchterman–Reingold, moving only the new nodes, with a cooling step size.
  const k = IDEAL_DISTANCE;
  for (let step = 0; step < ITERATIONS; step++) {
    const maxMove = k * (1 - step / ITERATIONS) * 0.5 + 1;
    for (const n of free) {
      let fx = 0;
      let fy = 0;
      for (const other of nodes) {
        if (other === n) continue;
        const [dx, dy, d] = offset(n, other);
        const push = (k * k) / d;
        fx += (dx / d) * push;
        fy += (dy / d) * push;
      }
      for (const other of neighbours.get(n.id)) {
        const [dx, dy, d] = offset(n, other);
        const pull = (d * d) / k;
        fx -= (dx / d) * pull;
        fy -= (dy / d) * pull;
      }
      fx -= (n.x - centre.x) * GRAVITY;
      fy -= (n.y - centre.y) * GRAVITY;

      const f = Math.hypot(fx, fy) || 1;
      const move = Math.min(f, maxMove);
      n.x += (fx / f) * move;
      n.y += (fy / f) * move;
    }
  }

  for (const n of free) {
    n.x = Math.round(n.x);
    n.y = Math.round(n.y);
  }
  return free;
}

// The vector from b to a and its length (never zero).
function offset(a, b) {
  let dx = a.x - b.x;
  let dy = a.y - b.y;
  if (dx === 0 && dy === 0) {
    dx = 0.1;
    dy = 0.1;
  }
  return [dx, dy, Math.hypot(dx, dy)];
}

function average(nodes, key) {
  return nodes.reduce((sum, n) => sum + n[key], 0) / nodes.length;
}

// How far the farthest node is from the centre.
function spread(nodes, centre) {
  return Math.max(...nodes.map((n) => Math.hypot(n.x - centre.x, n.y - centre.y)));
}
