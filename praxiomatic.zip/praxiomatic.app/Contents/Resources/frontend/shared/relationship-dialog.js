// Core relationship dialog: a modal window for editing an edge's own data. It
// shows the edge as source → relationship type → target (with — in place of →
// for a symmetric type), and edits its
// property values; created time is read-only. It knows nothing about
// perspectives: each chooses how to open it (Graph: double-click a
// relationship).
//
// Changes are saved only with Save (or Enter in a field). Cancel, Escape, or
// clicking outside the window close it without saving.

import { api } from "./api.js";
import { createPropertiesEditor } from "./properties.js";

// Built on first use and reused.
let ui = null;

// The edge being edited: { edgeId, onSaved }. Replaced on each open.
let current = null;

/**
 * Loads an edge and opens the dialog.
 * @param {string} edgeId
 * @param {(edge: object) => void} [onSaved] Called with the saved edge.
 * @throws if the edge can't be loaded (the dialog stays closed).
 */
export async function openRelationshipDialog(edgeId, onSaved = () => {}) {
  const edge = await api("GET", `/api/edges/${encodeURIComponent(edgeId)}`);
  const [source, target] = await Promise.all(
    [edge.source_node_id, edge.target_node_id].map((id) => api("GET", `/api/nodes/${encodeURIComponent(id)}`)),
  );
  ui ??= buildDialog();
  current = { edgeId, onSaved };
  ui.source.textContent = source.title;
  ui.type.textContent = edge.relationship_type_name;
  for (const link of ui.links) link.textContent = edge.is_symmetric ? " — " : " → ";
  ui.target.textContent = target.title;
  await ui.properties.load(edge.properties);
  ui.created.textContent = formatUTC(edge.created_utc);
  setError("");
  ui.save.disabled = false;
  ui.dialog.showModal();
  ui.properties.element.querySelector("input, button")?.focus();
}

function buildDialog() {
  const dialog = el("dialog", { className: "dialog", id: "relationship-dialog" });
  dialog.setAttribute("aria-labelledby", "relationship-dialog-title");

  const form = el("form", { className: "dialog-body", noValidate: true });
  const heading = el("h2", { className: "dialog-title", id: "relationship-dialog-title", textContent: "Edit relationship" });
  const error = el("p", { className: "alert alert--error", hidden: true });
  error.setAttribute("role", "alert");

  const source = el("span", { className: "relationship-node" });
  const type = el("span", { className: "relationship-type" });
  const target = el("span", { className: "relationship-node" });
  const links = [el("span"), el("span")];
  const summary = el("p", { className: "relationship-summary" }, [source, links[0], type, links[1], target]);
  const properties = createPropertiesEditor("edge", (message) => setError(message));
  const created = el("dd");

  const cancel = el("button", { type: "button", className: "btn btn--secondary", textContent: "Cancel" });
  const save = el("button", { type: "submit", className: "btn btn--primary", textContent: "Save" });

  form.append(
    heading,
    error,
    summary,
    properties.element,
    el("dl", { className: "details" }, [el("dt", { textContent: "Created (UTC)" }), created]),
    el("div", { className: "dialog-actions" }, [cancel, save]),
  );
  dialog.append(form);
  document.body.append(dialog);

  form.addEventListener("submit", async (event) => {
    event.preventDefault();
    if (!dialog.open || save.disabled) return;
    const changes = properties.changes();
    if (!Object.keys(changes).length) {
      dialog.close();
      return;
    }
    save.disabled = true;
    setError("");
    const editing = current;
    try {
      const edge = await api("PATCH", `/api/edges/${encodeURIComponent(editing.edgeId)}`, { properties: changes });
      editing.onSaved(edge);
      dialog.close();
    } catch (err) {
      // Keep the window open with the user's edits so nothing is lost.
      setError(`Could not save the relationship. ${err.message}`);
    } finally {
      save.disabled = false;
    }
  });

  cancel.addEventListener("click", () => dialog.close());

  // Clicking the backdrop closes the dialog, as in the node dialog: the press
  // must also have started on the backdrop, not in a text selection.
  let pressedOnBackdrop = false;
  dialog.addEventListener("pointerdown", (event) => {
    pressedOnBackdrop = event.target === dialog;
  });
  dialog.addEventListener("click", (event) => {
    if (event.target === dialog && pressedOnBackdrop) dialog.close();
    pressedOnBackdrop = false;
  });

  return { dialog, source, type, target, links, properties, created, error, save };
}

function el(tag, props = {}, children = []) {
  const node = Object.assign(document.createElement(tag), props);
  node.append(...children);
  return node;
}

function setError(message) {
  ui.error.textContent = message;
  ui.error.hidden = !message;
}

// "2026-10-19T02:57:31.619Z" -> "2026-10-19 02:57:31"
function formatUTC(value) {
  return value.replace("T", " ").replace(/\.\d+Z$|Z$/, "");
}
