// Core relationship panel: edits an edge's own data in place, in a panel a
// perspective keeps on its page (Graph: the details panel), instead of in the
// modal relationship dialog. It shows the edge as source → relationship type →
// target (with — in place of → for a symmetric type), its property values, and
// its created time. It knows nothing about
// perspectives.
//
// A property value is saved as it's committed, with no Save button: when its
// field is left or on Enter, or at once when cleared with ×. Escape in a field
// puts back its saved value. If a save fails, the saved values come back and
// an error is shown.

import { api } from "./api.js";
import { createPropertiesEditor } from "./properties.js";

/**
 * Builds a relationship panel, hidden until an edge is shown.
 * @param {object} options
 * @param {(message: string) => void} options.onError Shows an error about an
 *   edge the panel no longer shows.
 * @returns {{
 *   element: HTMLElement,
 *   show: (edgeId: string) => Promise<void>,
 *   clear: () => void,
 *   focus: () => Promise<void>,
 *   flush: () => void,
 * }}
 *   As the node panel's (node-panel.js); focus puts the cursor in the first
 *   property value, or on "+ Add property".
 */
export function createRelationshipPanel({ onError }) {
  // The edge shown: { edgeId, edge }; edge is as last loaded or saved, and
  // null until loaded. Replaced on each show.
  let current = null;
  // Loads run one after another, so an earlier one can't overwrite a later.
  let loaded = Promise.resolve();
  // Saves in progress; a load waits for them, so it shows what they saved.
  const saving = new Set();

  const ui = build();

  function show(edgeId) {
    flush();
    const editing = { edgeId, edge: null };
    current = editing;
    ui.element.hidden = false;
    ui.fields.hidden = true;
    setError("");
    loaded = loaded.then(() => load(editing));
    return loaded;
  }

  function clear() {
    flush();
    current = null;
    ui.element.hidden = true;
  }

  async function focus() {
    await loaded;
    if (current?.edge) ui.properties.element.querySelector("input:not(:disabled), button")?.focus();
  }

  async function load(editing) {
    await Promise.allSettled([...saving]);
    if (editing !== current) return;
    let source, target;
    try {
      const edge = await api("GET", edgePath(editing.edgeId));
      [source, target] = await Promise.all(
        [edge.source_node_id, edge.target_node_id].map((id) => api("GET", `/api/nodes/${encodeURIComponent(id)}`)),
      );
      if (editing !== current) return;
      await ui.properties.load(edge.properties);
      if (editing !== current) return;
      editing.edge = edge;
    } catch (err) {
      if (editing === current) setError(`Could not load the relationship. ${err.message}`);
      return;
    }
    ui.source.textContent = source.title;
    ui.type.textContent = editing.edge.relationship_type_name;
    for (const link of ui.links) link.textContent = editing.edge.is_symmetric ? " — " : " → ";
    ui.target.textContent = target.title;
    ui.created.textContent = formatUTC(editing.edge.created_utc);
    ui.fields.hidden = false;
  }

  function flush() {
    const editing = current;
    if (!editing?.edge) return;
    const changes = ui.properties.changes();
    if (!Object.keys(changes).length) return;
    const promise = (async () => {
      try {
        editing.edge = await api("PATCH", edgePath(editing.edgeId), { properties: changes });
      } catch (err) {
        if (editing === current) {
          ui.properties.load(editing.edge.properties).catch((e) => setError(`Could not load the properties. ${e.message}`));
          setError(`Could not save the relationship. ${err.message}`);
        } else {
          onError(`Could not save the relationship. ${err.message}`);
        }
        return;
      }
      if (editing === current) {
        ui.properties.markSaved(changes);
        setError("");
      }
    })();
    saving.add(promise);
    promise.finally(() => saving.delete(promise));
  }

  function setError(message) {
    ui.error.textContent = message;
    ui.error.hidden = !message;
  }

  function build() {
    const error = el("p", { className: "alert alert--error", hidden: true });
    error.setAttribute("role", "alert");
    const source = el("span", { className: "relationship-node" });
    const type = el("span", { className: "relationship-type" });
    const target = el("span", { className: "relationship-node" });
    const links = [el("span"), el("span")];
    const properties = createPropertiesEditor("edge", setError, { onCommit: () => flush(), removeTitle: "Clear" });
    const created = el("dd");
    const fields = el("div", { className: "details-panel-fields", hidden: true }, [
      el("p", { className: "relationship-summary" }, [source, links[0], type, links[1], target]),
      properties.element,
      el("dl", { className: "details" }, [el("dt", { textContent: "Created (UTC)" }), created]),
    ]);
    const element = el("div", { className: "details-panel-body", hidden: true }, [error, fields]);
    return { element, fields, error, source, type, target, links, properties, created };
  }

  return { element: ui.element, show, clear, focus, flush };
}

const edgePath = (id) => `/api/edges/${encodeURIComponent(id)}`;

function el(tag, props = {}, children = []) {
  const node = Object.assign(document.createElement(tag), props);
  node.append(...children);
  return node;
}

// "2026-10-19T02:57:31.619Z" -> "2026-10-19 02:57:31"
function formatUTC(value) {
  return value.replace("T", " ").replace(/\.\d+Z$|Z$/, "");
}
