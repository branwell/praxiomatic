// Small wrapper around fetch() for the JSON API.

/**
 * Sends a request to the API and returns the decoded JSON response.
 * Throws an Error with a readable message on network failure or a non-OK status.
 * @param {string} method HTTP method, e.g. "GET".
 * @param {string} path Root-relative API path, e.g. "/api/kanban/boards".
 * @param {object|FormData} [body] Request body, sent as JSON; FormData (e.g. an
 *   uploaded image) is sent as multipart/form-data.
 */
export async function api(method, path, body) {
  const options = { method, headers: {} };
  if (body instanceof FormData) {
    options.body = body; // fetch sets the multipart Content-Type and boundary
  } else if (body !== undefined) {
    options.headers["Content-Type"] = "application/json";
    options.body = JSON.stringify(body);
  }

  let response;
  try {
    response = await fetch(path, options);
  } catch {
    throw new Error("Could not reach the server. Is it running?");
  }

  const text = await response.text();
  let data = null;
  if (text) {
    try {
      data = JSON.parse(text);
    } catch {
      // Not JSON; fall through to the status-based message below.
    }
  }

  if (!response.ok) {
    const error = new Error(data?.error ?? `Request failed (${response.status})`);
    error.status = response.status;
    throw error;
  }
  return data;
}
