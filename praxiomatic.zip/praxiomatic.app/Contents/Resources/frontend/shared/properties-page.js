// Property definitions page: every definition, with how many nodes and edges
// have a value for it. Names are renamed by double-clicking them (or Rename in
// their right-click menu); data type, where a property can be set, and
// description save as they change. Each change shows immediately; if saving
// fails, the old value returns with a message. Definitions have no order, so
// they are listed by name.

import { api } from "./api.js";
import { openContextMenu } from "./context-menu.js";
import { showError, clearError } from "./ui.js";

const MAX_NAME_LENGTH = 64;
const TYPES = ["text", "date", "integer", "decimal", "boolean", "url"];

const rows = document.getElementById("property-rows");
const addForm = document.getElementById("property-add");
const addName = document.getElementById("property-add-name");
const addType = document.getElementById("property-add-type");
const addNodes = document.getElementById("property-add-nodes");
const addEdges = document.getElementById("property-add-edges");

let definitions = [];

async function load() {
  try {
    definitions = await api("GET", "/api/property-definitions");
    render();
  } catch (error) {
    showError(`Could not load the properties. ${error.message}`);
  }
}

function render() {
  definitions.sort((a, b) => a.property_name.localeCompare(b.property_name, undefined, { sensitivity: "base" }));
  if (!definitions.length) {
    const cell = el("td", { className: "empty-state", colSpan: 6, textContent: "No properties yet." });
    rows.replaceChildren(el("tr", {}, [cell]));
    return;
  }
  rows.replaceChildren(...definitions.map(row));
}

function row(d) {
  const name = el("span", { className: "property-name", textContent: d.property_name, title: "Double-click to rename" });
  name.addEventListener("dblclick", () => rename(d, name));
  name.addEventListener("contextmenu", (event) => {
    event.preventDefault();
    openContextMenu({ x: event.clientX, y: event.clientY, items: [{ label: "Rename", action: () => rename(d, name) }] });
  });

  // A timestamp is set by the system, and its type can't change.
  const type =
    d.data_type === "timestamp"
      ? el("span", { className: "muted", textContent: "timestamp", title: "Set by the system; read-only, and its type can't change" })
      : el("select", { className: "input" }, TYPES.map((t) => el("option", { value: t, textContent: t })));
  if (type.tagName === "SELECT") {
    type.value = d.data_type;
    type.setAttribute("aria-label", `${d.property_name} data type`);
    type.addEventListener("change", () => save(d, { data_type: type.value }, () => (type.value = d.data_type)));
  }

  const nodes = flag(d, "allowed_on_nodes", `${d.property_name} allowed on nodes`);
  const edges = flag(d, "allowed_on_edges", `${d.property_name} allowed on relationships`);

  const description = el("input", { className: "input property-description", type: "text", maxLength: 1024, value: d.description, autocomplete: "off" });
  description.setAttribute("aria-label", `${d.property_name} description`);
  description.addEventListener("keydown", (event) => {
    if (event.key === "Enter") description.blur();
    if (event.key === "Escape") {
      description.value = d.description;
      description.blur();
    }
  });
  description.addEventListener("change", () =>
    save(d, { description: description.value }, () => (description.value = d.description)),
  );

  return el("tr", {}, [
    el("td", {}, [name]),
    el("td", {}, [type]),
    el("td", {}, [nodes]),
    el("td", {}, [edges]),
    el("td", {}, [description]),
    el("td", { className: "num", textContent: usedBy(d) }),
  ]);
}

function flag(d, field, label) {
  const box = el("input", { type: "checkbox", checked: d[field] });
  box.setAttribute("aria-label", label);
  box.addEventListener("change", () => save(d, { [field]: box.checked }, () => (box.checked = d[field])));
  return box;
}

function usedBy(d) {
  const parts = [];
  if (d.node_value_count) parts.push(`${d.node_value_count} ${d.node_value_count === 1 ? "node" : "nodes"}`);
  if (d.edge_value_count) parts.push(`${d.edge_value_count} ${d.edge_value_count === 1 ? "relationship" : "relationships"}`);
  return parts.join(", ") || "—";
}

// Saves a change to a definition. The control already shows it; on failure,
// revert puts the old value back.
async function save(d, change, revert) {
  clearError();
  try {
    const saved = await api("PATCH", `/api/property-definitions/${encodeURIComponent(d.id)}`, change);
    Object.assign(d, saved);
    if ("property_name" in change || "description" in change) render();
  } catch (error) {
    revert();
    showError(`Could not save ${d.property_name}. ${error.message}`);
  }
}

// Swaps the name for a text box: Enter or leaving the box saves, Escape cancels.
function rename(d, name) {
  if (!name.isConnected) return;
  const input = el("input", { className: "input", type: "text", value: d.property_name, maxLength: MAX_NAME_LENGTH });
  input.setAttribute("aria-label", "Property name");
  name.replaceWith(input);
  input.focus();
  input.select();
  let done = false;
  const finish = async (keep) => {
    if (done) return;
    done = true;
    const value = input.value.replace(/\s+/g, " ").trim();
    input.replaceWith(name);
    if (!keep || value === d.property_name) return;
    if (!value) {
      showError("A property needs a name.");
      return;
    }
    const old = d.property_name;
    name.textContent = value;
    await save(d, { property_name: value }, () => (name.textContent = old));
  };
  input.addEventListener("keydown", (event) => {
    if (event.key === "Enter") finish(true);
    if (event.key === "Escape") finish(false);
  });
  input.addEventListener("blur", () => finish(true));
}

addForm.addEventListener("submit", async (event) => {
  event.preventDefault();
  clearError();
  const name = addName.value.replace(/\s+/g, " ").trim();
  if (!name) {
    showError("A property needs a name.");
    addName.focus();
    return;
  }
  try {
    const created = await api("POST", "/api/property-definitions", {
      property_name: name,
      data_type: addType.value,
      allowed_on_nodes: addNodes.checked,
      allowed_on_edges: addEdges.checked,
    });
    definitions.push(created);
    render();
    addName.value = "";
    addName.focus();
  } catch (error) {
    showError(`Could not add the property. ${error.message}`);
  }
});

function el(tag, props = {}, children = []) {
  const node = Object.assign(document.createElement(tag), props);
  node.append(...children);
  return node;
}

load();
