// Shortcuts that act on the selection (spec: Interaction Model): Delete or
// Backspace removes it, Escape clears it. Keys pass through while typing in a
// field, or while a dialog or menu is open.

import { isContextMenuOpen } from "./context-menu.js";

/**
 * Whether a key press should be left alone by shortcuts: it was already
 * handled, a menu or dialog is open, or it's typed into a field.
 * @param {KeyboardEvent} event
 */
export function isShortcutBlocked(event) {
  if (event.defaultPrevented || isContextMenuOpen() || document.querySelector("dialog[open]")) return true;
  return Boolean(event.target.closest?.("input, textarea, select, [contenteditable]"));
}

/**
 * @param {object} handlers Each is optional; a key with no handler does nothing.
 * @param {() => void} [handlers.remove]
 * @param {() => void} [handlers.clear]
 */
export function onSelectionKeys({ remove, clear }) {
  document.addEventListener("keydown", (event) => {
    if (isShortcutBlocked(event)) return;

    let handler = null;
    if (event.key === "Delete" || event.key === "Backspace") handler = remove;
    else if (event.key === "Escape") handler = clear;
    if (!handler) return;
    event.preventDefault();
    handler();
  });
}
