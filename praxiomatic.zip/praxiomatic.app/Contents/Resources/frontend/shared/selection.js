// Selection of objects on a page (spec: Interaction Model).
//
// Click selects one object, replacing the selection; ⌘+click (Mac) or
// Ctrl+click elsewhere adds or removes one. The selection can hold objects of
// different kinds (each object's data-kind); actions pick out the kinds they
// apply to. Selected objects get the is-selected class and
// aria-selected="true", for HTML and SVG elements alike.

const IS_MAC = /mac/i.test(navigator.userAgentData?.platform ?? navigator.platform ?? "");

/** Whether a click adds to the selection: ⌘ on a Mac, Ctrl elsewhere. */
export function isAdditive(event) {
  return IS_MAC ? event.metaKey : event.ctrlKey;
}

/**
 * @param {object} [options]
 * @param {(items: Element[]) => void} [options.onChange] Called whenever the selection changes.
 */
export function createSelection({ onChange = () => {} } = {}) {
  let items = [];

  function set(next) {
    for (const el of items) if (!next.includes(el)) mark(el, false);
    for (const el of next) mark(el, true);
    const changed = next.length !== items.length || next.some((el, i) => el !== items[i]);
    items = next;
    if (changed) onChange([...items]);
  }

  return {
    /** Handles a click on an object: select it, or add/remove it with ⌘/Ctrl. */
    click(el, event) {
      if (event && isAdditive(event)) {
        set(items.includes(el) ? items.filter((i) => i !== el) : [...items, el]);
      } else {
        set([el]);
      }
    },
    /** Selects just this object. */
    select(el) {
      set([el]);
    },
    /** Selects these objects, replacing the selection, or adding to it with add. */
    selectMany(els, { add = false } = {}) {
      const base = add ? items : [];
      set([...base, ...els.filter((el) => !base.includes(el))]);
    },
    clear() {
      set([]);
    },
    /** Forgets an object that left the page (e.g. it was deleted). */
    forget(el) {
      if (items.includes(el)) set(items.filter((i) => i !== el));
    },
    items: () => items.filter((el) => el.isConnected),
    has: (el) => items.includes(el),
    /** The selected objects of one kind, e.g. "node". */
    ofKind: (kind) => items.filter((el) => el.isConnected && el.dataset.kind === kind),
  };
}

function mark(el, selected) {
  el.classList.toggle("is-selected", selected);
  if (selected) el.setAttribute("aria-selected", "true");
  else el.removeAttribute("aria-selected");
}
