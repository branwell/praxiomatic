// Icons shared by perspectives, as SVG elements, so they can be placed in
// HTML or inside another SVG. Each is drawn on a 24×24 grid; its look (size,
// stroke) comes from the class the caller gives it. A perspective draws its
// own icons (e.g. its Perspectives page icon) with icon().

const SVG_NS = "http://www.w3.org/2000/svg";

// A picture: marks images.
export function imageIcon(className) {
  return icon(className, [
    ["rect", { x: 3, y: 5, width: 18, height: 14, rx: 2 }],
    ["circle", { cx: 9, cy: 10, r: 1.5 }],
    ["path", { d: "M21 16l-5-5-8 8" }],
  ]);
}

/**
 * An SVG icon on a 24×24 grid.
 * @param {string} className
 * @param {[string, Record<string, string | number>][]} shapes Each shape's tag and attributes.
 * @returns {SVGSVGElement}
 */
export function icon(className, shapes) {
  const svg = document.createElementNS(SVG_NS, "svg");
  svg.setAttribute("class", className);
  svg.setAttribute("viewBox", "0 0 24 24");
  svg.setAttribute("aria-hidden", "true");
  for (const [tag, attrs] of shapes) {
    const shape = document.createElementNS(SVG_NS, tag);
    for (const [name, value] of Object.entries(attrs)) shape.setAttribute(name, value);
    svg.append(shape);
  }
  return svg;
}
