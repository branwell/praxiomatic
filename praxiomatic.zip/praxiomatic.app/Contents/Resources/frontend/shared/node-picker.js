// Node picker: a text box that lists the nodes whose titles contain what's
// typed (ignoring case), for choosing an existing node. ↑/↓ move through the
// list, Enter chooses, Escape closes it; the pointer works too. The caller
// supplies the nodes, so the picker knows nothing about where they come from.

const MAX_SHOWN = 20;

/**
 * Creates a node picker.
 * @param {object} options
 * @param {() => {id: string, title: string}[]} options.nodes The nodes to
 *   choose from, read each time the list is shown.
 * @param {(node: {id: string, title: string}) => void} options.onPick Called
 *   with the chosen node; the text box is then cleared.
 * @param {string} [options.placeholder]
 * @returns {{ element: HTMLElement, input: HTMLInputElement }}
 */
export function createNodePicker({ nodes, onPick, placeholder = "Type part of a title…" }) {
  const input = Object.assign(document.createElement("input"), {
    className: "input node-picker-input",
    type: "text",
    placeholder,
    autocomplete: "off",
    spellcheck: false,
  });
  input.setAttribute("role", "combobox");
  input.setAttribute("aria-autocomplete", "list");
  input.setAttribute("aria-expanded", "false");
  input.setAttribute("aria-label", "Node");

  const list = document.createElement("ul");
  list.className = "node-picker-list";
  list.setAttribute("role", "listbox");
  list.hidden = true;

  const element = document.createElement("div");
  element.className = "node-picker";
  element.append(input, list);

  let matches = [];
  let active = -1;

  function show() {
    const text = input.value.trim().toLowerCase();
    matches = text
      ? nodes()
          .filter((n) => n.title.toLowerCase().includes(text))
          .sort((a, b) => a.title.localeCompare(b.title, undefined, { sensitivity: "base" }))
      : [];
    active = matches.length ? 0 : -1;
    render();
  }

  function render() {
    const shown = matches.slice(0, MAX_SHOWN);
    list.replaceChildren(
      ...shown.map((n, i) => {
        const item = document.createElement("li");
        item.className = "node-picker-option" + (i === active ? " is-active" : "");
        item.setAttribute("role", "option");
        item.setAttribute("aria-selected", String(i === active));
        item.textContent = n.title;
        // mousedown, not click, so the choice is made before the text box loses focus.
        item.addEventListener("mousedown", (event) => {
          event.preventDefault();
          pick(i);
        });
        return item;
      }),
    );
    if (matches.length > MAX_SHOWN) {
      const more = document.createElement("li");
      more.className = "node-picker-more";
      more.textContent = `${matches.length - MAX_SHOWN} more: keep typing to narrow the list.`;
      list.append(more);
    } else if (input.value.trim() && !matches.length) {
      const none = document.createElement("li");
      none.className = "node-picker-more";
      none.textContent = "No matching nodes.";
      list.append(none);
    }
    list.hidden = list.childElementCount === 0;
    input.setAttribute("aria-expanded", String(!list.hidden));
  }

  function close() {
    matches = [];
    active = -1;
    render();
  }

  function pick(i) {
    const node = matches[i];
    if (!node) return;
    input.value = "";
    close();
    onPick(node);
  }

  input.addEventListener("input", show);
  input.addEventListener("focus", show);
  input.addEventListener("blur", close);
  input.addEventListener("keydown", (event) => {
    if (event.key === "ArrowDown" || event.key === "ArrowUp") {
      if (!matches.length) return;
      event.preventDefault();
      const last = Math.min(matches.length, MAX_SHOWN) - 1;
      active = event.key === "ArrowDown" ? Math.min(active + 1, last) : Math.max(active - 1, 0);
      render();
    } else if (event.key === "Enter") {
      event.preventDefault();
      pick(active);
    } else if (event.key === "Escape" && !list.hidden) {
      // Closes the list only, not a dialog or anything else Escape would close.
      event.preventDefault();
      event.stopPropagation();
      close();
    }
  });

  return { element, input };
}
