// Right-click menus (spec: Interaction Model). Perspectives supply the items;
// this shows them at the pointer and runs the one chosen. Items can come in
// groups (e.g. a node's own actions, then other perspectives', then the
// view's); when more than one group has items, each gets a heading.
//
// Arrow keys, Home, and End move between items; Enter or Space runs one;
// Escape or Tab closes the menu. It also closes on a click elsewhere, or when
// the window scrolls, resizes, or loses focus. Only one menu is open at a time.

let current = null; // { menu, cleanup }

/**
 * @param {object} options
 * @param {number} options.x Viewport x of the menu's top-left corner.
 * @param {number} options.y Viewport y.
 * @param {MenuItem[]} [options.items] A menu without groups.
 * @param {{heading: string, items: MenuItem[]}[]} [options.groups] A menu in
 *   groups, in place of items. Empty groups are left out.
 *
 * @typedef {{label: string, action: () => void, danger?: boolean, disabled?: boolean, checked?: boolean}} MenuItem
 *   checked makes the item a setting, ticked while it's on (true).
 */
export function openContextMenu({ x, y, items, groups }) {
  closeContextMenu();
  groups = (groups ?? [{ items: items ?? [] }]).filter((g) => g.items.length > 0);
  if (groups.length === 0) return;

  const menu = document.createElement("div");
  menu.className = "context-menu";
  menu.setAttribute("role", "menu");
  for (const group of groups) {
    if (groups.length > 1) {
      const heading = document.createElement("div");
      heading.className = "context-menu-heading";
      heading.setAttribute("role", "presentation");
      heading.textContent = group.heading;
      menu.append(heading);
    }
    for (const item of group.items) {
      const button = document.createElement("button");
      button.type = "button";
      button.className = "context-menu-item";
      if (item.checked === undefined) {
        button.setAttribute("role", "menuitem");
      } else {
        button.setAttribute("role", "menuitemcheckbox");
        button.setAttribute("aria-checked", String(item.checked));
      }
      button.textContent = item.label;
      button.disabled = Boolean(item.disabled);
      button.classList.toggle("is-danger", Boolean(item.danger));
      button.addEventListener("click", () => {
        closeContextMenu();
        item.action();
      });
      menu.append(button);
    }
  }
  document.body.append(menu);

  // Keep the whole menu inside the window.
  const box = menu.getBoundingClientRect();
  const left = Math.max(4, Math.min(x, window.innerWidth - box.width - 4));
  const top = Math.max(4, Math.min(y, window.innerHeight - box.height - 4));
  menu.style.setProperty("--x", `${left}px`);
  menu.style.setProperty("--y", `${top}px`);

  const buttons = () => [...menu.querySelectorAll(".context-menu-item:not(:disabled)")];
  menu.addEventListener("keydown", (event) => {
    const all = buttons();
    const i = all.indexOf(document.activeElement);
    const go = (n) => all[(n + all.length) % all.length]?.focus();
    if (event.key === "ArrowDown") go(i + 1);
    else if (event.key === "ArrowUp") go(i - 1);
    else if (event.key === "Home") go(0);
    else if (event.key === "End") go(all.length - 1);
    else if (event.key === "Escape" || event.key === "Tab") closeContextMenu();
    else return;
    event.preventDefault();
    event.stopPropagation();
  });

  const onPointerDown = (event) => {
    if (!menu.contains(event.target)) closeContextMenu();
  };
  const onDismiss = () => closeContextMenu();
  document.addEventListener("pointerdown", onPointerDown, true);
  window.addEventListener("blur", onDismiss);
  window.addEventListener("resize", onDismiss);
  window.addEventListener("scroll", onDismiss, true);

  current = {
    menu,
    cleanup() {
      document.removeEventListener("pointerdown", onPointerDown, true);
      window.removeEventListener("blur", onDismiss);
      window.removeEventListener("resize", onDismiss);
      window.removeEventListener("scroll", onDismiss, true);
    },
  };
  buttons()[0]?.focus();
}

export function closeContextMenu() {
  if (!current) return;
  const { menu, cleanup } = current;
  current = null;
  cleanup();
  menu.remove();
}

export function isContextMenuOpen() {
  return current !== null;
}
