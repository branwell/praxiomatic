// Images attached to nodes, shared by the core node dialog and node panel: which
// pasted files can be attached, and how an attached image is shown.

// The images that can be attached (spec: Assets), and their size limit.
const IMAGE_TYPES = new Set(["image/png", "image/jpeg", "image/gif", "image/webp"]);
const MAX_IMAGE_BYTES = 20 * 1024 * 1024;

/**
 * The image files in a paste, sorted into those that can be attached and
 * messages for those that can't.
 * @param {ClipboardEvent} event
 * @returns {{files: File[], refused: string[]}} Both empty if the paste has no images.
 */
export function pastedImages(event) {
  const files = [];
  const refused = [];
  for (const file of event.clipboardData?.files ?? []) {
    if (!file.type.startsWith("image/")) continue;
    if (!IMAGE_TYPES.has(file.type)) refused.push(`${file.name} isn't a PNG, JPEG, GIF, or WebP image.`);
    else if (file.size > MAX_IMAGE_BYTES) refused.push(`${file.name} is over 20 MB.`);
    else files.push(file);
  }
  return { files, refused };
}

/** An asset's image, linking to it full size in a new tab. */
export function imageLink(assetId, title) {
  const href = `/api/assets/${encodeURIComponent(assetId)}`;
  const img = Object.assign(document.createElement("img"), { src: href, alt: title });
  const link = Object.assign(document.createElement("a"), { href, target: "_blank", rel: "noopener" });
  link.title = "Open full size in a new tab";
  link.append(img);
  return link;
}
