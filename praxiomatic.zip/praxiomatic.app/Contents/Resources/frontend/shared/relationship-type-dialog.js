// Choosing a relationship type for relationships that already exist (e.g.
// Change relationship type… in a perspective's menu). Cancel, Escape, or a
// click outside the window chooses nothing.
//
// Given a direction (one relationship whose type is symmetric), it also shows
// source → target while the chosen type is directed, with ⇄ to swap them.

let ui = null;

/**
 * Asks for a relationship type.
 * @param {object} options
 * @param {string} options.title
 * @param {{id: string, name: string, isSymmetric?: boolean}[]} options.types In the order to list them.
 * @param {string|null} [options.current] The type chosen at first.
 * @param {{source: string, target: string}|null} [options.direction] The
 *   relationship's source and target titles, to offer swapping them.
 * @returns {Promise<{typeId: string, reverse: boolean}|null>} The chosen
 *   type's id and whether to swap source and target, or null if cancelled.
 */
export function chooseRelationshipType({ title, types, current = null, direction = null }) {
  ui ??= buildDialog();
  ui.title.textContent = title;
  ui.select.replaceChildren(...types.map((t) => Object.assign(document.createElement("option"), { value: t.id, textContent: t.name })));
  ui.select.value = current ?? types[0]?.id ?? "";
  let reverse = false;
  const showDirection = () => {
    const directed = !types.find((t) => t.id === ui.select.value)?.isSymmetric;
    ui.direction.hidden = !direction || !directed;
    if (!direction) return;
    const [from, to] = reverse ? [direction.target, direction.source] : [direction.source, direction.target];
    ui.directionText.textContent = `${from} → ${to}`;
  };
  ui.select.onchange = showDirection;
  ui.swap.onclick = () => {
    reverse = !reverse;
    showDirection();
  };
  showDirection();
  ui.dialog.returnValue = "";
  ui.dialog.showModal();
  ui.select.focus();
  return new Promise((resolve) => {
    ui.dialog.addEventListener("close", () => resolve(ui.dialog.returnValue === "change"
      ? { typeId: ui.select.value, reverse: !ui.direction.hidden && reverse }
      : null), { once: true });
  });
}

function buildDialog() {
  const dialog = document.createElement("dialog");
  dialog.className = "dialog";
  dialog.setAttribute("aria-labelledby", "relationship-type-title");

  const form = document.createElement("form");
  form.className = "dialog-body";
  form.method = "dialog";

  const title = document.createElement("h2");
  title.className = "dialog-title";
  title.id = "relationship-type-title";

  const field = document.createElement("label");
  field.className = "field";
  const label = Object.assign(document.createElement("span"), { className: "field-label", textContent: "Relationship type" });
  const select = Object.assign(document.createElement("select"), { className: "input" });
  field.append(label, select);

  const direction = document.createElement("div");
  direction.className = "field";
  const directionLabel = Object.assign(document.createElement("span"), { className: "field-label", textContent: "Direction" });
  const directionRow = Object.assign(document.createElement("div"), { className: "relationship-direction" });
  const directionText = document.createElement("span");
  const swap = Object.assign(document.createElement("button"), { type: "button", className: "btn btn--secondary", textContent: "⇄" });
  swap.setAttribute("aria-label", "Swap source and target");
  directionRow.append(directionText, swap);
  direction.append(directionLabel, directionRow);

  const actions = document.createElement("div");
  actions.className = "dialog-actions";
  const cancel = Object.assign(document.createElement("button"), { className: "btn btn--secondary", value: "cancel", textContent: "Cancel" });
  const change = Object.assign(document.createElement("button"), { className: "btn btn--primary", value: "change", textContent: "Change" });
  actions.append(cancel, change);
  form.append(title, field, direction, actions);
  dialog.append(form);
  document.body.append(dialog);

  // Enter in the list changes. (Left to the form, Enter would press its first
  // button, Cancel.)
  select.addEventListener("keydown", (event) => {
    if (event.key !== "Enter") return;
    event.preventDefault();
    dialog.close("change");
  });

  // A click on the backdrop (outside the window) chooses nothing.
  let pressedOnBackdrop = false;
  dialog.addEventListener("pointerdown", (event) => { pressedOnBackdrop = event.target === dialog; });
  dialog.addEventListener("click", (event) => {
    if (event.target === dialog && pressedOnBackdrop) dialog.close();
    pressedOnBackdrop = false;
  });

  return { dialog, title, select, direction, directionText, swap };
}
