// The site menu: the ☰ button at the right of every page's site header
// (spec: UI). It opens a menu of application-wide items under the button;
// today just About…, which shows the About dialog.

import { openContextMenu } from "./context-menu.js";
import { icon } from "./icons.js";

const LOGO_URL = new URL("parallax-icon.svg", import.meta.url).href;

let about = null;

function openAbout() {
  about ??= buildAbout();
  about.showModal();
}

function buildAbout() {
  const dialog = document.createElement("dialog");
  dialog.className = "dialog";
  dialog.setAttribute("aria-labelledby", "about-title");

  const form = document.createElement("form");
  form.className = "dialog-body about";
  form.method = "dialog";

  const logo = Object.assign(document.createElement("img"), { className: "about-logo", src: LOGO_URL, alt: "" });
  const title = Object.assign(document.createElement("h2"), { className: "dialog-title", id: "about-title", textContent: "Parallax" });
  const description = Object.assign(document.createElement("p"), { textContent: "An information discovery and exploration tool." });
  const copyright = Object.assign(document.createElement("p"), { className: "muted", textContent: "© Metaphorica 2026" });

  const actions = document.createElement("div");
  actions.className = "dialog-actions";
  actions.append(Object.assign(document.createElement("button"), {
    className: "btn btn--secondary", value: "close", textContent: "Close",
  }));

  form.append(logo, title, description, copyright, actions);
  dialog.append(form);
  // Clicking outside the dialog (on its backdrop) closes it.
  dialog.addEventListener("click", (event) => {
    if (event.target === dialog) dialog.close();
  });
  document.body.append(dialog);
  return dialog;
}

const button = document.getElementById("site-menu");
if (button) {
  // Three lines.
  button.append(icon("site-menu-icon", [["path", { d: "M4 7h16M4 12h16M4 17h16" }]]));
  button.addEventListener("click", () => {
    const rect = button.getBoundingClientRect();
    openContextMenu({ x: rect.right, y: rect.bottom, items: [{ label: "About…", action: openAbout }] });
  });
}
