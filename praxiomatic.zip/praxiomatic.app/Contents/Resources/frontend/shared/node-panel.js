// Core node panel: edits a node's own data in place, in a panel a perspective
// keeps on its page (Graph: the details panel), instead of in the modal node
// dialog. It shows the same fields as the dialog: title, content, property
// values, images, created time and creator, and, above the properties, the
// node's sources (the nodes its source_is relationships point to), read-only,
// each a link when the source is a URL. It knows nothing about perspectives.
//
// Each change is saved as it's committed, with no Save button: the title when
// its field is left or on Enter, the content when its field is left or on
// Ctrl/Cmd+Enter, a property value when its field is left or on Enter (or at
// once when cleared with ×). Escape in a field puts back its saved value. If a
// save fails, the saved value comes back and an error is shown. Images pasted
// into the panel are attached at once; removing one asks first, since the
// image node is deleted too if nothing else connects to it.

import { api } from "./api.js";
import { confirmAction } from "./confirm.js";
import { imageLink, pastedImages } from "./node-images.js";
import { createPropertiesEditor } from "./properties.js";

const MAX_TITLE_LENGTH = 256;
const MAX_LINK_TEXT = 20; // characters of a source link shown before "…"

/**
 * Builds a node panel, hidden until a node is shown.
 * @param {object} options
 * @param {(node: object) => void} options.onSaved Called with the node each
 *   time a change to it is saved, even if the panel shows another by then.
 * @param {() => void} options.onImagesChanged Called after images are attached
 *   or removed (their nodes and edges were then created or deleted).
 * @param {(message: string) => void} options.onError Shows an error about a
 *   node the panel no longer shows.
 * @returns {{
 *   element: HTMLElement,
 *   show: (nodeId: string) => Promise<void>,
 *   clear: () => void,
 *   focus: () => Promise<void>,
 *   flush: () => void,
 * }}
 *   show saves any change being made to the node shown, then loads and shows
 *   another (resolving once it's shown, or failed to load, with an error in
 *   the panel). clear saves likewise and hides the panel. focus puts the
 *   cursor in the title once the node is shown. flush saves changes being made
 *   but not committed yet, such as text typed in a field that still has focus.
 */
export function createNodePanel({ onSaved, onImagesChanged, onError }) {
  // The node shown: { nodeId, node, images, sources }; node, images, and
  // sources are as last loaded or saved, and node null until loaded. Replaced on each show, so work
  // that finishes later can tell whether the panel still shows its node.
  let current = null;
  // Loads run one after another, so an earlier one can't overwrite a later.
  let loaded = Promise.resolve();
  // Saves in progress; a load waits for them, so it shows what they saved.
  const saving = new Set();

  const ui = build();

  function show(nodeId) {
    flush();
    const editing = { nodeId, node: null, images: [], sources: [] };
    current = editing;
    ui.element.hidden = false;
    ui.fields.hidden = true;
    setError("");
    loaded = loaded.then(() => load(editing));
    return loaded;
  }

  function clear() {
    flush();
    current = null;
    ui.element.hidden = true;
  }

  async function focus() {
    await loaded;
    if (current?.node) ui.title.focus();
  }

  function flush() {
    saveTitle();
    saveContent();
    saveProperties();
  }

  async function load(editing) {
    await Promise.allSettled([...saving]);
    if (editing !== current) return;
    const path = nodePath(editing.nodeId);
    try {
      const [node, { images }, { sources }] = await Promise.all([
        api("GET", path),
        api("GET", `${path}/images`),
        api("GET", `${path}/sources`),
      ]);
      if (editing !== current) return;
      await ui.properties.load(node.properties);
      if (editing !== current) return;
      editing.node = node;
      editing.images = images;
      editing.sources = sources;
    } catch (err) {
      if (editing === current) setError(`Could not load the node. ${err.message}`);
      return;
    }
    const { node } = editing;
    ui.title.value = node.title;
    ui.content.value = node.content ?? "";
    ui.content.classList.toggle("is-sql", node.format === "sql");
    // An image node shows its own image.
    ui.ownImageField.hidden = !node.asset_id;
    ui.ownImage.replaceChildren(...(node.asset_id ? [imageLink(node.asset_id, node.title)] : []));
    renderSources();
    renderImages();
    ui.created.textContent = formatUTC(node.created_utc);
    ui.createdBy.textContent = node.created_by_username;
    ui.fields.hidden = false;
  }

  function saveTitle() {
    const editing = current;
    if (!editing?.node) return;
    // Titles are single-line; collapse pasted line breaks and runs of spaces.
    const value = ui.title.value.replace(/\s+/g, " ").trim();
    if (value === editing.node.title) return;
    if (!value) {
      ui.title.value = editing.node.title;
      report(editing, "Title is required.");
      return;
    }
    save(editing, { title: value }, () => {
      ui.title.value = editing.node.title;
    });
  }

  function saveContent() {
    const editing = current;
    if (!editing?.node) return;
    const value = ui.content.value;
    if (value === (editing.node.content ?? "")) return;
    save(editing, { content: value }, () => {
      ui.content.value = editing.node.content ?? "";
    });
  }

  function saveProperties() {
    const editing = current;
    if (!editing?.node) return;
    const changes = ui.properties.changes();
    if (!Object.keys(changes).length) return;
    save(editing, { properties: changes }, () => {
      ui.properties.load(editing.node.properties).catch((err) => setError(`Could not load the properties. ${err.message}`));
    }).then((saved) => {
      if (saved && editing === current) ui.properties.markSaved(changes);
    });
  }

  // Saves part of a node. On failure, revert puts back the saved value if the
  // panel still shows the node. Resolves to the saved node, or null.
  function save(editing, body, revert) {
    return track(async () => {
      try {
        const node = await api("PATCH", nodePath(editing.nodeId), body);
        editing.node = node;
        onSaved(node);
        if (editing === current) setError("");
        return node;
      } catch (err) {
        if (editing === current) revert();
        report(editing, `Could not save the node. ${err.message}`);
        return null;
      }
    });
  }

  // Attaches pasted images, one request each, stopping at the first failure.
  function attach(files) {
    const editing = current;
    if (!editing?.node || !files.length) return;
    track(async () => {
      let changed = false;
      try {
        for (const file of files) {
          const form = new FormData();
          form.append("image", file, file.name);
          editing.images.push(await api("POST", `${nodePath(editing.nodeId)}/images`, form));
          changed = true;
        }
      } catch (err) {
        report(editing, `Could not attach ${files.length === 1 ? "the image" : "all the images"}. ${err.message}`);
      }
      if (editing === current) renderImages();
      if (changed) onImagesChanged();
    });
  }

  async function detach(image) {
    const editing = current;
    const confirmed = await confirmAction({
      title: "Remove image",
      message: `Remove “${image.title}” from this node? The image is deleted too if nothing else connects to it. This can't be undone.`,
      confirmLabel: "Remove",
    });
    if (!confirmed) return;
    await track(async () => {
      try {
        await api("DELETE", `${nodePath(editing.nodeId)}/images/${encodeURIComponent(image.node_id)}`);
      } catch (err) {
        report(editing, `Could not remove the image. ${err.message}`);
        return;
      }
      editing.images = editing.images.filter((img) => img.node_id !== image.node_id);
      if (editing === current) renderImages();
      onImagesChanged();
    });
  }

  // Runs work, counting it as a save in progress until it's done.
  function track(work) {
    const promise = work();
    saving.add(promise);
    promise.finally(() => saving.delete(promise));
    return promise;
  }

  // An error goes in the panel if it still shows the node, else to the page.
  function report(editing, message) {
    if (editing === current) setError(message);
    else onError(message);
  }

  // The node's sources, shown only when it has some: each its title, linking
  // to the source when its text is a web address. A long link shows its first
  // MAX_LINK_TEXT characters and "…", and its whole title on hover.
  function renderSources() {
    ui.sourcesField.hidden = !current.sources.length;
    ui.sources.replaceChildren(...current.sources.map((source) => {
      const href = webAddress(source.content || source.title);
      if (!href) return el("span", { textContent: source.title });
      const text = source.title.length > MAX_LINK_TEXT ? `${source.title.slice(0, MAX_LINK_TEXT)}…` : source.title;
      const link = el("a", { href, target: "_blank", rel: "noopener noreferrer", textContent: text });
      link.title = `${source.title}\nOpen in a new tab`;
      return link;
    }));
  }

  function renderImages() {
    const items = current.images.map((image) => {
      const remove = el("button", { type: "button", className: "dialog-image-remove", textContent: "×" });
      remove.setAttribute("aria-label", `Remove ${image.title}`);
      remove.title = "Remove image";
      remove.addEventListener("click", () => detach(image));
      return el("figure", { className: "dialog-image" }, [
        imageLink(image.asset_id, image.title),
        el("figcaption", {}, [el("span", { textContent: image.title }), remove]),
      ]);
    });
    if (!items.length) items.push(el("p", { className: "dialog-images-empty", textContent: "No images." }));
    ui.images.replaceChildren(...items);
  }

  function setError(message) {
    ui.error.textContent = message;
    ui.error.hidden = !message;
  }

  function build() {
    const error = el("p", { className: "alert alert--error", hidden: true });
    error.setAttribute("role", "alert");
    const title = el("input", {
      className: "input",
      id: "node-panel-title",
      type: "text",
      maxLength: MAX_TITLE_LENGTH,
      autocomplete: "off",
    });
    const content = el("textarea", { className: "input details-panel-content", id: "node-panel-content", rows: 6 });
    const ownImage = el("div", { className: "dialog-image" });
    const ownImageField = el("div", { className: "field" }, [el("span", { className: "field-label", textContent: "Image" }), ownImage]);
    const sources = el("div", { className: "details-panel-sources" });
    const sourcesField = el("div", { className: "field", hidden: true }, [el("span", { className: "field-label", textContent: "Source" }), sources]);
    const properties = createPropertiesEditor("node", setError, { onCommit: () => saveProperties(), removeTitle: "Clear" });
    const images = el("div", { className: "dialog-images" });
    const created = el("dd");
    const createdBy = el("dd");

    const fields = el("div", { className: "details-panel-fields", hidden: true }, [
      field("Title", title),
      field("Content", content),
      sourcesField,
      properties.element,
      ownImageField,
      el("div", { className: "field" }, [
        el("span", { className: "field-label", textContent: "Images" }),
        images,
        el("p", { className: "field-help", textContent: "Paste an image (⌘+V or Ctrl+V) here to attach it." }),
      ]),
      el("dl", { className: "details" }, [
        el("dt", { textContent: "Created (UTC)" }),
        created,
        el("dt", { textContent: "Created by" }),
        createdBy,
      ]),
    ]);
    // Focusable, so a click anywhere in the panel lets a paste land here.
    const element = el("div", { className: "details-panel-body", tabIndex: -1, hidden: true }, [error, fields]);

    title.addEventListener("change", saveTitle);
    title.addEventListener("keydown", (event) => {
      if (event.key === "Enter") {
        event.preventDefault();
        title.blur();
      } else if (event.key === "Escape") {
        title.value = current?.node?.title ?? title.value;
        title.blur();
      }
    });
    content.addEventListener("change", saveContent);
    content.addEventListener("keydown", (event) => {
      if (event.key === "Enter" && (event.ctrlKey || event.metaKey)) {
        event.preventDefault();
        content.blur();
      } else if (event.key === "Escape") {
        content.value = current?.node?.content ?? "";
        content.blur();
      }
    });
    // Pasting images attaches them; pasting text works as usual.
    element.addEventListener("paste", (event) => {
      const { files, refused } = pastedImages(event);
      if (!files.length && !refused.length) return;
      event.preventDefault();
      setError(refused.join(" "));
      attach(files);
    });

    return { element, fields, error, title, content, sources, sourcesField, ownImage, ownImageField, properties, images, created, createdBy };
  }

  return { element: ui.element, show, clear, focus, flush };
}

const nodePath = (id) => `/api/nodes/${encodeURIComponent(id)}`;

// The text as an http(s) URL with a host, or null if it isn't one. Other
// schemes aren't linked (see url under Properties in spec.md).
function webAddress(text) {
  try {
    const url = new URL(text.trim());
    return (url.protocol === "http:" || url.protocol === "https:") && url.host ? url.href : null;
  } catch {
    return null;
  }
}

// A labelled form field wrapping control.
function field(label, control) {
  return el("div", { className: "field" }, [el("label", { className: "field-label", htmlFor: control.id, textContent: label }), control]);
}

function el(tag, props = {}, children = []) {
  const node = Object.assign(document.createElement(tag), props);
  node.append(...children);
  return node;
}

// "2026-10-19T02:57:31.619Z" -> "2026-10-19 02:57:31"
function formatUTC(value) {
  return value.replace("T", " ").replace(/\.\d+Z$|Z$/, "");
}
