// Core node dialog: a modal window for editing a node's own data. Title,
// content, and property values are editable; created time and creator are
// read-only. Images pasted anywhere in the window are attached to the node, and
// attached images can be removed. It knows nothing about perspectives: a
// perspective that edits its own data has its own dialog.
//
// Changes, including properties and pasted and removed images, are saved only
// with Save (or Enter in the title, Ctrl/Cmd+Enter in the content). Cancel,
// Escape, or clicking outside the window close it without saving.

import { api } from "./api.js";
import { imageLink, pastedImages } from "./node-images.js";
import { createPropertiesEditor } from "./properties.js";

const MAX_TITLE_LENGTH = 256;

// Built on first use and reused.
let ui = null;

// The node being edited: { nodeId, onSaved, images, pending, removed }.
// images are the attached images as loaded; pending, images pasted but not
// saved yet ({ file, url }, url being a preview); removed, the ids of attached
// image nodes to detach on Save. Replaced on each open; not cleared on close,
// because the close event fires asynchronously and could otherwise clear a
// node opened right after.
let current = null;

/**
 * Loads a node and opens the dialog.
 * @param {string} nodeId
 * @param {(node: object, images: {count: number, changed: boolean}) => void} onSaved
 *   Called with the saved node, how many images are now attached to it, and
 *   whether any were attached or removed (their nodes and edges were then
 *   created or deleted).
 * @throws if the node can't be loaded (the dialog stays closed).
 */
export async function openNodeDialog(nodeId, onSaved) {
  const path = `/api/nodes/${encodeURIComponent(nodeId)}`;
  const [node, { images }] = await Promise.all([api("GET", path), api("GET", `${path}/images`)]);
  ui ??= buildDialog();
  for (const p of current?.pending ?? []) URL.revokeObjectURL(p.url);
  current = { nodeId, onSaved, images, pending: [], removed: new Set() };
  ui.title.value = node.title;
  ui.content.value = node.content;
  ui.content.classList.toggle("is-sql", node.format === "sql");
  // An image node shows its own image.
  ui.ownImageField.hidden = !node.asset_id;
  if (node.asset_id) ui.ownImage.replaceChildren(imageLink(node.asset_id, node.title));
  renderImages();
  await ui.properties.load(node.properties);
  ui.created.textContent = formatUTC(node.created_utc);
  ui.createdBy.textContent = node.created_by_username;
  setError("");
  ui.save.disabled = false;
  ui.dialog.showModal();
  ui.title.focus();
}

function buildDialog() {
  const dialog = el("dialog", { className: "dialog", id: "node-dialog" });
  dialog.setAttribute("aria-labelledby", "node-dialog-title");

  const form = el("form", { className: "dialog-body", id: "node-form", noValidate: true });
  const heading = el("h2", { className: "dialog-title", id: "node-dialog-title", textContent: "Edit node" });
  const error = el("p", { className: "alert alert--error", id: "node-error", hidden: true });
  error.setAttribute("role", "alert");

  const title = el("input", {
    className: "input",
    id: "node-title",
    name: "title",
    type: "text",
    maxLength: MAX_TITLE_LENGTH,
    required: true,
    autocomplete: "off",
  });
  const content = el("textarea", { className: "input dialog-content", id: "node-content", name: "content", rows: 8 });
  const ownImage = el("div", { className: "dialog-image", id: "node-own-image" });
  const ownImageField = el("div", { className: "field" }, [
    el("span", { className: "field-label", textContent: "Image" }),
    ownImage,
  ]);
  const properties = createPropertiesEditor("node", (message) => setError(message));
  const images = el("div", { className: "dialog-images", id: "node-images" });
  const created = el("dd", { id: "node-created" });
  const createdBy = el("dd", { id: "node-created-by" });

  const cancel = el("button", { type: "button", className: "btn btn--secondary", id: "node-cancel", textContent: "Cancel" });
  const save = el("button", { type: "submit", className: "btn btn--primary", id: "node-save", textContent: "Save" });

  form.append(
    heading,
    error,
    field("Title", title),
    field("Content", content, el("p", { className: "field-help", textContent: "Ctrl+Enter or ⌘+Enter to save." })),
    properties.element,
    ownImageField,
    el("div", { className: "field" }, [
      el("span", { className: "field-label", textContent: "Images" }),
      images,
      el("p", { className: "field-help", textContent: "Paste an image (⌘+V or Ctrl+V) to attach it. PNG, JPEG, GIF, or WebP, up to 20 MB." }),
    ]),
    el("dl", { className: "details" }, [
      el("dt", { textContent: "Created (UTC)" }),
      created,
      el("dt", { textContent: "Created by" }),
      createdBy,
    ]),
    el("div", { className: "dialog-actions" }, [cancel, save]),
  );
  dialog.append(form);
  document.body.append(dialog);

  form.addEventListener("submit", async (event) => {
    event.preventDefault();
    if (!dialog.open || save.disabled) return;

    // Titles are single-line; collapse pasted line breaks and runs of spaces.
    const value = title.value.replace(/\s+/g, " ").trim();
    if (!value) {
      setError("Title is required.");
      title.focus();
      return;
    }

    save.disabled = true;
    setError("");
    const editing = current;
    const path = `/api/nodes/${encodeURIComponent(editing.nodeId)}`;
    let node = null;
    let changed = false;
    try {
      // Saving again after a failure resends the same property changes, which is harmless.
      node = await api("PATCH", path, { title: value, content: content.value, properties: ui.properties.changes() });
      // One request per image. Each one done leaves the lists, so trying
      // Save again after a failure only repeats what's left.
      while (editing.pending.length) {
        const { file, url } = editing.pending[0];
        const form = new FormData();
        form.append("image", file, file.name);
        editing.images.push(await api("POST", `${path}/images`, form));
        editing.pending.shift();
        URL.revokeObjectURL(url);
        changed = true;
      }
      for (const imageId of [...editing.removed]) {
        await api("DELETE", `${path}/images/${encodeURIComponent(imageId)}`);
        editing.removed.delete(imageId);
        editing.images = editing.images.filter((img) => img.node_id !== imageId);
        changed = true;
      }
      editing.onSaved(node, { count: editing.images.length, changed });
      dialog.close();
    } catch (err) {
      // Keep the window open with the user's edits so nothing is lost; show
      // what has been saved so far.
      if (node) editing.onSaved(node, { count: editing.images.length, changed });
      if (editing === current) renderImages();
      setError(`Could not save the node. ${err.message}`);
    } finally {
      save.disabled = false;
    }
  });

  // Pasting images anywhere in the window attaches them on Save; pasting
  // text works as usual.
  dialog.addEventListener("paste", (event) => {
    const { files, refused } = pastedImages(event);
    if (!files.length && !refused.length) return;
    event.preventDefault();
    for (const file of files) current.pending.push({ file, url: URL.createObjectURL(file) });
    setError(refused.join(" "));
    renderImages();
  });

  content.addEventListener("keydown", (event) => {
    if (event.key === "Enter" && (event.ctrlKey || event.metaKey)) {
      event.preventDefault();
      form.requestSubmit();
    }
  });

  cancel.addEventListener("click", () => dialog.close());

  // Clicking the backdrop closes the dialog. A click on the backdrop targets the
  // dialog itself, but so does a text selection that starts inside the form and
  // ends outside it, so the press must also have started on the backdrop.
  let pressedOnBackdrop = false;
  dialog.addEventListener("pointerdown", (event) => {
    pressedOnBackdrop = event.target === dialog;
  });
  dialog.addEventListener("click", (event) => {
    if (event.target === dialog && pressedOnBackdrop) dialog.close();
    pressedOnBackdrop = false;
  });

  return { dialog, title, content, properties, ownImage, ownImageField, images, created, createdBy, error, save };
}

// Shows the attached images (except those removed but not saved yet), then
// the pasted ones, each scaled to the window's width with a remove (×)
// control. Attached images open full size in a new tab.
function renderImages() {
  const items = [];
  for (const img of current.images) {
    if (current.removed.has(img.node_id)) continue;
    items.push(imageFigure(imageLink(img.asset_id, img.title), img.title, () => current.removed.add(img.node_id)));
  }
  for (const p of current.pending) {
    const preview = el("img", { src: p.url, alt: p.file.name });
    const figure = imageFigure(preview, `${p.file.name} · not saved yet`, () => {
      current.pending.splice(current.pending.indexOf(p), 1);
      URL.revokeObjectURL(p.url);
    });
    figure.classList.add("is-pending");
    items.push(figure);
  }
  if (!items.length) items.push(el("p", { className: "dialog-images-empty", textContent: "No images." }));
  ui.images.replaceChildren(...items);
}

function imageFigure(picture, caption, onRemove) {
  const remove = el("button", { type: "button", className: "dialog-image-remove", textContent: "×" });
  remove.setAttribute("aria-label", `Remove ${caption}`);
  remove.title = "Remove image (on Save)";
  remove.addEventListener("click", () => {
    onRemove();
    renderImages();
  });
  return el("figure", { className: "dialog-image" }, [
    picture,
    el("figcaption", {}, [el("span", { textContent: caption }), remove]),
  ]);
}

// A labelled form field wrapping control, with optional help text after it.
function field(label, control, help) {
  const wrapper = el("div", { className: "field" }, [
    el("label", { className: "field-label", htmlFor: control.id, textContent: label }),
    control,
  ]);
  if (help) wrapper.append(help);
  return wrapper;
}

function el(tag, props = {}, children = []) {
  const node = Object.assign(document.createElement(tag), props);
  node.append(...children);
  return node;
}

function setError(message) {
  ui.error.textContent = message;
  ui.error.hidden = !message;
}

// "2026-10-19T02:57:31.619Z" -> "2026-10-19 02:57:31"
function formatUTC(value) {
  return value.replace("T", " ").replace(/\.\d+Z$|Z$/, "");
}
