// Properties section of the core node and relationship dialogs and panels: a
// node's or an edge's property values, each edited according to its
// definition's data type, with "+ Add property" to pick a definition or create
// one. Values are only collected here; a dialog saves them with its own Save, a
// panel as each is committed (onCommit), and the server checks them. Timestamps are set by the system (e.g. imported_on): they're
// shown read-only, can't be cleared, and aren't offered to add.

import { api } from "./api.js";

const MAX_NAME_LENGTH = 64;
const NEW_PROPERTY = "__new__";

// Data types whose values only the system sets (core.IsSystemSet).
const isSystemSet = (dataType) => dataType === "timestamp";

const HELP = {
  text: "One line.",
  date: "YYYY, YYYY-MM, or YYYY-MM-DD",
  integer: "e.g. 42 or -7",
  decimal: "e.g. 42 or -3.5",
  url: "https://…",
};

/**
 * Creates a properties editor.
 * @param {"node"|"edge"} kind What the values belong to; only definitions
 *   allowed on it can be added.
 * @param {(message: string) => void} onError Shows a message in the dialog
 *   ("" clears it).
 * @param {object} [options]
 * @param {() => void} [options.onChange] Called when the user adds, edits, or
 *   removes a value.
 * @param {() => void} [options.onCommit] Called when the user commits a value:
 *   leaves its field or presses Enter after editing it, or removes it. With
 *   onCommit, Escape in a field puts back its value as loaded.
 * @param {string} [options.removeTitle] The tooltip of a value's ×.
 * @returns {{
 *   element: HTMLElement,
 *   load: (properties: Object<string, string>) => Promise<void>,
 *   changes: () => Object<string, string>,
 *   markSaved: (saved: Object<string, string>) => void,
 *   values: () => Object<string, string>,
 * }}
 *   load shows an object's values (keyed by definition id), reloading the
 *   definitions; it throws if they can't be loaded. changes returns the values
 *   that differ from those loaded, "" for a value cleared. markSaved takes
 *   changes that were saved as the values loaded, so they aren't changes any
 *   more. values returns every value shown that isn't blank.
 */
export function createPropertiesEditor(kind, onError, { onChange = () => {}, onCommit = null, removeTitle = "Clear (on Save)" } = {}) {
  let definitions = new Map(); // id -> definition
  let original = {}; // the values as loaded
  let rows = new Map(); // id -> input, for the properties shown, in order
  let readOnly = new Set(); // ids of the system-set properties shown

  const list = el("div", { className: "properties" });
  const add = el("button", { type: "button", className: "btn btn--ghost properties-add", textContent: "+ Add property" });
  const picker = el("select", { className: "input" });
  picker.setAttribute("aria-label", "Property to add");
  const newName = el("input", { className: "input", type: "text", maxLength: MAX_NAME_LENGTH, placeholder: "Name", autocomplete: "off" });
  newName.setAttribute("aria-label", "New property name");
  const newType = el("select", { className: "input" }, ["text", "date", "integer", "decimal", "boolean", "url"].map((t) => el("option", { value: t, textContent: t })));
  newType.setAttribute("aria-label", "New property data type");
  const create = el("button", { type: "button", className: "btn btn--secondary", textContent: "Create" });
  const creator = el("div", { className: "properties-new", hidden: true }, [newName, newType, create]);
  const adder = el("div", { className: "properties-adder", hidden: true }, [picker, creator]);
  const element = el("div", { className: "field" }, [
    el("span", { className: "field-label", textContent: "Properties" }),
    list,
    adder,
    add,
  ]);

  add.addEventListener("click", () => {
    fillPicker();
    adder.hidden = false;
    add.hidden = true;
    showCreator(picker.value === NEW_PROPERTY);
    (picker.value === NEW_PROPERTY ? newName : picker).focus();
  });

  picker.addEventListener("change", () => {
    if (picker.value === NEW_PROPERTY) {
      showCreator(true);
      newName.focus();
    } else if (picker.value) {
      addRow(picker.value, "").focus();
      closeAdder();
      onChange();
    }
  });

  create.addEventListener("click", createDefinition);
  newName.addEventListener("keydown", (event) => {
    // Enter creates the property instead of saving the dialog.
    if (event.key === "Enter") {
      event.preventDefault();
      createDefinition();
    }
  });

  async function createDefinition() {
    const name = newName.value.replace(/\s+/g, " ").trim();
    if (!name) {
      onError("A property needs a name.");
      newName.focus();
      return;
    }
    create.disabled = true;
    try {
      // Allowed on nodes and edges, as by default on the Properties page.
      const definition = await api("POST", "/api/property-definitions", { property_name: name, data_type: newType.value });
      definitions.set(definition.id, definition);
      onError("");
      addRow(definition.id, "").focus();
      closeAdder();
      onChange();
    } catch (err) {
      onError(`Could not create the property. ${err.message}`);
      newName.focus();
    } finally {
      create.disabled = false;
    }
  }

  // The definitions that can be added: allowed here and not shown yet, by name.
  function fillPicker() {
    const allowed = kind === "node" ? "allowed_on_nodes" : "allowed_on_edges";
    const options = [...definitions.values()]
      .filter((d) => d[allowed] && !rows.has(d.id) && !isSystemSet(d.data_type))
      .sort((a, b) => a.property_name.localeCompare(b.property_name, undefined, { sensitivity: "base" }))
      .map((d) => el("option", { value: d.id, textContent: `${d.property_name} (${d.data_type})`, title: d.description }));
    picker.replaceChildren(
      el("option", { value: "", textContent: "Choose a property…", disabled: true, selected: true }),
      ...options,
      el("option", { value: NEW_PROPERTY, textContent: "New property…" }),
    );
    if (!options.length) picker.value = NEW_PROPERTY;
  }

  function showCreator(show) {
    creator.hidden = !show;
    if (show) {
      newName.value = "";
      newType.value = "text";
    }
  }

  function closeAdder() {
    adder.hidden = true;
    add.hidden = false;
  }

  // Adds a row for a definition, and returns its input.
  function addRow(id, value) {
    const d = definitions.get(id);
    const input = d.data_type === "boolean" ? booleanSelect(value) : el("input", {
      className: "input",
      type: d.data_type === "url" ? "url" : "text",
      value,
      placeholder: HELP[d.data_type] ?? "",
      autocomplete: "off",
    });
    input.setAttribute("aria-label", d.property_name);
    const label = el("span", { className: "properties-name", textContent: d.property_name });
    if (d.description) label.title = d.description;
    const row = el("div", { className: "properties-row" }, [label, input]);
    if (d.data_type === "url") row.append(urlLink(input));
    if (isSystemSet(d.data_type)) {
      input.disabled = true;
      input.title = "Set by the system";
      readOnly.add(id);
    } else {
      const remove = el("button", { type: "button", className: "dialog-image-remove", textContent: "×" });
      remove.setAttribute("aria-label", `Clear ${d.property_name}`);
      remove.title = removeTitle;
      row.append(remove);
      remove.addEventListener("click", () => {
        rows.delete(id);
        row.remove();
        renderEmpty();
        onChange();
        onCommit?.();
      });
      input.addEventListener("input", onChange);
      if (onCommit) {
        input.addEventListener("change", onCommit);
        input.addEventListener("keydown", (event) => {
          if (event.key !== "Escape") return;
          input.value = original[id] ?? "";
          input.dispatchEvent(new Event("input"));
          input.blur();
        });
      }
    }
    rows.set(id, input);
    list.querySelector(".properties-empty")?.remove();
    list.append(row);
    return input;
  }

  function renderEmpty() {
    if (!rows.size) list.replaceChildren(el("p", { className: "properties-empty", textContent: "No properties." }));
  }

  async function load(properties) {
    const defs = await api("GET", "/api/property-definitions");
    definitions = new Map(defs.map((d) => [d.id, d]));
    original = { ...properties };
    rows = new Map();
    readOnly = new Set();
    list.replaceChildren();
    const ids = Object.keys(properties).sort((a, b) =>
      (definitions.get(a)?.property_name ?? "").localeCompare(definitions.get(b)?.property_name ?? "", undefined, { sensitivity: "base" }),
    );
    for (const id of ids) if (definitions.has(id)) addRow(id, properties[id]);
    renderEmpty();
    closeAdder();
  }

  // Both leave out system-set values, which users can't change.
  function changes() {
    const result = {};
    for (const [id, input] of rows) {
      if (readOnly.has(id)) continue;
      const value = input.value.trim();
      if (value !== (original[id] ?? "")) result[id] = value;
    }
    for (const id of Object.keys(original)) if (!rows.has(id)) result[id] = "";
    return result;
  }

  function markSaved(saved) {
    for (const [id, value] of Object.entries(saved)) {
      if (value === "") delete original[id];
      else original[id] = value;
    }
  }

  function values() {
    const result = {};
    for (const [id, input] of rows) {
      const value = input.value.trim();
      if (value && !readOnly.has(id)) result[id] = value;
    }
    return result;
  }

  return { element, load, changes, markSaved, values };
}

// A boolean's value is chosen, never typed, so only true or false can be
// entered. It has an input's value, events, and focus, so rows treat it like
// any other field; "" (Choose…) means no value yet.
function booleanSelect(value) {
  const select = el("select", { className: "input" }, [
    el("option", { value: "", textContent: "Choose…", disabled: true }),
    el("option", { value: "true", textContent: "true" }),
    el("option", { value: "false", textContent: "false" }),
  ]);
  select.value = value;
  return select;
}

// A link opening an http(s) URL value in a new tab, shown while the value is one.
function urlLink(input) {
  const link = el("a", { className: "properties-open", target: "_blank", rel: "noopener noreferrer", textContent: "Open" });
  link.title = "Open in a new tab";
  const update = () => {
    let ok = false;
    try {
      const url = new URL(input.value.trim());
      ok = (url.protocol === "http:" || url.protocol === "https:") && url.host !== "";
    } catch {
      // Not a URL (yet).
    }
    link.hidden = !ok;
    if (ok) link.href = input.value.trim();
    else link.removeAttribute("href");
  };
  input.addEventListener("input", update);
  update();
  return link;
}

function el(tag, props = {}, children = []) {
  const node = Object.assign(document.createElement(tag), props);
  node.append(...children);
  return node;
}
