// Page-level error message, shown in the page's #error element.

export function showError(message) {
  const el = document.getElementById("error");
  el.textContent = message;
  el.hidden = false;
}

export function clearError() {
  const el = document.getElementById("error");
  el.textContent = "";
  el.hidden = true;
}
