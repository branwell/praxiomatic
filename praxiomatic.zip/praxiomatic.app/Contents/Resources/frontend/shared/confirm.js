// Confirmation for actions that can't be undone, such as deleting core data
// (spec: Interaction Model). Cancel, Escape, or clicking outside the window
// answer no; the confirm button answers yes. An action can also require the
// user to type a name (e.g. a board's) before the confirm button is enabled.

let ui = null;

/**
 * Asks the user to confirm an action.
 * @param {object} options
 * @param {string} options.title
 * @param {string} options.message
 * @param {string[]} [options.details] Listed under the message, e.g. what else
 *   the action will delete.
 * @param {string} [options.confirmLabel] The confirm button's label.
 * @param {string} [options.requireText] Text the user must type, exactly
 *   (ignoring surrounding whitespace), before confirming.
 * @returns {Promise<boolean>} Whether the user confirmed.
 */
export function confirmAction({ title, message, details = [], confirmLabel = "Delete", requireText = null }) {
  ui ??= buildDialog();
  ui.title.textContent = title;
  ui.message.textContent = message;
  ui.details.replaceChildren(...details.map((text) => Object.assign(document.createElement("li"), { textContent: text })));
  ui.details.hidden = details.length === 0;
  ui.confirm.textContent = confirmLabel;
  ui.requireText = requireText;
  ui.field.hidden = requireText === null;
  ui.fieldLabel.textContent = `Type “${requireText}” to confirm.`;
  ui.input.value = "";
  ui.confirm.disabled = requireText !== null;
  ui.dialog.returnValue = "";
  ui.dialog.showModal();
  (requireText === null ? ui.cancel : ui.input).focus();
  return new Promise((resolve) => {
    ui.dialog.addEventListener("close", () => resolve(ui.dialog.returnValue === "confirm"), { once: true });
  });
}

function buildDialog() {
  const dialog = document.createElement("dialog");
  dialog.className = "dialog";
  dialog.id = "confirm-dialog";
  dialog.setAttribute("aria-labelledby", "confirm-title");

  const form = document.createElement("form");
  form.className = "dialog-body";
  form.method = "dialog";

  const title = document.createElement("h2");
  title.className = "dialog-title";
  title.id = "confirm-title";
  const message = document.createElement("p");
  message.id = "confirm-message";
  const details = document.createElement("ul");
  details.className = "confirm-details";
  details.id = "confirm-details";

  const field = document.createElement("label");
  field.className = "field";
  const fieldLabel = document.createElement("span");
  const input = Object.assign(document.createElement("input"), {
    className: "input", id: "confirm-input", type: "text", autocomplete: "off", spellcheck: false,
  });
  field.append(fieldLabel, input);

  const actions = document.createElement("div");
  actions.className = "dialog-actions";
  const cancel = Object.assign(document.createElement("button"), {
    className: "btn btn--secondary", id: "confirm-cancel", value: "cancel", textContent: "Cancel",
  });
  const confirm = Object.assign(document.createElement("button"), {
    className: "btn btn--danger", id: "confirm-ok", value: "confirm",
  });
  actions.append(cancel, confirm);
  form.append(title, message, details, field, actions);
  dialog.append(form);
  document.body.append(dialog);

  const matches = () => ui.requireText !== null && input.value.trim() === ui.requireText;
  input.addEventListener("input", () => { confirm.disabled = !matches(); });
  // Enter confirms once the text matches. (Left to the form, Enter would
  // press its first button, Cancel.)
  input.addEventListener("keydown", (event) => {
    if (event.key !== "Enter") return;
    event.preventDefault();
    if (matches()) dialog.close("confirm");
  });

  // A click on the backdrop (outside the window) answers no.
  let pressedOnBackdrop = false;
  dialog.addEventListener("pointerdown", (event) => { pressedOnBackdrop = event.target === dialog; });
  dialog.addEventListener("click", (event) => {
    if (event.target === dialog && pressedOnBackdrop) dialog.close();
    pressedOnBackdrop = false;
  });

  return { dialog, title, message, details, field, fieldLabel, input, cancel, confirm, requireText: null };
}
