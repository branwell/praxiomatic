// Page help: a "?" button in the page header shows or hides the page's help
// panel, written in the page's HTML (an <aside class="help-panel" hidden>). The
// panel sits at the right of the window and isn't modal, so the page stays in
// use (shortcuts included) while it's open. Its × or the "?" closes it.

/**
 * Wires a help button to its panel.
 * @param {HTMLButtonElement} button
 * @param {HTMLElement} panel Holds a button with class help-close.
 */
export function enableHelp(button, panel) {
  const show = (open) => {
    panel.hidden = !open;
    button.setAttribute("aria-expanded", String(open));
  };
  show(false);
  button.addEventListener("click", () => show(panel.hidden));
  panel.querySelector(".help-close").addEventListener("click", () => {
    show(false);
    button.focus();
  });
}
