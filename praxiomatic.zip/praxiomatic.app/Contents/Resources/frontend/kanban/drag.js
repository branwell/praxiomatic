// Drag and drop for cards and lists, using the browser's native drag and drop.
//
// Cards: where a card is dropped decides what happens:
// - on a list: the card moves there (reorder, or move to another list);
// - on the Delete zone: the card's node is deleted, with every card showing it;
// - anywhere else on the page: the card is removed from the board (its node is kept).
// While dragging, a dashed placeholder shows where the card will land. Off a
// list or over the Delete zone, the placeholder stays where it last was and
// turns red, labelled with what will happen to the card. The Delete zone is
// shown only while a card is being dragged.
//
// Lists: a list is dragged by its header, and the whole list (cards and all) is
// what moves under the pointer. It drops anywhere to land where its placeholder
// is, which is the same size as the list. Lists are only reordered; they can't
// be removed by dragging.
//
// Escape, or releasing outside the window, cancels. Changes show immediately;
// if saving fails the card or list is put back and an error shown.
//
// Listeners are attached to the document once, so lists and cards added later
// work without extra setup.

/**
 * @param {object} options
 * @param {HTMLElement} options.deleteZone Drop target for deleting cards.
 * @param {(cardId: string, listId: string, beforeCardId: string|null) => Promise<void>} options.onMove
 *   Saves a card move; beforeCardId null means the end of the list.
 * @param {(cardId: string) => Promise<void>} options.onRemove Takes a card off the board.
 * @param {(nodeId: string) => Promise<void>} options.onDelete Deletes a card's node.
 * @param {(listId: string, beforeListId: string|null) => Promise<void>} options.onMoveList
 *   Saves a list move; beforeListId null means the right end.
 * @param {(action: string, error: Error) => void} options.onError Called if saving fails,
 *   after the card or list is put back; action is "move", "remove", "delete", or "move-list".
 */
export function enableDragging({ deleteZone, onMove, onRemove, onDelete, onMoveList, onError }) {
  let dragged = null; // the card or list element being dragged
  let kind = null; // "card" or "list"
  let origin = null; // where it came from: { parent, next }

  const cardPlaceholder = document.createElement("li");
  cardPlaceholder.className = "card-placeholder";
  cardPlaceholder.setAttribute("aria-hidden", "true");

  const listPlaceholder = document.createElement("div");
  listPlaceholder.className = "list-placeholder";
  listPlaceholder.setAttribute("aria-hidden", "true");

  // A list header is a drag handle, except while its name is being typed in,
  // so text in the name field can still be selected with the mouse.
  document.addEventListener("pointerdown", (event) => {
    const header = event.target.closest?.(".list-title");
    if (header) header.draggable = !event.target.closest("input, textarea");
  });

  document.addEventListener("dragstart", (event) => {
    const card = event.target.closest?.(".card");
    const header = card ? null : event.target.closest?.(".list-title");
    const element = card ?? header?.closest(".list");
    if (!element) return;

    dragged = element;
    kind = card ? "card" : "list";
    origin = { parent: element.parentElement, next: element.nextElementSibling };
    event.dataTransfer.effectAllowed = "move";
    // Some browsers only start a drag when data is set.
    event.dataTransfer.setData("text/plain", card ? card.querySelector(".card-title").textContent : header.textContent);
    if (kind === "list") {
      // Drag the whole list, cards and all, not just the header that was
      // grabbed, keeping the grab point under the pointer. The placeholder
      // takes the list's exact size so nothing collapses.
      const box = element.getBoundingClientRect();
      event.dataTransfer.setDragImage(element, event.clientX - box.left, event.clientY - box.top);
      listPlaceholder.style.setProperty("--placeholder-height", `${box.height}px`);
    }
    // Change the page after the browser has captured the drag image.
    requestAnimationFrame(() => {
      if (dragged !== element) return;
      element.classList.add("dragging");
      if (kind === "card") document.body.classList.add("dragging-card");
    });
  });

  document.addEventListener("dragover", (event) => {
    if (!dragged) return;
    event.preventDefault(); // allows dropping anywhere on the page
    event.dataTransfer.dropEffect = "move";

    if (kind === "list") {
      placeList(event.clientX);
      return;
    }

    const target = cardDropTarget(event.target);
    deleteZone.classList.toggle("is-active", target.action === "delete");
    cardPlaceholder.classList.toggle("is-remove", target.action === "remove");
    cardPlaceholder.classList.toggle("is-delete", target.action === "delete");
    if (target.action === "move") {
      placeCard(target.list, event.clientY);
    } else if (!cardPlaceholder.isConnected) {
      // Off a list the placeholder stays where it last was; it only needs a
      // spot if the card never passed over a list position.
      origin.parent.insertBefore(cardPlaceholder, origin.next);
    }
  });

  document.addEventListener("drop", async (event) => {
    if (!dragged) return;
    event.preventDefault();

    const element = dragged;
    const from = origin;
    const save = async (action, request) => {
      try {
        await request();
      } catch (error) {
        from.parent.insertBefore(element, from.next);
        onError(action, error);
      }
    };

    if (kind === "list") {
      if (!listPlaceholder.isConnected) return reset();
      listPlaceholder.replaceWith(element);
      reset();
      if (element.nextElementSibling === from.next) return;
      const next = element.nextElementSibling;
      const beforeListId = next?.classList.contains("list") ? next.dataset.listId : null;
      await save("move-list", () => onMoveList(element.dataset.listId, beforeListId));
      return;
    }

    const target = cardDropTarget(event.target);
    if (target.action === "move") {
      cardPlaceholder.replaceWith(element);
      reset();
      if (element.parentElement === from.parent && element.nextElementSibling === from.next) return;
      const beforeCardId = element.nextElementSibling?.dataset.cardId ?? null;
      await save("move", () => onMove(element.dataset.cardId, target.list.dataset.listId, beforeCardId));
      return;
    }

    reset();
    element.remove();
    if (target.action === "delete") {
      await save("delete", () => onDelete(element.dataset.nodeId));
    } else {
      await save("remove", () => onRemove(element.dataset.cardId));
    }
  });

  // Fires after a drop, or when a drag is cancelled.
  document.addEventListener("dragend", reset);

  function reset() {
    cardPlaceholder.remove();
    cardPlaceholder.classList.remove("is-remove", "is-delete");
    listPlaceholder.remove();
    dragged?.classList.remove("dragging");
    document.body.classList.remove("dragging-card");
    deleteZone.classList.remove("is-active");
    dragged = null;
    kind = null;
    origin = null;
  }

  function cardDropTarget(element) {
    if (deleteZone.contains(element)) return { action: "delete" };
    const list = element.closest?.(".list");
    if (list) return { action: "move", list };
    return { action: "remove" };
  }

  function placeCard(list, y) {
    const cards = list.querySelector(".cards");
    const next = cardBelow(cards, y);
    if (next) {
      if (cardPlaceholder.nextElementSibling !== next) cards.insertBefore(cardPlaceholder, next);
    } else if (cardPlaceholder.parentElement !== cards || cardPlaceholder.nextElementSibling) {
      cards.append(cardPlaceholder);
    }
  }

  // Lists are placed by the pointer's horizontal position: before the first
  // list whose midpoint is to its right, otherwise after the last list.
  function placeList(x) {
    const container = origin.parent;
    let next = null;
    for (const list of container.querySelectorAll(".list")) {
      if (list === dragged) continue;
      const box = list.getBoundingClientRect();
      if (x < box.left + box.width / 2) {
        next = list;
        break;
      }
    }
    // After the last list means before "+ Add list", which always stays last.
    next ??= container.querySelector(".add-list");
    if (listPlaceholder.parentElement !== container || listPlaceholder.nextElementSibling !== next) {
      container.insertBefore(listPlaceholder, next);
    }
  }

  // The first card whose vertical midpoint is below y, ignoring the dragged
  // card and cards hidden by the filter.
  function cardBelow(cards, y) {
    for (const card of cards.querySelectorAll(".card:not([hidden])")) {
      if (card === dragged) continue;
      const box = card.getBoundingClientRect();
      if (y < box.top + box.height / 2) return card;
    }
    return null;
  }
}
