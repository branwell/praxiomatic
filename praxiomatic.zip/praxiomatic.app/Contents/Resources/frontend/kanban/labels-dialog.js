// Card colours window: sets the colour and optional name of each of a board's
// ten colour labels, one row per key (1–9, then 0). Save sends them all in one
// request; Cancel, Escape, or clicking outside the window close it without
// saving. If saving fails, the window stays open with the edits and an error.

import { api } from "../shared/api.js";

// Built on first use and reused.
let ui = null;

// The board being edited and how the window ends: { boardId, resolve }.
let current = null;

/** The key that toggles a label: 1–9, and 0 for slot 10. */
export const labelKey = (slot) => String(slot % 10);

/**
 * Opens the window for a board's labels.
 * @param {string} boardId
 * @param {{id: string, slot: number, color: string, label_name: string|null}[]} labels By slot.
 * @returns {Promise<object[]|null>} The saved labels, or null if closed without saving.
 */
export function openLabelsDialog(boardId, labels) {
  ui ??= buildDialog();
  setError("");
  ui.rows.replaceChildren(...labels.map(labelRow));
  return new Promise((resolve) => {
    current = { boardId, resolve };
    ui.dialog.showModal();
    ui.rows.querySelector("input")?.focus();
  });
}

function labelRow(label) {
  const key = labelKey(label.slot);
  const color = el("input", { type: "color", className: "labels-color", value: label.color });
  color.setAttribute("aria-label", `Colour for key ${key}`);
  const name = el("input", {
    type: "text",
    className: "input",
    value: label.label_name ?? "",
    maxLength: 64,
    placeholder: "Name (optional)",
  });
  name.setAttribute("aria-label", `Name for key ${key}`);
  const row = el("li", { className: "labels-row" }, [el("kbd", { className: "labels-key", textContent: key }), color, name]);
  row.dataset.labelId = label.id;
  return row;
}

function buildDialog() {
  const dialog = el("dialog", { className: "dialog", id: "labels-dialog" });
  dialog.setAttribute("aria-labelledby", "labels-title");

  const form = el("form", { className: "dialog-body", noValidate: true });
  const heading = el("h2", { className: "dialog-title", id: "labels-title", textContent: "Card colours" });
  const help = el("p", {
    className: "field-help",
    textContent: "Point at a card and press a key to put its colour on the card or take it off.",
  });
  const error = el("p", { className: "alert alert--error", hidden: true });
  error.setAttribute("role", "alert");
  const rows = el("ol", { className: "labels-rows" });

  const cancel = el("button", { type: "button", className: "btn btn--secondary", textContent: "Cancel" });
  const save = el("button", { type: "submit", className: "btn btn--primary", textContent: "Save" });

  form.append(heading, help, error, rows, el("div", { className: "dialog-actions" }, [cancel, save]));
  dialog.append(form);
  document.body.append(dialog);

  form.addEventListener("submit", async (event) => {
    event.preventDefault();
    if (!dialog.open || save.disabled) return;
    save.disabled = true;
    setError("");
    try {
      const { labels } = await api("PATCH", `/api/kanban/boards/${encodeURIComponent(current.boardId)}/labels`, {
        labels: [...rows.children].map((row) => {
          const [color, name] = row.querySelectorAll("input");
          return { id: row.dataset.labelId, color: color.value, label_name: name.value };
        }),
      });
      finish(labels);
    } catch (err) {
      setError(`Could not save the colours. ${err.message}`);
    } finally {
      save.disabled = false;
    }
  });

  cancel.addEventListener("click", () => dialog.close());
  // Closing any other way (Escape, Cancel, the backdrop) saves nothing.
  dialog.addEventListener("close", () => finish(null));

  // Clicking the backdrop closes the dialog, but only if the press started
  // there too (a text selection can end outside the window).
  let pressedOnBackdrop = false;
  dialog.addEventListener("pointerdown", (event) => {
    pressedOnBackdrop = event.target === dialog;
  });
  dialog.addEventListener("click", (event) => {
    if (event.target === dialog && pressedOnBackdrop) dialog.close();
    pressedOnBackdrop = false;
  });

  return { dialog, error, rows };
}

// Resolves the open window's promise once, then closes it.
function finish(labels) {
  if (!current) return;
  const { resolve } = current;
  current = null;
  resolve(labels);
  if (ui.dialog.open) ui.dialog.close();
}

function el(tag, props = {}, children = []) {
  const node = Object.assign(document.createElement(tag), props);
  node.append(...children);
  return node;
}

function setError(message) {
  ui.error.textContent = message;
  ui.error.hidden = !message;
}
