// Inline-editable names (board and list names). Kanban's, since the blank-name
// rule ("Untitled") is Kanban's.
//
// Following the Interaction Model, a name is renamed by double-clicking it or
// choosing Rename from a menu (which calls startEditing). A text box replaces
// the name: Enter or leaving the box saves, Escape cancels. Names can't be
// blank: an empty name becomes "Untitled", matching the server's rule.

const DEFAULT_NAME = "Untitled";
const MAX_NAME_LENGTH = 256;

/**
 * Creates an editable name.
 * @param {object} options
 * @param {string} options.value Current name.
 * @param {string} options.label What is being named, for screen readers, e.g. "board".
 * @param {(name: string) => Promise<string>} options.onSave Saves the name and
 *   resolves to the name as stored by the server.
 * @param {(error: Error) => void} options.onError Called if saving fails; the
 *   previous name is restored first.
 * @param {(name: string) => void} [options.onChange] Called whenever the shown name changes.
 * @param {boolean} [options.renameOnDoubleClick] False where double-click means
 *   something else (a board tile opens its board); rename then comes from a menu.
 * @returns {{element: HTMLElement, startEditing: () => void}}
 */
export function editableName({ value, label, onSave, onError, onChange = () => {}, renameOnDoubleClick = true }) {
  const name = document.createElement("span");
  name.className = "editable";
  setName(value);
  if (renameOnDoubleClick) {
    name.title = "Double-click to rename";
    name.addEventListener("dblclick", startEditing);
  }
  return { element: name, startEditing };

  function setName(text) {
    name.textContent = text;
    name.setAttribute("aria-label", `${text} (${label} name)`);
    onChange(text);
  }

  function startEditing() {
    if (!name.isConnected) return;
    const input = document.createElement("input");
    input.type = "text";
    input.className = "editable-input";
    input.value = name.textContent;
    input.maxLength = MAX_NAME_LENGTH;
    input.setAttribute("aria-label", `${label} name`);

    let finished = false;
    input.addEventListener("keydown", (event) => {
      if (event.key === "Enter") {
        event.preventDefault();
        finish(true);
      } else if (event.key === "Escape") {
        event.preventDefault();
        finish(false);
      }
      // Keys typed here are for the box, not the page.
      event.stopPropagation();
    });
    input.addEventListener("blur", () => finish(true));
    // Clicks in the box (e.g. to place the cursor) aren't page clicks.
    for (const type of ["click", "dblclick", "contextmenu"]) input.addEventListener(type, (event) => event.stopPropagation());

    name.replaceWith(input);
    input.focus();
    input.select();

    async function finish(save) {
      // Swapping the input out of the page can fire blur after Enter/Escape.
      if (finished) return;
      finished = true;

      const previous = name.textContent;
      const next = input.value.trim() || DEFAULT_NAME;
      input.replaceWith(name);
      if (!save || next === previous) return;

      // Show the new name immediately; restore the old one if saving fails.
      setName(next);
      try {
        setName(await onSave(next));
      } catch (error) {
        setName(previous);
        onError(error);
      }
    }
  }
}
