// Board page: shows one board, its lists, and their cards, following the
// Interaction Model (spec):
// - Cards: double-click opens the card's node; right-click for Open, Remove
//   from board, and Delete card and its data. ⌘/Ctrl+click selects cards to
//   act on together (a plain click does nothing); Delete removes the selected
//   cards from the board. Cards are added at the bottom of a list, and dragged
//   to move, remove, or delete them. Pointing at a card and pressing 1–9 or 0
//   toggles that colour label on it (on the whole selection, if it's selected).
// - Lists: double-click the name (or right-click, Rename) to rename; drag the
//   header to reorder; right-click, Delete list… to delete one. "+ Add list" adds one to the right of the last list.
// - The board name: double-click (or right-click, Rename) to rename it.
//   "Colours" (or right-click, Card colours…) sets the board's label colours.
// - The filter box (F jumps to it) hides cards whose title doesn't contain
//   what's typed.

import { api } from "../shared/api.js";
import { confirmAction } from "../shared/confirm.js";
import { imageIcon } from "../shared/icons.js";
import { openContextMenu } from "../shared/context-menu.js";
import { isShortcutBlocked, onSelectionKeys } from "../shared/keys.js";
import { confirmNodeDelete } from "../shared/node-delete.js";
import { openNodeDialog } from "../shared/node-dialog.js";
import { createSelection, isAdditive } from "../shared/selection.js";
import { enableDragging } from "./drag.js";
import { editableName } from "./editable.js";
import { labelKey, openLabelsDialog } from "./labels-dialog.js";
import { showError, clearError } from "../shared/ui.js";

const titleEl = document.getElementById("board-title");
const listsEl = document.getElementById("lists");
const labelsButton = document.getElementById("labels-button");
const filterInput = document.getElementById("card-filter");

// Cards selected to act on together (with ⌘/Ctrl+click).
const selection = createSelection();
// Rename functions for each list section and the board name.
const renamers = new WeakMap();
// The board's id and its colour labels, by slot.
let boardId = null;
let labels = [];
// Each card's labels: card element → Set of label ids.
const cardLabelIds = new WeakMap();

function renderBoard(board) {
  boardId = board.id;
  labels = board.labels;
  labelsButton.hidden = false;
  filterInput.hidden = false;
  const name = editableName({
    value: board.board_name,
    label: "board",
    onSave: async (value) => {
      clearError();
      const saved = await api("PATCH", `/api/kanban/boards/${encodeURIComponent(board.id)}`, { board_name: value });
      return saved.board_name;
    },
    onError: (error) => showError(`Could not rename the board. ${error.message}`),
    onChange: (value) => {
      document.title = `${value} · Parallax`;
    },
  });
  renamers.set(titleEl, name.startEditing);
  titleEl.replaceChildren(name.element);

  listsEl.replaceChildren(...board.lists.map(renderList), addListButton(board));
}

// "+ Add list" sits to the right of the last list. It creates an "Untitled"
// list, then opens the new list's name for editing so the user can type one.
function addListButton(board) {
  const button = document.createElement("button");
  button.type = "button";
  button.className = "add-list";
  button.textContent = "+ Add list";

  button.addEventListener("click", async () => {
    clearError();
    button.disabled = true;
    try {
      const list = await api("POST", `/api/kanban/boards/${encodeURIComponent(board.id)}/lists`);
      const section = renderList(list);
      button.before(section);
      renamers.get(section)();
    } catch (error) {
      showError(`Could not add a list. ${error.message}`);
    } finally {
      button.disabled = false;
    }
  });
  return button;
}

function renderList(list) {
  const section = document.createElement("section");
  section.className = "list";
  section.dataset.listId = list.id;
  section.dataset.kind = "list";

  // The header selects the list and is its drag handle.
  const title = document.createElement("h2");
  title.className = "list-title";
  title.draggable = true;
  const name = editableName({
    value: list.list_name,
    label: "list",
    onSave: async (value) => {
      clearError();
      const saved = await api("PATCH", `/api/kanban/lists/${encodeURIComponent(list.id)}`, { list_name: value });
      return saved.list_name;
    },
    onError: (error) => showError(`Could not rename the list. ${error.message}`),
  });
  renamers.set(section, name.startEditing);
  title.append(name.element);

  const cards = document.createElement("ol");
  cards.className = "cards";
  cards.setAttribute("aria-label", "Cards");
  cards.append(...list.cards.map(renderCard));

  section.append(title, cards, cardComposer(list, cards));
  return section;
}

function renderCard(card) {
  const item = document.createElement("li");
  item.className = "card";
  item.dataset.cardId = card.id;
  item.dataset.nodeId = card.node_id;
  item.dataset.kind = "card";
  item.draggable = true;
  const title = document.createElement("span");
  title.className = "card-title";
  item.append(title);
  cardLabelIds.set(item, new Set(card.label_ids));
  renderCardLabels(item);
  setCardTitle(item, card.title);
  setCardImages(item, card.image_count);
  return item;
}

function setCardTitle(item, title) {
  item.querySelector(".card-title").textContent = title;
}

const cardTitle = (item) => item.querySelector(".card-title").textContent;

// A bar along the top of the card for each of its labels, by slot. The row is
// there only when the card has labels.
function renderCardLabels(item) {
  item.querySelector(".card-labels")?.remove();
  const ids = cardLabelIds.get(item);
  const bars = labels.filter((label) => ids.has(label.id)).map(labelBar);
  if (!bars.length) return;
  const row = document.createElement("span");
  row.className = "card-labels";
  row.append(...bars);
  item.prepend(row);
}

function labelBar(label) {
  const bar = document.createElement("span");
  bar.className = "card-label";
  // The colour is the user's data, so it's passed to the stylesheet as a variable.
  bar.style.setProperty("--label-color", label.color);
  const key = labelKey(label.slot);
  bar.title = label.label_name ? `${label.label_name} (key ${key})` : `Key ${key}`;
  return bar;
}

// A picture icon in the card's indicator row when its node has images
// attached. The row runs along the bottom of the card and is there only when
// it holds an indicator.
function setCardImages(item, count) {
  item.querySelector(".card-indicator-images")?.remove();
  if (count) {
    const indicator = document.createElement("span");
    indicator.className = "card-indicator card-indicator-images";
    indicator.title = "Has images";
    indicator.append(imageIcon("card-indicator-icon"));
    cardIndicators(item).append(indicator);
  }
  const row = item.querySelector(".card-indicators");
  if (row && !row.children.length) row.remove();
}

// The card's indicator row, created if missing.
function cardIndicators(item) {
  let row = item.querySelector(".card-indicators");
  if (!row) {
    row = document.createElement("span");
    row.className = "card-indicators";
    item.append(row);
  }
  return row;
}

// "+ Add a card": a button that opens a text box at the bottom of the list.
// Enter adds the card and keeps the box open for the next one; Escape, or
// leaving an empty box, closes it. Leaving with text adds it first.
function cardComposer(list, cardsEl) {
  const wrapper = document.createElement("div");

  const openButton = document.createElement("button");
  openButton.type = "button";
  openButton.className = "add-card";
  openButton.textContent = "+ Add a card";

  const input = document.createElement("textarea");
  input.className = "card-input";
  input.rows = 2;
  input.maxLength = 256;
  input.placeholder = "Enter a title for this card";
  input.setAttribute("aria-label", "New card title");

  const hint = document.createElement("p");
  hint.className = "card-hint";
  hint.textContent = "Enter to add · Esc to close";

  let saving = false;

  function open() {
    wrapper.replaceChildren(input, hint);
    input.focus();
  }

  function close() {
    input.value = "";
    wrapper.replaceChildren(openButton);
  }

  async function add() {
    // Titles are single-line; collapse pasted line breaks and runs of spaces.
    const title = input.value.replace(/\s+/g, " ").trim();
    if (!title || saving) return false;
    saving = true;
    clearError();
    try {
      const card = await api("POST", `/api/kanban/lists/${encodeURIComponent(list.id)}/cards`, { title });
      cardsEl.append(renderCard(card));
      input.value = "";
      return true;
    } catch (error) {
      // Keep the typed text so nothing is lost.
      showError(`Could not add the card. ${error.message}`);
      return false;
    } finally {
      saving = false;
    }
  }

  openButton.addEventListener("click", open);
  input.addEventListener("keydown", async (event) => {
    if (event.key === "Enter") {
      // Titles are single-line; Enter submits rather than adding a newline.
      event.preventDefault();
      await add();
      input.focus();
    } else if (event.key === "Escape") {
      close();
      openButton.focus();
    }
  });
  input.addEventListener("blur", async () => {
    if (saving || !input.isConnected) return;
    if (input.value.trim() === "" || (await add())) close();
  });

  wrapper.append(openButton);
  return wrapper;
}

// Cards are dragged to reorder or move them, off a list to remove them from the
// board (keeping their node), or onto the Delete zone to delete their node.
// Lists are dragged by their header to reorder them.
const failedAction = {
  move: "Could not move the card.",
  remove: "Could not remove the card from the board.",
  delete: "Could not delete the card.",
  "move-list": "Could not move the list.",
};
enableDragging({
  deleteZone: document.getElementById("delete-zone"),
  onMove: async (cardId, listId, beforeCardId) => {
    clearError();
    await api("POST", `/api/kanban/cards/${encodeURIComponent(cardId)}/move`, {
      list_id: listId,
      before_card_id: beforeCardId,
    });
  },
  onRemove: async (cardId) => {
    clearError();
    await api("DELETE", `/api/kanban/cards/${encodeURIComponent(cardId)}`);
  },
  onDelete: async (nodeId) => {
    clearError();
    await api("DELETE", `/api/nodes/${encodeURIComponent(nodeId)}`);
  },
  onMoveList: async (listId, beforeListId) => {
    clearError();
    await api("POST", `/api/kanban/lists/${encodeURIComponent(listId)}/move`, { before_list_id: beforeListId });
  },
  onError: (action, error) => showError(`${failedAction[action]} ${error.message}`),
});

// ---------------------------------------------------------------------------
// Selecting, opening, removing, and right-click menus
// ---------------------------------------------------------------------------

// ⌘/Ctrl+click adds a card to the selection or removes it. Any other click
// clears the selection, except on controls (buttons, inputs) and in dialogs.
// (A drag never produces a click.)
document.addEventListener("click", (event) => {
  const card = event.target.closest(".card");
  if (card && isAdditive(event)) selection.click(card, event);
  else if (!event.target.closest("button, input, textarea, a, dialog, .context-menu")) selection.clear();
});

// Double-clicking a card opens it. (Double-clicking a list's name renames it,
// handled by the name itself.)
listsEl.addEventListener("dblclick", (event) => {
  const card = event.target.closest(".card");
  if (card) openCard(card);
});

async function openCard(card) {
  clearError();
  try {
    await openNodeDialog(card.dataset.nodeId, (node, images) => {
      // Every card showing this node displays its title and images.
      for (const el of listsEl.querySelectorAll(".card")) {
        if (el.dataset.nodeId !== node.id) continue;
        setCardTitle(el, node.title);
        setCardImages(el, images.count);
      }
    });
  } catch (error) {
    showError(`Could not open the card. ${error.message}`);
  }
}

// Takes cards off the page now, then saves: each group's request removes its
// cards. If a group's request fails, its cards go back where they were and
// message is shown.
async function removeCards(groups, message) {
  const places = new Map();
  for (const { cards } of groups) {
    for (const card of cards) {
      places.set(card, { parent: card.parentElement, next: card.nextElementSibling });
      selection.forget(card);
      card.remove();
    }
  }
  clearError();
  const results = await Promise.allSettled(groups.map((group) => group.request()));
  const failed = results.flatMap((result, i) => (result.status === "rejected" ? [{ ...groups[i], error: result.reason }] : []));
  for (const { cards } of failed) {
    for (const card of [...cards].reverse()) {
      const { parent, next } = places.get(card);
      parent.insertBefore(card, next?.isConnected ? next : null);
    }
  }
  if (failed.length) showError(`${message} ${failed[0].error.message}`);
}

// Remove from board: the cards go; their nodes are kept.
function removeFromBoard(cards) {
  return removeCards(
    cards.map((card) => ({
      cards: [card],
      request: () => api("DELETE", `/api/kanban/cards/${encodeURIComponent(card.dataset.cardId)}`),
    })),
    cards.length === 1 ? "Could not remove the card from the board." : "Could not remove some cards from the board.",
  );
}

// Delete card and its data: after confirming (listing what else goes with the
// cards' nodes: their edges, and other cards showing them), the nodes are
// deleted, with their edges and every card showing them.
async function deleteCardData(cards) {
  const nodeIds = [...new Set(cards.map((card) => card.dataset.nodeId))];
  let confirmed;
  try {
    confirmed = await confirmNodeDelete({
      nodeIds,
      title: cards.length === 1 ? "Delete card" : "Delete cards",
      question: cards.length === 1 ? `Delete “${cardTitle(cards[0])}” and its data?` : `Delete ${cards.length} cards and their data?`,
      alreadyCounted: { "Kanban card": cards.length },
    });
  } catch (error) {
    showError(`Could not delete the card. ${error.message}`);
    return;
  }
  if (!confirmed) return;
  const all = [...listsEl.querySelectorAll(".card")];
  await removeCards(
    nodeIds.map((id) => ({
      cards: all.filter((card) => card.dataset.nodeId === id),
      request: () => api("DELETE", `/api/nodes/${encodeURIComponent(id)}`),
    })),
    cards.length === 1 ? "Could not delete the card." : "Could not delete some cards.",
  );
}

// Delete list: the list goes with its cards; their nodes are kept. A list
// with cards asks first; an empty one goes at once.
async function deleteList(section) {
  const cards = [...section.querySelectorAll(".card")];
  if (cards.length > 0) {
    const name = section.querySelector(".list-title").textContent.trim();
    const confirmed = await confirmAction({
      title: "Delete list",
      message: `Delete “${name}”? This can't be undone.`,
      details: [`${cards.length} ${cards.length === 1 ? "card" : "cards"} will also be deleted (their nodes are kept).`],
    });
    if (!confirmed) return;
  }
  clearError();
  try {
    await api("DELETE", `/api/kanban/lists/${encodeURIComponent(section.dataset.listId)}`);
    for (const card of cards) selection.forget(card);
    section.remove();
  } catch (error) {
    showError(`Could not delete the list. ${error.message}`);
  }
}

// ---------------------------------------------------------------------------
// Filtering cards
// ---------------------------------------------------------------------------

// As the user types, cards whose title doesn't contain the text (ignoring
// case and surrounding whitespace) are hidden; lists stay. It's applied only
// when the text changes, so a card just added or renamed stays in view.
// Hidden cards leave the selection, so actions never reach cards out of view.
function applyFilter() {
  const text = filterInput.value.trim().toLowerCase();
  for (const card of listsEl.querySelectorAll(".card")) {
    card.hidden = text !== "" && !cardTitle(card).toLowerCase().includes(text);
    if (card.hidden) selection.forget(card);
  }
}

filterInput.addEventListener("input", applyFilter);
// F jumps to the filter box, selecting its text so typing replaces it.
document.addEventListener("keydown", (event) => {
  if (event.key !== "f" || event.altKey || event.ctrlKey || event.metaKey) return;
  if (isShortcutBlocked(event) || filterInput.hidden) return;
  event.preventDefault();
  filterInput.focus();
  filterInput.select();
});
// Escape clears the filter (some browsers don't do this for search boxes).
filterInput.addEventListener("keydown", (event) => {
  if (event.key !== "Escape" || !filterInput.value) return;
  event.preventDefault();
  filterInput.value = "";
  applyFilter();
});

// ---------------------------------------------------------------------------
// Colour labels
// ---------------------------------------------------------------------------

// Label saves are sent one at a time, in order, so quick repeated presses
// are saved in the order they were made.
let labelSaves = Promise.resolve();

// Toggles a label on cards: if any of them lacks it, all get it; otherwise it
// comes off all of them. The change shows now; if saving fails it's undone
// and an error is shown.
function toggleLabel(label, cards) {
  const applied = cards.some((card) => !cardLabelIds.get(card).has(label.id));
  const changed = cards.filter((card) => cardLabelIds.get(card).has(label.id) !== applied);
  const show = (on) => {
    for (const card of changed) {
      const ids = cardLabelIds.get(card);
      if (on) ids.add(label.id);
      else ids.delete(label.id);
      renderCardLabels(card);
    }
  };
  show(applied);
  clearError();
  labelSaves = labelSaves.then(async () => {
    try {
      await api("POST", `/api/kanban/labels/${encodeURIComponent(label.id)}/cards`, {
        card_ids: changed.map((card) => card.dataset.cardId),
        applied,
      });
    } catch (error) {
      show(!applied);
      showError(`Could not ${applied ? "add" : "remove"} the colour. ${error.message}`);
    }
  });
}

// Keys 1–9 and 0 toggle labels 1–10 on the card under the pointer, or, if
// that card is selected, on the whole selection.
document.addEventListener("keydown", (event) => {
  if (!/^[0-9]$/.test(event.key) || event.altKey || event.ctrlKey || event.metaKey) return;
  if (isShortcutBlocked(event)) return;
  const card = listsEl.querySelector(".card:hover");
  const label = labels.find((l) => labelKey(l.slot) === event.key);
  if (!card || !label) return;
  event.preventDefault();
  toggleLabel(label, selection.has(card) ? selection.items() : [card]);
});

async function editLabels() {
  clearError();
  const saved = await openLabelsDialog(boardId, labels);
  if (!saved) return;
  labels = saved;
  for (const card of listsEl.querySelectorAll(".card")) renderCardLabels(card);
}

labelsButton.addEventListener("click", editLabels);

// The right-click menu for cards: one card, or all the selected cards.
function cardMenu(cards) {
  return [
    ...(cards.length === 1 ? [{ label: "Open", action: () => openCard(cards[0]) }] : []),
    { label: "Remove from board", action: () => removeFromBoard(cards) },
    { label: cards.length === 1 ? "Delete card and its data…" : "Delete cards and their data…", danger: true, action: () => deleteCardData(cards) },
  ];
}

document.addEventListener("contextmenu", (event) => {
  if (event.target.closest("input, textarea")) return;
  const at = { x: event.clientX, y: event.clientY };
  // The board name, and a list's header, offer Rename; the board name also
  // Card colours…, and a list's header Delete list….
  const renamable = titleEl.contains(event.target) ? titleEl : event.target.closest(".list-title")?.closest(".list");
  if (renamable && renamers.has(renamable)) {
    event.preventDefault();
    const items = [{ label: "Rename", action: renamers.get(renamable) }];
    if (renamable === titleEl) items.push({ label: "Card colours…", action: editLabels });
    else items.push({ label: "Delete list…", danger: true, action: () => deleteList(renamable) });
    openContextMenu({ ...at, items });
    return;
  }
  const card = event.target.closest(".card");
  if (!card) return; // no view actions on empty space: the browser's own menu
  event.preventDefault();
  // On a selected card, the menu acts on the whole selection; on any other
  // card, on just that card.
  openContextMenu({ ...at, items: cardMenu(selection.has(card) ? selection.items() : [card]) });
});

onSelectionKeys({
  remove: () => {
    if (selection.items().length) removeFromBoard(selection.items());
  },
  clear: () => selection.clear(),
});

async function loadBoard() {
  const id = new URLSearchParams(window.location.search).get("id");
  if (!id) {
    titleEl.textContent = "No board selected";
    showError("This page needs a board. Choose one from Boards.");
    return;
  }
  try {
    renderBoard(await api("GET", `/api/kanban/boards/${encodeURIComponent(id)}`));
  } catch (error) {
    titleEl.textContent = error.status === 404 ? "Board not found" : "Board unavailable";
    showError(`Could not load the board. ${error.message}`);
  }
}

loadBoard();
