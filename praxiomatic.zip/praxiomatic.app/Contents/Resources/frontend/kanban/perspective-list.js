// Kanban's list-perspectives operation: its boards as tiles on the
// Perspectives page, New › Board, and a board tile's Rename and Delete. The
// page uses it through app/perspectives.js, without knowing about Kanban.

import { api } from "../shared/api.js";
import { confirmAction } from "../shared/confirm.js";
import { icon } from "../shared/icons.js";
import { editableName } from "./editable.js";

function boardURL(id) {
  return `/kanban/board.html?id=${encodeURIComponent(id)}`;
}

function boardPath(id) {
  return `/api/kanban/boards/${encodeURIComponent(id)}`;
}

function plural(count, singular, pluralName) {
  return `${count} ${count === 1 ? singular : pluralName}`;
}

// Deleting a board deletes its lists and cards but keeps the cards' nodes. The
// user confirms by typing the board's name.
async function deleteBoard(item, page) {
  let board;
  try {
    board = await api("GET", boardPath(item.id));
  } catch (error) {
    page.showError(`Could not delete the board. ${error.message}`);
    return;
  }
  const cards = board.lists.reduce((sum, list) => sum + list.cards.length, 0);
  const details = [`${plural(board.lists.length, "list", "lists")} will also be deleted.`];
  if (cards > 0) details.push(`${plural(cards, "card", "cards")} will also be deleted (their nodes are kept).`);
  const confirmed = await confirmAction({
    title: "Delete board",
    message: `Delete “${board.board_name}”? This can't be undone.`,
    details,
    requireText: board.board_name,
  });
  if (!confirmed) return;
  try {
    await api("DELETE", boardPath(item.id));
    page.remove();
  } catch (error) {
    page.showError(`Could not delete the board. ${error.message}`);
  }
}

/** @type {import("../app/perspectives.js").PerspectiveList} */
export const kanbanPerspectiveList = {
  kind: "Kanban board",
  // Three columns.
  icon: (className) => icon(className, [
    ["rect", { x: 3, y: 4, width: 5, height: 16, rx: 1 }],
    ["rect", { x: 9.5, y: 4, width: 5, height: 11, rx: 1 }],
    ["rect", { x: 16, y: 4, width: 5, height: 7, rx: 1 }],
  ]),
  list: async () => (await api("GET", "/api/kanban/boards"))
    .map((board) => ({ id: board.id, title: board.board_name, url: boardURL(board.id) })),
  // A new board is created as "Untitled" with one "Untitled" list.
  create: {
    label: "Kanban Board",
    run: async () => boardURL((await api("POST", "/api/kanban/boards")).id),
  },
  tile: (item, page) => {
    const name = editableName({
      value: item.title,
      label: "board",
      // Clicking a tile opens its board, so renaming comes from the menu.
      renameOnDoubleClick: false,
      onSave: async (value) => (await api("PATCH", boardPath(item.id), { board_name: value })).board_name,
      onError: (error) => page.showError(`Could not rename the board. ${error.message}`),
    });
    return {
      title: name.element,
      menu: [
        { label: "Rename", action: name.startEditing },
        { label: "Delete board…", action: () => deleteBoard(item, page) },
      ],
    };
  },
};
