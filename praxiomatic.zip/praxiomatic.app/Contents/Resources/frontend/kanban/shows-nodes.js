// Kanban's shows-nodes operation: which nodes are shown as cards, on any
// board. Other views use it through app/perspectives.js, e.g. to highlight
// those nodes, without knowing about Kanban.

import { api } from "../shared/api.js";

/** @type {import("../app/perspectives.js").ShowsNodes} */
export const kanbanShowsNodes = {
  name: "Kanban",
  nodeIds: async () => (await api("GET", "/api/kanban/node-ids")).node_ids,
};
