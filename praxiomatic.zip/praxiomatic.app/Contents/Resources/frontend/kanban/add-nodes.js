// Kanban's add-nodes operation: shows existing nodes as cards. Other views
// offer it through app/perspectives.js, without knowing about Kanban.
//
// A modal window asks for a board and a list, marking those that already
// show the nodes; Add puts a card for each node at the bottom of the list.
// Adding a node that's already there is allowed. Cancel, Escape, or clicking
// outside the window close it without adding. It uses only shared styles,
// since it opens on other perspectives' pages.

import { api } from "../shared/api.js";

/** @type {import("../app/perspectives.js").AddNodes} */
export const kanbanAddNodes = {
  label: (count) => (count === 1 ? "Add to Kanban board…" : `Add ${count} nodes to Kanban board…`),
  add: openAddNodesDialog,
};

// Built on first use and reused.
let ui = null;

// The nodes being added and where they are already shown: { nodes, onBoard,
// onList, done }. onBoard and onList map a board or list id to the set of
// node ids it shows.
let current = null;

// The board and list last chosen on this page, chosen again next time.
let last = { boardId: null, listId: null };

// Each board change loads its lists; only the latest load fills the list box.
let loadCount = 0;

/**
 * Loads the boards and opens the dialog.
 * @param {{id: string, title: string}[]} nodes
 * @returns {Promise<void>} Resolves when the dialog closes.
 * @throws if the boards can't be loaded (the dialog stays closed).
 */
async function openAddNodesDialog(nodes) {
  const query = nodes.map((n) => `node_id=${encodeURIComponent(n.id)}`).join("&");
  const [boards, { cards }] = await Promise.all([api("GET", "/api/kanban/boards"), api("GET", `/api/kanban/cards?${query}`)]);

  ui ??= buildDialog();
  const onBoard = new Map();
  const onList = new Map();
  for (const card of cards) {
    addTo(onBoard, card.board_id, card.node_id);
    addTo(onList, card.list_id, card.node_id);
  }
  current = { nodes, onBoard, onList };

  ui.heading.textContent = nodes.length === 1 ? `Add “${nodes[0].title}” to a board` : `Add ${nodes.length} nodes to a board`;
  setError("");
  ui.empty.hidden = boards.length > 0;
  for (const f of ui.fields) f.hidden = boards.length === 0;
  ui.board.replaceChildren(...boards.map((b) => option(b.id, b.board_name, onBoard.get(b.id))));
  ui.list.replaceChildren();
  ui.add.disabled = true;

  const closed = new Promise((resolve) => ui.dialog.addEventListener("close", resolve, { once: true }));
  ui.dialog.showModal();
  if (boards.length) {
    if (boards.some((b) => b.id === last.boardId)) ui.board.value = last.boardId;
    ui.board.focus();
    await loadLists();
  } else {
    ui.cancel.focus();
  }
  await closed;
}

// Fills the list box with the chosen board's lists.
async function loadLists() {
  const load = ++loadCount;
  ui.list.replaceChildren();
  ui.list.disabled = true;
  ui.add.disabled = true;
  setError("");
  let board;
  try {
    board = await api("GET", `/api/kanban/boards/${encodeURIComponent(ui.board.value)}`);
  } catch (err) {
    if (load === loadCount) setError(`Could not load the board's lists. ${err.message}`);
    return;
  }
  if (load !== loadCount) return;
  ui.list.replaceChildren(...board.lists.map((l) => option(l.id, l.list_name, current.onList.get(l.id))));
  if (board.lists.some((l) => l.id === last.listId)) ui.list.value = last.listId;
  ui.list.disabled = board.lists.length === 0;
  ui.add.disabled = board.lists.length === 0;
}

// A board or list option, marked if it already shows some of the nodes:
// "✓ Name (already here)" for one node, "Name (2 of 3 here)" for several
// (with ✓ when all of them are).
function option(value, name, shown) {
  const total = current.nodes.length;
  const count = shown?.size ?? 0;
  let text = name;
  if (count === total) text = `✓ ${name} (${total === 1 ? "already here" : `all ${total} here`})`;
  else if (count > 0) text = `${name} (${count} of ${total} here)`;
  return Object.assign(document.createElement("option"), { value, textContent: text });
}

function addTo(map, key, value) {
  if (!map.has(key)) map.set(key, new Set());
  map.get(key).add(value);
}

function buildDialog() {
  const dialog = el("dialog", { className: "dialog", id: "add-nodes-dialog" });
  dialog.setAttribute("aria-labelledby", "add-nodes-title");

  const form = el("form", { className: "dialog-body", noValidate: true });
  const heading = el("h2", { className: "dialog-title", id: "add-nodes-title" });
  const error = el("p", { className: "alert alert--error", id: "add-nodes-error", hidden: true });
  error.setAttribute("role", "alert");

  const empty = el("p", { id: "add-nodes-empty" }, [
    "No boards yet. ",
    el("a", { href: "/index.html", textContent: "Create one on the Perspectives page." }),
  ]);
  const board = el("select", { className: "input", id: "add-nodes-board", name: "board" });
  const list = el("select", { className: "input", id: "add-nodes-list", name: "list" });
  const fields = [field("Board", board), field("List", list)];

  const cancel = el("button", { type: "button", className: "btn btn--secondary", id: "add-nodes-cancel", textContent: "Cancel" });
  const add = el("button", { type: "submit", className: "btn btn--primary", id: "add-nodes-add", textContent: "Add" });

  form.append(heading, error, empty, ...fields, el("div", { className: "dialog-actions" }, [cancel, add]));
  dialog.append(form);
  document.body.append(dialog);

  board.addEventListener("change", () => {
    last = { boardId: board.value, listId: null };
    loadLists();
  });
  list.addEventListener("change", () => {
    last.listId = list.value;
  });

  form.addEventListener("submit", async (event) => {
    event.preventDefault();
    if (!dialog.open || add.disabled || !list.value) return;
    add.disabled = true;
    setError("");
    try {
      await api("POST", `/api/kanban/lists/${encodeURIComponent(list.value)}/nodes`, {
        node_ids: current.nodes.map((n) => n.id),
      });
      last = { boardId: board.value, listId: list.value };
      dialog.close();
    } catch (err) {
      // Keep the window open so the user can try again or choose elsewhere.
      setError(`Could not add to the board. ${err.message}`);
    } finally {
      add.disabled = false;
    }
  });

  cancel.addEventListener("click", () => dialog.close());

  // Clicking the backdrop closes the dialog, but only if the press started
  // there too (a text selection can end outside the window).
  let pressedOnBackdrop = false;
  dialog.addEventListener("pointerdown", (event) => {
    pressedOnBackdrop = event.target === dialog;
  });
  dialog.addEventListener("click", (event) => {
    if (event.target === dialog && pressedOnBackdrop) dialog.close();
    pressedOnBackdrop = false;
  });

  return { dialog, heading, error, empty, fields, board, list, cancel, add };
}

function field(label, control) {
  return el("div", { className: "field" }, [
    el("label", { className: "field-label", htmlFor: control.id, textContent: label }),
    control,
  ]);
}

function el(tag, props = {}, children = []) {
  const node = Object.assign(document.createElement(tag), props);
  node.append(...children);
  return node;
}

function setError(message) {
  ui.error.textContent = message;
  ui.error.hidden = !message;
}
