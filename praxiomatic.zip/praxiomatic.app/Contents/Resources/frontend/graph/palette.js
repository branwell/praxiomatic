// Relationship type palette: the graph's list of relationship types, as tags.
//
// - Click a tag to select or deselect it; several can be selected. The graph
//   highlights edges of the selected types, and new edges get those types.
// - Double-click a tag's name to rename it: Enter or leaving the box saves,
//   Escape cancels.
// - Right-click a tag for Rename, Symmetric (checked while the type's edges
//   have no direction; choosing it switches), and Delete….
// - Drag tags to reorder them. A tag's colour follows its position.
// - "×" (or Delete… in the menu) deletes a type and every edge of that type,
//   after confirming.
// Tags toggle on a plain click because they're filters, an exception to the
// Interaction Model's click-to-select (spec).
// - "+ Add relationship type" adds types at the end; Enter keeps the box open
//   for the next one, Escape closes it.
//
// Reorders, renames, and switching Symmetric show immediately; if saving fails
// they are undone and an error is shown.

import { api } from "../shared/api.js";
import { confirmAction } from "../shared/confirm.js";
import { openContextMenu } from "../shared/context-menu.js";
import { showError, clearError } from "../shared/ui.js";

// The seeded default type (spec: Seed data). It can't be deleted.
export const RELATED_TO_ID = "ea272bfa-0775-4290-afd4-ba8ce5016218";
// The seeded attachment type, connecting a node to its images. It can't be deleted either.
const ATTACHMENT_ID = "83366303-f7ad-4a2c-8140-e2138ee98239";
// The seeded source_is type, connecting an imported node to its source. Also built in.
const SOURCE_IS_ID = "e7617eb9-72e8-4440-8af9-9f44d6db5eb7";
// The seeded broader type, from a narrower topic to a broader one. Also built in.
const BROADER_ID = "a4d14461-1cdc-4de2-91b0-60fe35f45516";
const isBuiltIn = (id) => id === RELATED_TO_ID || id === ATTACHMENT_ID || id === SOURCE_IS_ID || id === BROADER_ID;

export const COLOUR_COUNT = 8;
const MAX_NAME_LENGTH = 64;

/**
 * Builds the palette.
 * @param {object} options
 * @param {HTMLOListElement} options.list Where the tags go.
 * @param {HTMLElement} options.composer Where "+ Add relationship type" goes.
 * @param {{id: string, relationship_type_name: string, is_symmetric: boolean}[]} options.types In palette order.
 * @param {(change: {kind: string, typeId?: string}) => void} options.onChange
 *   Called after the selection, order, names, symmetry, or set of types
 *   changes; kind is "select", "order", "rename", "symmetric", "add", or
 *   "delete".
 */
export function createPalette({ list, composer, types, onChange }) {
  const selected = new Set();
  const names = new Map();
  const symmetric = new Set();

  list.replaceChildren(...types.map(renderTag));
  recolour();
  composer.append(addTypeComposer());
  enableReordering();

  return {
    /** The selected types' ids, in palette order. */
    selectedIds: () => tags().map((t) => t.dataset.typeId).filter((id) => selected.has(id)),
    /** A type's colour number (1..COLOUR_COUNT), from its position. */
    colourOf: (id) => {
      const index = tags().findIndex((t) => t.dataset.typeId === id);
      return index < 0 ? null : (index % COLOUR_COUNT) + 1;
    },
    nameOf: (id) => names.get(id) ?? "",
    /** Whether a type's edges have no direction. */
    isSymmetric: (id) => symmetric.has(id),
    /** Every type, in palette order. */
    types: () => tags().map((t) => ({ id: t.dataset.typeId, name: names.get(t.dataset.typeId) ?? "", isSymmetric: symmetric.has(t.dataset.typeId) })),
  };

  function tags() {
    return [...list.querySelectorAll(".palette-tag")];
  }

  function renderTag(type) {
    names.set(type.id, type.relationship_type_name);
    if (type.is_symmetric) symmetric.add(type.id);
    const item = document.createElement("li");
    item.className = "palette-tag";
    item.dataset.typeId = type.id;
    item.draggable = true;

    const toggle = document.createElement("button");
    toggle.type = "button";
    toggle.className = "palette-toggle";
    toggle.setAttribute("aria-pressed", "false");
    const swatch = document.createElement("span");
    swatch.className = "palette-swatch";
    const name = document.createElement("span");
    name.className = "palette-name";
    name.textContent = type.relationship_type_name;
    toggle.append(swatch, name);
    toggle.addEventListener("click", () => {
      const on = !selected.has(type.id);
      if (on) selected.add(type.id);
      else selected.delete(type.id);
      toggle.setAttribute("aria-pressed", String(on));
      onChange({ kind: "select", typeId: type.id });
    });
    name.addEventListener("dblclick", (event) => {
      event.preventDefault();
      startRename(item, name);
    });
    item.addEventListener("contextmenu", (event) => {
      if (event.target.closest("input")) return;
      event.preventDefault();
      openContextMenu({
        x: event.clientX,
        y: event.clientY,
        items: [
          { label: "Rename", action: () => startRename(item, name) },
          { label: "Symmetric", checked: symmetric.has(type.id), action: () => toggleSymmetric(type.id) },
          ...(isBuiltIn(type.id) ? [] : [{ label: "Delete…", danger: true, action: () => confirmDelete(type.id) }]),
        ],
      });
    });
    item.append(toggle);

    if (!isBuiltIn(type.id)) {
      const remove = document.createElement("button");
      remove.type = "button";
      remove.className = "palette-delete";
      remove.textContent = "×";
      remove.setAttribute("aria-label", `Delete relationship type ${type.relationship_type_name}`);
      remove.addEventListener("click", () => confirmDelete(type.id));
      item.append(remove);
    }
    return item;
  }

  // Colours follow position, cycling through the palette's colours.
  function recolour() {
    tags().forEach((tag, i) => {
      for (const c of [...tag.classList]) if (c.startsWith("rel-color-")) tag.classList.remove(c);
      tag.classList.add(`rel-color-${(i % COLOUR_COUNT) + 1}`);
    });
  }

  // ---------------------------------------------------------------------------
  // Renaming
  // ---------------------------------------------------------------------------

  function startRename(item, nameEl) {
    const id = item.dataset.typeId;
    const toggle = item.querySelector(".palette-toggle");
    const input = document.createElement("input");
    input.type = "text";
    input.className = "input palette-rename";
    input.value = names.get(id);
    input.maxLength = MAX_NAME_LENGTH;
    input.setAttribute("aria-label", "Relationship type name");
    toggle.replaceWith(input);
    item.draggable = false; // so the text can be selected with the mouse
    input.focus();
    input.select();

    let finished = false;
    const finish = async (save) => {
      if (finished) return;
      finished = true;
      const previous = names.get(id);
      const next = input.value.replace(/\s+/g, " ").trim();
      input.replaceWith(toggle);
      item.draggable = true;
      toggle.focus();
      if (!save || next === previous) return;
      if (!next) {
        showError("A relationship type needs a name.");
        return;
      }

      // Show the new name immediately; restore the old one if saving fails.
      clearError();
      setName(id, nameEl, next);
      try {
        const saved = await api("PATCH", `/api/relationship-types/${encodeURIComponent(id)}`, { relationship_type_name: next });
        setName(id, nameEl, saved.relationship_type_name);
      } catch (error) {
        setName(id, nameEl, previous);
        showError(`Could not rename the relationship type. ${error.message}`);
      }
    };
    input.addEventListener("keydown", (event) => {
      if (event.key === "Enter") {
        event.preventDefault();
        finish(true);
      } else if (event.key === "Escape") {
        finish(false);
      }
    });
    input.addEventListener("blur", () => finish(true));
  }

  function setName(id, nameEl, name) {
    names.set(id, name);
    nameEl.textContent = name;
    nameEl.closest(".palette-tag").querySelector(".palette-delete")
      ?.setAttribute("aria-label", `Delete relationship type ${name}`);
    onChange({ kind: "rename", typeId: id });
  }

  // ---------------------------------------------------------------------------
  // Symmetric
  // ---------------------------------------------------------------------------

  // Makes a type symmetric, or directed again. Shows at once; put back if the
  // server refuses (some pairs of nodes have it both ways) or saving fails.
  async function toggleSymmetric(id) {
    clearError();
    const on = !symmetric.has(id);
    setSymmetric(id, on);
    try {
      const saved = await api("PATCH", `/api/relationship-types/${encodeURIComponent(id)}`, { is_symmetric: on });
      if (saved.is_symmetric !== on) setSymmetric(id, saved.is_symmetric);
    } catch (error) {
      setSymmetric(id, !on);
      showError(error.status === 409 ? error.message : `Could not change the relationship type. ${error.message}`);
    }
  }

  function setSymmetric(id, on) {
    if (on) symmetric.add(id);
    else symmetric.delete(id);
    onChange({ kind: "symmetric", typeId: id });
  }

  // ---------------------------------------------------------------------------
  // Deleting
  // ---------------------------------------------------------------------------

  async function confirmDelete(id) {
    clearError();
    let type;
    try {
      // Fresh counts: edges may have been added since the page loaded.
      type = (await api("GET", "/api/relationship-types")).find((t) => t.id === id);
    } catch (error) {
      showError(`Could not delete the relationship type. ${error.message}`);
      return;
    }
    if (!type) return;

    const name = `“${type.relationship_type_name}”`;
    const confirmed = await confirmAction({
      title: "Delete relationship type",
      message: type.edge_count > 0
        ? `Delete relationship type ${name}? This also deletes its ${plural(type.edge_count, "relationship")} between ${plural(type.node_count, "node")}. This can't be undone.`
        : `Delete relationship type ${name}? No relationships use it.`,
    });
    if (!confirmed) return;
    try {
      await api("DELETE", `/api/relationship-types/${encodeURIComponent(id)}`);
    } catch (error) {
      showError(`Could not delete the relationship type. ${error.message}`);
      return;
    }
    list.querySelector(`[data-type-id="${CSS.escape(id)}"]`)?.remove();
    selected.delete(id);
    names.delete(id);
    symmetric.delete(id);
    recolour();
    onChange({ kind: "delete", typeId: id });
  }

  function plural(n, word) {
    return `${n} ${word}${n === 1 ? "" : "s"}`;
  }

  // ---------------------------------------------------------------------------
  // Adding: "+ Add relationship type" opens a box at the bottom of the palette
  // ---------------------------------------------------------------------------

  function addTypeComposer() {
    const wrapper = document.createElement("div");

    const openButton = document.createElement("button");
    openButton.type = "button";
    openButton.className = "palette-add";
    openButton.textContent = "+ Add relationship type";

    const input = document.createElement("input");
    input.type = "text";
    input.className = "input palette-input";
    input.maxLength = MAX_NAME_LENGTH;
    input.placeholder = "e.g. has_a";
    input.setAttribute("aria-label", "New relationship type name");

    const hint = document.createElement("p");
    hint.className = "palette-hint";
    hint.textContent = "Enter to add · Esc to close";

    let saving = false;

    const open = () => {
      wrapper.replaceChildren(input, hint);
      input.focus();
    };
    const close = () => {
      input.value = "";
      wrapper.replaceChildren(openButton);
    };

    async function add() {
      const name = input.value.replace(/\s+/g, " ").trim();
      if (!name || saving) return false;
      saving = true;
      clearError();
      try {
        const type = await api("POST", "/api/relationship-types", { relationship_type_name: name });
        // New types go at the end of the palette.
        await api("POST", `/api/graph/palette/${encodeURIComponent(type.id)}/move`, { before_type_id: null });
        list.append(renderTag(type));
        recolour();
        onChange({ kind: "add", typeId: type.id });
        input.value = "";
        return true;
      } catch (error) {
        // Keep the typed text so nothing is lost.
        showError(`Could not add the relationship type. ${error.message}`);
        return false;
      } finally {
        saving = false;
      }
    }

    openButton.addEventListener("click", open);
    input.addEventListener("keydown", async (event) => {
      if (event.key === "Enter") {
        event.preventDefault();
        await add();
        input.focus();
      } else if (event.key === "Escape") {
        close();
        openButton.focus();
      }
    });
    input.addEventListener("blur", async () => {
      if (saving || !input.isConnected) return;
      if (input.value.trim() === "" || (await add())) close();
    });

    wrapper.append(openButton);
    return wrapper;
  }

  // ---------------------------------------------------------------------------
  // Reordering by drag and drop, within the palette
  // ---------------------------------------------------------------------------

  function enableReordering() {
    const placeholder = document.createElement("li");
    placeholder.className = "palette-placeholder";
    placeholder.setAttribute("aria-hidden", "true");
    let dragged = null;
    let origin = null;

    list.addEventListener("dragstart", (event) => {
      const tag = event.target.closest?.(".palette-tag");
      if (!tag) return;
      dragged = tag;
      origin = tag.nextElementSibling;
      event.dataTransfer.effectAllowed = "move";
      event.dataTransfer.setData("text/plain", names.get(tag.dataset.typeId));
      // Change the page after the browser has captured the drag image.
      requestAnimationFrame(() => {
        if (dragged !== tag) return;
        tag.classList.add("dragging");
        if (!placeholder.isConnected) list.insertBefore(placeholder, origin);
      });
    });

    list.addEventListener("dragover", (event) => {
      if (!dragged) return;
      event.preventDefault();
      event.dataTransfer.dropEffect = "move";
      const next = tags().find((t) => t !== dragged && event.clientY < midY(t)) ?? null;
      if (placeholder.nextElementSibling !== next || !placeholder.isConnected) list.insertBefore(placeholder, next);
    });

    list.addEventListener("drop", async (event) => {
      if (!dragged) return;
      event.preventDefault();
      const tag = dragged;
      const from = origin;
      placeholder.replaceWith(tag);
      reset();
      if (tag.nextElementSibling === from) return;

      const typeId = tag.dataset.typeId;
      const beforeTypeId = tag.nextElementSibling?.dataset.typeId ?? null;
      recolour();
      onChange({ kind: "order", typeId });
      clearError();
      try {
        await api("POST", `/api/graph/palette/${encodeURIComponent(typeId)}/move`, { before_type_id: beforeTypeId });
      } catch (error) {
        list.insertBefore(tag, from);
        recolour();
        onChange({ kind: "order", typeId });
        showError(`Could not move the relationship type. ${error.message}`);
      }
    });

    // Fires after a drop, or when a drag is cancelled (e.g. dropped outside).
    list.addEventListener("dragend", reset);

    function reset() {
      placeholder.remove();
      dragged?.classList.remove("dragging");
      dragged = null;
      origin = null;
    }

    function midY(el) {
      const box = el.getBoundingClientRect();
      return box.top + box.height / 2;
    }
  }
}
