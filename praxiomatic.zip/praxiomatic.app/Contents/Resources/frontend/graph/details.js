// Details panel: the column right of the graph showing the selection. One
// selected node is edited in the core node panel, one selected relationship in
// the core relationship panel; with nothing selected, or several objects, it
// shows a line of text instead. Editing several at once isn't designed yet.
//
// Changes are saved as each is committed (see shared/node-panel.js). Before
// the panel shows something else, a change still being typed is saved.

import { createNodePanel } from "../shared/node-panel.js";
import { createRelationshipPanel } from "../shared/relationship-panel.js";
import { showError } from "../shared/ui.js";

/**
 * Builds the details panel.
 * @param {HTMLElement} element Where the panels go.
 * @param {object} options
 * @param {(node: object) => void} options.onNodeSaved Called with a node each time a change to it is saved.
 * @param {() => void} options.onImagesChanged Called after images are attached or removed.
 */
export function createDetails(element, { onNodeSaved, onImagesChanged }) {
  const hint = Object.assign(document.createElement("p"), { className: "details-panel-hint" });
  const nodePanel = createNodePanel({ onSaved: onNodeSaved, onImagesChanged, onError: showError });
  const edgePanel = createRelationshipPanel({ onError: showError });
  element.append(hint, nodePanel.element, edgePanel.element);

  // The selected node or edge element shown, if just one is selected.
  let shown = null;
  update([]);

  /** Shows the selection: the selected objects' elements, with data-kind "node" or "edge". */
  function update(items) {
    const one = items.length === 1 ? items[0] : null;
    if (one && one === shown) return;
    nodePanel.clear();
    edgePanel.clear();
    shown = one;
    hint.hidden = Boolean(one);
    if (one?.dataset.kind === "node") nodePanel.show(one.dataset.nodeId);
    else if (one?.dataset.kind === "edge") edgePanel.show(one.dataset.edgeId);
    else hint.textContent = items.length ? `${describe(items)} selected.` : "Select a node or relationship to see its details.";
  }

  return {
    update,
    /** Puts the cursor in the panel shown, once it has loaded. */
    focus: () => (shown?.dataset.kind === "node" ? nodePanel.focus() : shown?.dataset.kind === "edge" ? edgePanel.focus() : Promise.resolve()),
    /** Reloads the relationship shown, e.g. after its type changed. */
    refresh: () => {
      if (shown?.dataset.kind === "edge") edgePanel.show(shown.dataset.edgeId);
    },
  };
}

// "3 nodes and 2 relationships"
function describe(items) {
  const count = (kind) => items.filter((el) => el.dataset.kind === kind).length;
  const nodes = count("node");
  const edges = count("edge");
  const parts = [];
  if (nodes) parts.push(nodes === 1 ? "1 node" : `${nodes} nodes`);
  if (edges) parts.push(edges === 1 ? "1 relationship" : `${edges} relationships`);
  return parts.join(" and ");
}
