// Graph page: every node and edge, drawn as boxes joined by arrows. It follows
// the Interaction Model (spec):
//
// - Click a node or an edge to select it (⌘/Ctrl+click adds); click empty
//   space to clear the selection. Shift+drag on empty space selects the nodes
//   and edges wholly inside the rectangle (with ⌘/Ctrl, adding to the
//   selection). Delete or Backspace deletes the selected edges, or, when nodes
//   are selected, the selected nodes and edges after confirming (listing their
//   edges and anything else that goes with them).
// - The details panel, right of the graph, shows the selected node or edge
//   and edits it in place (details.js). Double-click a node or an edge (or
//   choose Open) to select it and put the cursor in the panel.
// - Right-click for actions: a node's Open and Delete node…, then what other
//   perspectives can do with it (e.g. Add to Kanban board…, from
//   app/perspectives.js); an edge's Delete relationship; Add node here on
//   empty space.
//   On a selected object, the menu covers the whole selection, each action
//   using the selected objects of its kind.
// - Drag the background, or scroll (two fingers on a touchpad), to pan; pinch
//   or Ctrl+scroll to zoom.
// - Drag a node to move it; its position is saved when it's dropped. Dragging
//   a selected node or edge moves the whole selection: the selected nodes and
//   both ends of the selected edges.
// - Double-click empty space to add a node there, typing its title in place.
// - Drag from a node's dot (or Shift+drag a node) onto another node to connect
//   them, once for each relationship type selected in the palette (related_to
//   if none is selected). Edges that already exist aren't repeated.
// - Edges between the same two nodes fan out as curves. While relationship
//   types are selected, their edges show in the type's colour and the rest fade.
//   Edges of a symmetric type have no arrowhead.
// - Alt+click (Option+click) a directed edge, or choose Reverse direction in
//   its menu, to swap its source and target; Alt+click leaves the selection
//   as it is (an exception to the Interaction Model, listed in the spec).
// - While perspectives are selected in the Perspectives palette, the nodes
//   they show are outlined in the perspective's colour and the rest fade.
// - Sources (nodes an import's nodes point to with source_is) are hidden,
//   with all their edges, unless Show sources is checked.
// - A node's Focus node collapses every node but it and the nodes directly
//   connected to it (still hiding sources and collapsed nodes); expand from
//   there, or Expand all on empty space to show every node again.
// - A node's menu has Broader and Narrower groups: Expand shows the hidden
//   nodes one level up or down, Expand all those at every level, and Collapse
//   hides every node narrower than it (broader read the other way). A node's badge shows how
//   many narrower nodes are hidden, and clicking it shows them, one level at
//   a time; on hover, a node whose narrower nodes all show offers to collapse.
//
// Moves and removals show immediately; if saving fails they are undone and an
// error is shown. Nodes that have no position yet are placed by
// shared/layout.js; the relationship type palette is palette.js, the
// perspectives palette perspective-palette.js, and what collapsing hides
// hierarchy.js.

import { addNodesTo, showsNodesIn } from "../app/perspectives.js";
import { api } from "../shared/api.js";
import { openContextMenu } from "../shared/context-menu.js";
import { onSelectionKeys } from "../shared/keys.js";
import { confirmNodeDelete } from "../shared/node-delete.js";
import { imageIcon } from "../shared/icons.js";
import { chooseRelationshipType } from "../shared/relationship-type-dialog.js";
import { enableHelp } from "../shared/help.js";
import { createSelection, isAdditive } from "../shared/selection.js";
import { showError, clearError } from "../shared/ui.js";
import { placeNewNodes } from "../shared/layout.js";
import { createDetails } from "./details.js";
import { BROADER_ID, allBroaderOf, broaderOf, hiddenByCollapsing, narrowerIndex, narrowerOf } from "./hierarchy.js";
import { createPalette, COLOUR_COUNT } from "./palette.js";
import { createPerspectivePalette } from "./perspective-palette.js";

const SVG_NS = "http://www.w3.org/2000/svg";

// Node box geometry, in graph units.
// A box is one line tall, and grows taller when its title wraps.
const NODE_HEIGHT = 32; // height of a one-line box
const NODE_PADDING = 14; // space either side of the title
const MIN_NODE_WIDTH = 60;
const MAX_LABEL_WIDTH = 200; // titles wider than this wrap onto more lines
const TITLE_LINE_HEIGHT = 18;
const ICON_SIZE = 14; // the icon before an image node's title
const ICON_GAP = 5; // space between that icon and the title
const MAX_TITLE_LENGTH = 256;
const BADGE_HEIGHT = 16; // the narrower count at a node's top right corner
const BADGE_PADDING = 6;

const MIN_SCALE = 0.2;
const MAX_SCALE = 3;
const DRAG_THRESHOLD = 4; // pixels before a press on a node counts as a drag
const FAN_SPACING = 26; // how far apart edges between the same two nodes bend

const svg = document.getElementById("graph");
const wrap = document.getElementById("graph-wrap");
const viewportEl = document.getElementById("viewport");
const nodesEl = document.getElementById("nodes");
const edgesEl = document.getElementById("edges");
const previewEl = document.getElementById("edge-preview");
const previewLabelEl = document.getElementById("edge-preview-label");
const emptyEl = document.getElementById("graph-empty");
const marqueeEl = document.getElementById("marquee");

/** @type {Map<string, {id: string, title: string, x: number, y: number, width: number, el: SVGGElement}>} */
const nodes = new Map();
/** @type {Map<string, {id: string, source: string, target: string, typeId: string, el: SVGGElement}>} */
const edges = new Map();

let palette = null; // set up once the graph has loaded
let perspectivePalette = null; // likewise

// Sources (nodes that are the target of a source_is edge) are hidden, with all
// their edges, unless Show sources is checked. Not saved: off on every visit.
const SOURCE_IS_ID = "e7617eb9-72e8-4440-8af9-9f44d6db5eb7";
const showSources = document.getElementById("show-sources");

// Nodes hidden by collapsing the broader hierarchy (hierarchy.js). Nodes
// stranded by them hide too, without being listed. Not saved: every visit
// starts with every node shown.
const collapsed = new Set();

// Graph coordinates map to the screen as screen = graph * scale + (x, y).
const view = { x: 0, y: 0, scale: 1 };

// Selected nodes and edges, shown in the details panel. While an area is
// being selected, the panel waits for the drag to end.
const selection = createSelection({
  onChange: (items) => {
    if (gesture?.kind !== "area") details.update(items);
  },
});
let gesture = null; // the drag in progress: pan, area, move, or connect

const details = createDetails(document.getElementById("details"), {
  onNodeSaved: (saved) => {
    const node = nodes.get(saved.id);
    if (node) setTitle(node, saved.title);
  },
  // Attaching or removing images creates or deletes nodes and edges.
  onImagesChanged: () => syncGraph(),
});

// ---------------------------------------------------------------------------
// Drawing
// ---------------------------------------------------------------------------

function svgEl(tag, attrs = {}) {
  const el = document.createElementNS(SVG_NS, tag);
  for (const [name, value] of Object.entries(attrs)) el.setAttribute(name, value);
  return el;
}

function applyView() {
  viewportEl.setAttribute("transform", `translate(${view.x} ${view.y}) scale(${view.scale})`);
}

function addNode(data) {
  const el = svgEl("g", { class: "graph-node", "data-node-id": data.id, "data-kind": "node" });
  el.classList.toggle("is-image", data.content_type === "image");
  const tooltip = svgEl("title");
  const box = svgEl("rect", { class: "graph-node-box", rx: 3 });
  const label = svgEl("text", { class: "graph-node-label" });
  const handle = svgEl("circle", { class: "graph-node-handle", r: 5 });
  el.append(tooltip, box, label, handle);
  // Image nodes show a picture icon before the title.
  const icon = data.content_type === "image" ? imageIcon("graph-node-icon") : null;
  if (icon) {
    icon.setAttribute("width", ICON_SIZE);
    icon.setAttribute("height", ICON_SIZE);
    el.append(icon);
  }
  nodesEl.append(el);

  const node = { id: data.id, title: data.title, x: data.x, y: data.y, width: MIN_NODE_WIDTH, height: NODE_HEIGHT, el, icon };
  nodes.set(node.id, node);
  setTitle(node, data.title);
  moveNode(node, node.x, node.y);
  styleNode(node);
  emptyEl.hidden = true;
  return node;
}

// Shows a node's whole title, wrapped onto as many lines as it needs to fit
// MAX_LABEL_WIDTH, and sizes the box to it: as wide as its widest line (and
// its icon, if it has one), and taller for each extra line.
function setTitle(node, title) {
  node.title = title;
  const [tooltip, box, label, handle] = node.el.children;
  tooltip.textContent = title;

  const width = (text) => {
    label.textContent = text;
    return label.getComputedTextLength();
  };
  const lines = wrapTitle(title, width);
  const widest = Math.max(...lines.map(width));
  // The icon sits to the left of the title, level with its first line, and
  // the title moves right to make room, so the two are centred together.
  const iconSpace = node.icon ? ICON_SIZE + ICON_GAP : 0;
  const lineY = (i) => (i - (lines.length - 1) / 2) * TITLE_LINE_HEIGHT;

  label.replaceChildren(
    ...lines.map((line, i) => {
      // Lines are centred on the node, one TITLE_LINE_HEIGHT apart.
      const tspan = svgEl("tspan", { x: iconSpace / 2, y: lineY(i) });
      tspan.textContent = line;
      return tspan;
    }),
  );
  if (node.icon) {
    node.icon.setAttribute("x", -(widest + iconSpace) / 2);
    node.icon.setAttribute("y", lineY(0) - ICON_SIZE / 2);
  }

  node.width = Math.max(MIN_NODE_WIDTH, widest + iconSpace + 2 * NODE_PADDING);
  node.height = NODE_HEIGHT + (lines.length - 1) * TITLE_LINE_HEIGHT;
  box.setAttribute("x", -node.width / 2);
  box.setAttribute("y", -node.height / 2);
  box.setAttribute("width", node.width);
  box.setAttribute("height", node.height);
  handle.setAttribute("cx", node.width / 2);
  node.badge?.setAttribute("transform", `translate(${node.width / 2} ${-node.height / 2})`);
  updateEdgesOf(node.id);
}

// Breaks text into lines no wider than MAX_LABEL_WIDTH, at spaces where it
// can; a word too long for a line on its own is broken between characters.
function wrapTitle(text, width) {
  const lines = [];
  let line = "";
  for (const word of text.split(" ")) {
    const joined = line ? `${line} ${word}` : word;
    if (width(joined) <= MAX_LABEL_WIDTH) {
      line = joined;
      continue;
    }
    if (line) lines.push(line);
    line = word;
    while (width(line) > MAX_LABEL_WIDTH && line.length > 1) {
      let cut = line.length - 1;
      while (cut > 1 && width(line.slice(0, cut)) > MAX_LABEL_WIDTH) cut--;
      lines.push(line.slice(0, cut));
      line = line.slice(cut);
    }
  }
  lines.push(line);
  return lines;
}

function moveNode(node, x, y) {
  node.x = x;
  node.y = y;
  node.el.setAttribute("transform", `translate(${x} ${y})`);
  updateEdgesOf(node.id);
}

function addEdge(data) {
  const el = svgEl("g", { class: "graph-edge", "data-edge-id": data.id, "data-kind": "edge" });
  el.append(svgEl("title"), svgEl("path", { class: "graph-edge-line" }), svgEl("path", { class: "graph-edge-hit" }));
  edgesEl.append(el);
  const edge = { id: data.id, source: data.source_node_id, target: data.target_node_id, typeId: data.relationship_type_id, el };
  edges.set(edge.id, edge);
  styleEdge(edge);
  drawPair(edge);
  return edge;
}

function removeEdge(edge) {
  selection.forget(edge.el);
  edge.el.remove();
  edges.delete(edge.id);
  drawPair(edge);
}

// The edges between the same two nodes as edge, in either direction, in a
// fixed order.
function pairOf(edge) {
  return [...edges.values()]
    .filter((e) => (e.source === edge.source && e.target === edge.target) || (e.source === edge.target && e.target === edge.source))
    .sort((a, b) => (a.id < b.id ? -1 : 1));
}

function drawPair(edge) {
  for (const e of pairOf(edge)) drawEdge(e);
}

// An edge runs from the border of the source box to the border of the target
// box. One edge between two nodes is straight; several fan out as curves, each
// bending a different amount to one side or the other.
function drawEdge(edge) {
  const source = nodes.get(edge.source);
  const target = nodes.get(edge.target);
  if (!source || !target) return;

  const pair = pairOf(edge);
  const offset = (pair.indexOf(edge) - (pair.length - 1) / 2) * FAN_SPACING;
  // Bend relative to the same direction for both ways round (from the node
  // with the lower id), so A->B and B->A fan out instead of overlapping.
  const [a, b] = edge.source < edge.target ? [source, target] : [target, source];
  const length = Math.hypot(b.x - a.x, b.y - a.y) || 1;
  const normal = { x: -(b.y - a.y) / length, y: (b.x - a.x) / length };
  // A quadratic curve's middle sits halfway to its control point.
  const control = {
    x: (source.x + target.x) / 2 + normal.x * offset * 2,
    y: (source.y + target.y) / 2 + normal.y * offset * 2,
  };
  const start = boxEdgePoint(source, control);
  const end = boxEdgePoint(target, control);
  const d = offset === 0
    ? `M${start.x} ${start.y} L${end.x} ${end.y}`
    : `M${start.x} ${start.y} Q${control.x} ${control.y} ${end.x} ${end.y}`;
  for (const path of edge.el.querySelectorAll("path")) path.setAttribute("d", d);
}

// Colours an edge by its relationship type while that type is selected, drops
// its arrowhead if the type is symmetric, and names the type in its tooltip.
function styleEdge(edge) {
  const highlighted = palette?.selectedIds().includes(edge.typeId) ?? false;
  edge.el.classList.toggle("is-symmetric", palette?.isSymmetric(edge.typeId) ?? false);
  for (const c of [...edge.el.classList]) if (c.startsWith("rel-color-")) edge.el.classList.remove(c);
  edge.el.classList.toggle("is-highlighted", highlighted);
  if (highlighted) edge.el.classList.add(`rel-color-${palette.colourOf(edge.typeId)}`);
  edge.el.querySelector("title").textContent = palette?.nameOf(edge.typeId) ?? "";
}

function styleEdges() {
  svg.classList.toggle("has-filter", (palette?.selectedIds().length ?? 0) > 0);
  for (const edge of edges.values()) styleEdge(edge);
}

// Outlines a node in a perspective's colour while a selected perspective shows
// it.
function styleNode(node) {
  const colour = perspectivePalette?.colourOf(node.id) ?? null;
  for (const c of [...node.el.classList]) if (c.startsWith("rel-color-")) node.el.classList.remove(c);
  node.el.classList.toggle("is-highlighted", colour !== null);
  if (colour !== null) node.el.classList.add(`rel-color-${colour}`);
}

function styleNodes() {
  svg.classList.toggle("has-node-filter", perspectivePalette?.hasSelection() ?? false);
  for (const node of nodes.values()) styleNode(node);
}

// One arrowhead per palette colour, for highlighted edges.
function addColourMarkers() {
  const defs = svg.querySelector("defs");
  for (let n = 1; n <= COLOUR_COUNT; n++) {
    const marker = svgEl("marker", {
      id: `arrow-rel-${n}`,
      class: `rel-color-${n}`,
      viewBox: "0 0 10 10",
      refX: 10,
      refY: 5,
      markerUnits: "userSpaceOnUse",
      markerWidth: 12,
      markerHeight: 12,
      orient: "auto",
    });
    marker.append(svgEl("path", { class: "arrowhead arrowhead--rel", d: "M0,0 L10,5 L0,10 z" }));
    defs.append(marker);
  }
}

// Hides sources and their edges unless Show sources is checked, and the nodes
// hidden by collapsing (with those they strand) and their edges. Hidden
// objects leave the selection. Updates the narrower badges. Called whenever
// edges are added or deleted, or nodes are collapsed or expanded.
function applyVisibility() {
  const folded = hiddenByCollapsing(collapsed, edges.values());
  const hidden = new Set(folded);
  if (!showSources.checked) {
    for (const edge of edges.values()) if (edge.typeId === SOURCE_IS_ID) hidden.add(edge.target);
  }
  for (const node of nodes.values()) setHidden(node.el, hidden.has(node.id));
  for (const edge of edges.values()) setHidden(edge.el, hidden.has(edge.source) || hidden.has(edge.target));

  // Narrower nodes hidden as sources don't count: expanding wouldn't show them.
  const narrower = narrowerIndex(edges.values());
  for (const node of nodes.values()) {
    const children = hidden.has(node.id) ? [] : narrower.get(node.id) ?? [];
    setBadge(node, children.filter((id) => folded.has(id)).length, children.length);
  }
}

// A node's badge, at its top right corner: how many of its narrower nodes are
// hidden by collapsing ("▾ 3"; clicking shows them), or, when none are, "▴",
// shown on hover (clicking collapses the node). No badge without narrower
// nodes.
function setBadge(node, hiddenCount, total) {
  if (!total) {
    node.badge?.remove();
    node.badge = null;
    return;
  }
  if (!node.badge) {
    node.badge = svgEl("g", { class: "graph-node-badge" });
    node.badge.append(svgEl("title"), svgEl("rect", { class: "graph-node-badge-box", rx: 8 }), svgEl("text", { class: "graph-node-badge-label" }));
    node.el.append(node.badge);
  }
  const [tooltip, box, label] = node.badge.children;
  node.badge.classList.toggle("is-collapsible", hiddenCount === 0);
  tooltip.textContent = hiddenCount
    ? `Show ${hiddenCount === 1 ? "the hidden narrower node" : `the ${hiddenCount} hidden narrower nodes`}`
    : "Collapse: hide every narrower node";
  label.textContent = hiddenCount ? `▾ ${hiddenCount}` : "▴";
  const width = label.getComputedTextLength() + 2 * BADGE_PADDING;
  box.setAttribute("x", -width / 2);
  box.setAttribute("y", -BADGE_HEIGHT / 2);
  box.setAttribute("width", width);
  box.setAttribute("height", BADGE_HEIGHT);
  node.badge.setAttribute("transform", `translate(${node.width / 2} ${-node.height / 2})`);
}

function setHidden(el, hidden) {
  el.classList.toggle("is-hidden", hidden);
  if (hidden) selection.forget(el);
}

const isShown = (item) => !item.el.classList.contains("is-hidden");

function updateEdgesOf(nodeId) {
  for (const edge of edges.values()) {
    if (edge.source === nodeId || edge.target === nodeId) drawEdge(edge);
  }
}

// Where the line from node's centre towards other's centre leaves node's box.
function boxEdgePoint(node, other) {
  const dx = other.x - node.x;
  const dy = other.y - node.y;
  if (dx === 0 && dy === 0) return { x: node.x, y: node.y };
  const scale = Math.min(node.width / 2 / Math.abs(dx), node.height / 2 / Math.abs(dy));
  return { x: node.x + dx * scale, y: node.y + dy * scale };
}

// Centres the graph's shown nodes in the window, shrinking them to fit if
// needed.
function fitView() {
  const { width, height } = svg.getBoundingClientRect();
  const all = [...nodes.values()].filter(isShown);
  if (all.length === 0) {
    Object.assign(view, { x: width / 2, y: height / 2, scale: 1 });
    applyView();
    return;
  }
  const left = Math.min(...all.map((n) => n.x - n.width / 2));
  const right = Math.max(...all.map((n) => n.x + n.width / 2));
  const top = Math.min(...all.map((n) => n.y - n.height / 2));
  const bottom = Math.max(...all.map((n) => n.y + n.height / 2));
  const margin = 40;
  const scale = clamp(Math.min(1, (width - 2 * margin) / (right - left), (height - 2 * margin) / (bottom - top)), MIN_SCALE, 1);
  Object.assign(view, {
    scale,
    x: width / 2 - ((left + right) / 2) * scale,
    y: height / 2 - ((top + bottom) / 2) * scale,
  });
  applyView();
}

function clamp(value, min, max) {
  return Math.min(max, Math.max(min, value));
}

// The graph coordinates under a pointer event.
function toGraph(event) {
  const rect = svg.getBoundingClientRect();
  return {
    x: (event.clientX - rect.left - view.x) / view.scale,
    y: (event.clientY - rect.top - view.y) / view.scale,
  };
}

function nodeAt(clientX, clientY) {
  const el = document.elementFromPoint(clientX, clientY)?.closest(".graph-node");
  return el ? nodes.get(el.dataset.nodeId) : null;
}

// ---------------------------------------------------------------------------
// Saving
// ---------------------------------------------------------------------------

function savePosition(node) {
  return api("PUT", `/api/graph/positions/${encodeURIComponent(node.id)}`, { x: node.x, y: node.y });
}

async function createEdge(source, target) {
  clearError();
  try {
    const { edges: created } = await api("POST", "/api/edges", {
      source_node_id: source.id,
      target_node_id: target.id,
      relationship_type_ids: palette.selectedIds(),
    });
    for (const edge of created) addEdge(edge);
    applyVisibility();
    if (created.length === 0) showError("Already connected.");
  } catch (error) {
    showError(`Could not connect the nodes. ${error.message}`);
  }
}

// Deletes edges: they go at once; any whose delete fails come back.
async function deleteEdges(list) {
  clearError();
  for (const edge of list) removeEdge(edge);
  const results = await Promise.allSettled(list.map((edge) => api("DELETE", `/api/edges/${encodeURIComponent(edge.id)}`)));
  const failed = list.filter((_, i) => results[i].status === "rejected");
  for (const edge of failed) {
    edgesEl.append(edge.el);
    edges.set(edge.id, edge);
    drawPair(edge);
  }
  applyVisibility();
  if (failed.length) {
    const error = results.find((r) => r.status === "rejected").reason;
    showError(`Could not remove ${failed.length === 1 ? "the relationship" : "some relationships"}. ${error.message}`);
  }
}

// Gives edges the relationship type chosen in a dialog. One edge changing
// from a symmetric type can be given a direction there too. The change shows
// at once; any edge whose nodes already have that type in its direction, or
// whose change fails, goes back, with a message.
async function changeEdgeTypes(list) {
  clearError();
  const types = new Set(list.map((e) => e.typeId));
  const single = list.length === 1 ? list[0] : null;
  const choice = await chooseRelationshipType({
    title: single ? "Change relationship type" : `Change relationship type of ${list.length} relationships`,
    types: palette.types(),
    current: types.size === 1 ? list[0].typeId : null,
    direction: single && palette.isSymmetric(single.typeId)
      ? { source: nodes.get(single.source)?.title ?? "", target: nodes.get(single.target)?.title ?? "" }
      : null,
  });
  if (!choice) return;
  const { typeId } = choice;
  const reverse = choice.reverse && !palette.isSymmetric(typeId);
  const changing = list.filter((e) => e.typeId !== typeId || reverse).map((edge) => ({ edge, from: edge.typeId }));
  for (const { edge } of changing) {
    setEdgeType(edge, typeId);
    if (reverse) turnEdge(edge);
  }
  applyVisibility();
  const results = await Promise.allSettled(changing.map(({ edge }) =>
    api("PATCH", `/api/edges/${encodeURIComponent(edge.id)}`, { relationship_type_id: typeId, ...(reverse && { reverse: true }) })));
  const failed = changing.filter((_, i) => results[i].status === "rejected");
  for (const { edge, from } of failed) {
    setEdgeType(edge, from);
    if (reverse) turnEdge(edge);
  }
  applyVisibility();
  if (failed.length) {
    const reasons = results.filter((r) => r.status === "rejected").map((r) => r.reason);
    const repeats = reasons.filter((e) => e.status === 409).length;
    const other = reasons.find((e) => e.status !== 409);
    const name = palette.nameOf(typeId);
    const messages = [];
    if (repeats) messages.push(`${repeats === 1 ? "1 relationship was" : `${repeats} relationships were`} left as they were: their nodes are already connected by ${name} that way.`);
    if (other) messages.push(`Could not change ${reasons.length - repeats === 1 ? "a relationship" : "some relationships"}. ${other.message}`);
    showError(messages.join(" "));
  }
  details.refresh();
}

function setEdgeType(edge, typeId) {
  edge.typeId = typeId;
  styleEdge(edge);
}

// Swaps the source and target of the given edges whose type is directed. They
// turn at once; any whose reverse already exists, or whose change fails, turn
// back, with a message.
async function reverseEdges(list) {
  clearError();
  const turning = list.filter((e) => !palette.isSymmetric(e.typeId));
  if (turning.length === 0) return;
  for (const edge of turning) turnEdge(edge);
  applyVisibility();
  const results = await Promise.allSettled(turning.map((edge) =>
    api("PATCH", `/api/edges/${encodeURIComponent(edge.id)}`, { reverse: true })));
  const failed = turning.filter((_, i) => results[i].status === "rejected");
  for (const edge of failed) turnEdge(edge);
  applyVisibility();
  if (failed.length) {
    const reasons = results.filter((r) => r.status === "rejected").map((r) => r.reason);
    const repeats = reasons.filter((e) => e.status === 409).length;
    const other = reasons.find((e) => e.status !== 409);
    const messages = [];
    if (repeats) messages.push(`${repeats === 1 ? "1 relationship was" : `${repeats} relationships were`} left as they were: the reverse already exists.`);
    if (other) messages.push(`Could not reverse ${reasons.length - repeats === 1 ? "a relationship" : "some relationships"}. ${other.message}`);
    showError(messages.join(" "));
  }
  details.refresh();
}

function turnEdge(edge) {
  [edge.source, edge.target] = [edge.target, edge.source];
  drawPair(edge);
}

const isDirected = (edge) => !palette.isSymmetric(edge.typeId);

const selectedEdges = () => selection.ofKind("edge").map((el) => edges.get(el.dataset.edgeId));
const selectedNodes = () => selection.ofKind("node").map((el) => nodes.get(el.dataset.nodeId));

// Deletes nodes, and any edges given that aren't theirs, after one
// confirmation listing what else goes with them (their edges, and e.g. Kanban
// cards showing them). Each node goes, with its edges, once the server has
// deleted it; any that fail stay, with an error. The other edges then go as
// deleteEdges does.
async function deleteNodes(list, edgeList = []) {
  clearError();
  const ids = new Set(list.map((n) => n.id));
  const extra = edgeList.filter((e) => !ids.has(e.source) && !ids.has(e.target));
  const what = list.length === 1 ? `“${list[0].title}”` : `${list.length} nodes`;
  const andEdges = extra.length === 0 ? "" : ` and ${extra.length} ${extra.length === 1 ? "relationship" : "relationships"}`;
  let confirmed;
  try {
    confirmed = await confirmNodeDelete({
      nodeIds: list.map((n) => n.id),
      title: list.length === 1 ? "Delete node" : "Delete nodes",
      question: `Delete ${what}${andEdges}?`,
    });
  } catch (error) {
    showError(`Could not delete ${list.length === 1 ? "the node" : "the nodes"}. ${error.message}`);
    return;
  }
  if (!confirmed) return;
  const results = await Promise.allSettled(list.map((n) => api("DELETE", `/api/nodes/${encodeURIComponent(n.id)}`)));
  results.forEach((result, i) => {
    if (result.status === "fulfilled") removeNode(list[i]);
  });
  applyVisibility(); // a deleted node's source_is edges may have made a source
  if (extra.length) await deleteEdges(extra);
  const failed = results.find((r) => r.status === "rejected");
  if (failed) showError(`Could not delete ${list.length === 1 ? "the node" : "some nodes"}. ${failed.reason.message}`);
  // Images left with no edges were deleted with the nodes.
  else if (results.length) await syncGraph();
}

function removeNode(node) {
  for (const edge of [...edges.values()]) {
    if (edge.source === node.id || edge.target === node.id) removeEdge(edge);
  }
  selection.forget(node.el);
  node.el.remove();
  nodes.delete(node.id);
  emptyEl.hidden = nodes.size > 0;
}

// Hands nodes to another perspective (e.g. Kanban), which asks where to put them.
async function addNodesToPerspective(perspective, list) {
  clearError();
  try {
    await perspective.add(list.map((n) => ({ id: n.id, title: n.title })));
  } catch (error) {
    showError(`Could not add ${list.length === 1 ? "the node" : "the nodes"}. ${error.message}`);
    return;
  }
  // The nodes may now be shown there, so may need highlighting.
  await perspectivePalette.refresh();
}

// Selects a node or an edge and puts the cursor in the details panel.
function edit(el) {
  selection.select(el);
  details.focus();
}

// ---------------------------------------------------------------------------
// Collapsing and expanding the broader hierarchy
// ---------------------------------------------------------------------------

// Shows nodes hidden by collapsing, with their neighbours outside the
// hierarchy (such as attached images), which Focus node may have collapsed.
function reveal(ids) {
  const show = new Set(ids);
  const inHierarchy = new Set();
  for (const edge of edges.values()) {
    if (edge.typeId === BROADER_ID) inHierarchy.add(edge.source).add(edge.target);
  }
  for (const edge of edges.values()) {
    if (show.has(edge.source) && !inHierarchy.has(edge.target)) collapsed.delete(edge.target);
    if (show.has(edge.target) && !inHierarchy.has(edge.source)) collapsed.delete(edge.source);
  }
  for (const id of show) collapsed.delete(id);
  applyVisibility();
}

// Hides every node narrower than the given nodes, at any depth.
function collapseAll(list) {
  for (const id of narrowerOf(list.map((n) => n.id), edges.values())) collapsed.add(id);
  applyVisibility();
}

// The badge: shows a node's hidden narrower nodes, one level (theirs stay as
// they are), or, when none are hidden, collapses it.
function clickBadge(node) {
  const children = narrowerIndex(edges.values()).get(node.id) ?? [];
  if (children.some((id) => collapsed.has(id))) {
    reveal(children);
  } else {
    collapseAll([node]);
  }
}

// Collapses every node except the given ones and the nodes directly connected
// to them; neighbours already collapsed stay so. The given nodes always show.
// Expanding (the badges, the Broader and Narrower menus) then works from there.
function focusOn(list) {
  const ids = new Set(list.map((n) => n.id));
  const near = new Set(ids);
  for (const edge of edges.values()) {
    if (ids.has(edge.source)) near.add(edge.target);
    if (ids.has(edge.target)) near.add(edge.source);
  }
  for (const id of nodes.keys()) if (!near.has(id)) collapsed.add(id);
  for (const id of ids) collapsed.delete(id);
  applyVisibility();
}

// The Broader and Narrower menu groups for the given nodes: Expand shows the
// hidden nodes one level away, Expand all those at every level (offered when
// that shows more than Expand), and Collapse hides every narrower node.
function foldGroups(list) {
  const ids = list.map((n) => n.id);
  const hidden = (set) => [...set].filter((id) => collapsed.has(id));
  const up = hidden(broaderOf(ids, edges.values()));
  const allUp = hidden(allBroaderOf(ids, edges.values()));
  const index = narrowerIndex(edges.values());
  const down = hidden(new Set(ids.flatMap((id) => index.get(id) ?? [])));
  const below = [...narrowerOf(ids, edges.values())];
  const allDown = hidden(below);
  return [
    {
      heading: "Broader",
      items: [
        ...(up.length ? [{ label: "Expand", action: () => reveal(up) }] : []),
        ...(allUp.length > up.length ? [{ label: "Expand all", action: () => reveal(allUp) }] : []),
      ],
    },
    {
      heading: "Narrower",
      items: [
        ...(down.length ? [{ label: "Expand", action: () => reveal(down) }] : []),
        ...(allDown.length > down.length ? [{ label: "Expand all", action: () => reveal(allDown) }] : []),
        ...(below.length > allDown.length ? [{ label: "Collapse", action: () => collapseAll(list) }] : []),
      ],
    },
  ];
}



// ---------------------------------------------------------------------------
// Pointer gestures: pan, select an area, move nodes, or connect two nodes
// ---------------------------------------------------------------------------

svg.addEventListener("pointerdown", (event) => {
  if (event.button !== 0) return;
  const nodeEl = event.target.closest(".graph-node");
  const edgeEl = event.target.closest(".graph-edge");
  const start = { x: event.clientX, y: event.clientY };

  if (nodeEl) {
    const node = nodes.get(nodeEl.dataset.nodeId);
    // The narrower badge is a control: it expands or collapses the node.
    if (event.target.closest(".graph-node-badge")) {
      clickBadge(node);
      return;
    }
    if (event.target.closest(".graph-node-handle") || event.shiftKey) {
      gesture = { kind: "connect", source: node, target: null };
      svg.classList.add("is-connecting");
      previewEl.removeAttribute("hidden");
      previewLabelEl.removeAttribute("hidden");
      const ids = palette.selectedIds();
      previewLabelEl.textContent = ids.length ? ids.map(palette.nameOf).join(", ") : "related_to";
      updatePreview(event);
    } else {
      gesture = moveGesture(nodeEl, selection.has(nodeEl) ? selectionNodes() : [node], start);
    }
  } else if (edgeEl) {
    // Alt+click reverses the edge, leaving the selection as it is.
    if (event.altKey) {
      reverseEdges([edges.get(edgeEl.dataset.edgeId)]);
      return;
    }
    // A selected edge can be dragged to move the selection; any other edge is
    // selected at once.
    if (!selection.has(edgeEl)) {
      selection.click(edgeEl, event);
      return;
    }
    gesture = moveGesture(edgeEl, selectionNodes(), start);
  } else if (event.shiftKey) {
    gesture = { kind: "area", start, add: isAdditive(event), before: selection.items(), moved: false };
  } else {
    gesture = { kind: "pan", start, from: { x: view.x, y: view.y }, moved: false };
  }
  svg.setPointerCapture(event.pointerId);
});

svg.addEventListener("pointermove", (event) => {
  if (!gesture) return;
  const dx = event.clientX - (gesture.start?.x ?? 0);
  const dy = event.clientY - (gesture.start?.y ?? 0);

  if (gesture.kind === "pan") {
    gesture.moved ||= Math.hypot(dx, dy) > DRAG_THRESHOLD;
    if (!gesture.moved) return;
    svg.classList.add("is-panning");
    view.x = gesture.from.x + dx;
    view.y = gesture.from.y + dy;
    applyView();
  } else if (gesture.kind === "area") {
    gesture.moved ||= Math.hypot(dx, dy) > DRAG_THRESHOLD;
    if (!gesture.moved) return;
    svg.classList.add("is-selecting");
    selectArea(gesture, event);
  } else if (gesture.kind === "move") {
    gesture.moved ||= Math.hypot(dx, dy) > DRAG_THRESHOLD;
    if (!gesture.moved) return;
    svg.classList.add("is-moving");
    for (const { node, from } of gesture.moving) {
      moveNode(node, from.x + dx / view.scale, from.y + dy / view.scale);
    }
  } else if (gesture.kind === "connect") {
    updatePreview(event);
  }
});

svg.addEventListener("pointerup", async (event) => {
  const done = gesture;
  endGesture();
  if (!done) return;

  if ((done.kind === "pan" || done.kind === "area") && !done.moved) {
    selection.clear();
  } else if (done.kind === "move") {
    // A click (no drag) selects what was clicked.
    if (!done.moved) {
      selection.click(done.clicked, event);
      return;
    }
    // Each node is saved; any whose save fails goes back to where it was.
    for (const { node } of done.moving) {
      node.x = Math.round(node.x);
      node.y = Math.round(node.y);
    }
    clearError();
    const results = await Promise.allSettled(done.moving.map(({ node }) => savePosition(node)));
    const failed = done.moving.filter((_, i) => results[i].status === "rejected");
    for (const { node, from } of failed) moveNode(node, from.x, from.y);
    if (failed.length) {
      const error = results.find((r) => r.status === "rejected").reason;
      showError(`Could not move ${done.moving.length === 1 ? "the node" : "some nodes"}. ${error.message}`);
    }
  } else if (done.kind === "connect") {
    const target = nodeAt(event.clientX, event.clientY);
    if (target && target !== done.source) await createEdge(done.source, target);
  }
});

// A cancelled pointer (e.g. the window lost focus) puts dragged nodes back,
// and the selection as it was before an area selection.
svg.addEventListener("pointercancel", cancelGesture);

function cancelGesture() {
  if (gesture?.kind === "move") for (const { node, from } of gesture.moving) moveNode(node, from.x, from.y);
  if (gesture?.kind === "area") selection.selectMany(gesture.before);
  endGesture();
}

// Dragging the clicked node or edge moves these nodes together.
function moveGesture(clicked, list, start) {
  const moving = list.map((node) => ({ node, from: { x: node.x, y: node.y } }));
  return { kind: "move", clicked, moving, start, moved: false };
}

// The nodes a drag of the selection moves: the selected nodes and both ends of
// the selected edges, once each.
function selectionNodes() {
  const list = new Set(selectedNodes());
  for (const edge of selectedEdges()) {
    list.add(nodes.get(edge.source));
    list.add(nodes.get(edge.target));
  }
  return [...list];
}

function endGesture() {
  // An area selection done or cancelled: show the selection it left.
  if (gesture?.kind === "area") {
    gesture = null;
    details.update(selection.items());
  }
  if (gesture?.target) gesture.target.el.classList.remove("is-connect-target");
  svg.classList.remove("is-panning", "is-connecting", "is-selecting", "is-moving");
  marqueeEl.setAttribute("hidden", "");
  previewEl.setAttribute("hidden", "");
  previewLabelEl.setAttribute("hidden", "");
  gesture = null;
}

// Draws the rectangle from where the drag started to the pointer, and selects
// the nodes and edges wholly inside it: instead of the selection, or added to
// the selection from before the drag.
function selectArea(area, event) {
  const rect = svg.getBoundingClientRect();
  const x1 = Math.min(area.start.x, event.clientX), x2 = Math.max(area.start.x, event.clientX);
  const y1 = Math.min(area.start.y, event.clientY), y2 = Math.max(area.start.y, event.clientY);
  marqueeEl.setAttribute("x", x1 - rect.left);
  marqueeEl.setAttribute("y", y1 - rect.top);
  marqueeEl.setAttribute("width", x2 - x1);
  marqueeEl.setAttribute("height", y2 - y1);
  marqueeEl.removeAttribute("hidden");

  const from = toGraph({ clientX: x1, clientY: y1 });
  const to = toGraph({ clientX: x2, clientY: y2 });
  const inside = (left, top, right, bottom) => left >= from.x && right <= to.x && top >= from.y && bottom <= to.y;
  const enclosed = [];
  for (const n of [...nodes.values()].filter(isShown)) {
    if (inside(n.x - n.width / 2, n.y - n.height / 2, n.x + n.width / 2, n.y + n.height / 2)) enclosed.push(n.el);
  }
  for (const e of [...edges.values()].filter(isShown)) {
    const box = e.el.querySelector(".graph-edge-line").getBBox();
    if (inside(box.x, box.y, box.x + box.width, box.y + box.height)) enclosed.push(e.el);
  }
  selection.selectMany(area.add ? [...area.before, ...enclosed] : enclosed);
}

// The dashed line from the source node to the pointer, highlighting the node
// it would connect to.
function updatePreview(event) {
  const point = toGraph(event);
  previewEl.setAttribute("x1", gesture.source.x);
  previewEl.setAttribute("y1", gesture.source.y);
  previewEl.setAttribute("x2", point.x);
  previewEl.setAttribute("y2", point.y);
  // The types the new edges will get, just above and right of the pointer.
  previewLabelEl.setAttribute("x", point.x + 10 / view.scale);
  previewLabelEl.setAttribute("y", point.y - 10 / view.scale);

  const over = nodeAt(event.clientX, event.clientY);
  const target = over && over !== gesture.source ? over : null;
  if (target === gesture.target) return;
  gesture.target?.el.classList.remove("is-connect-target");
  target?.el.classList.add("is-connect-target");
  gesture.target = target;
}

// Scrolling (two fingers on a touchpad) pans. Pinching zooms, keeping the
// point under the pointer still: browsers report a pinch as a scroll with Ctrl
// held, which also makes Ctrl+scroll with a mouse wheel zoom.
const LINE_HEIGHT = 16; // pixels per line, for wheels that scroll by lines
svg.addEventListener(
  "wheel",
  (event) => {
    event.preventDefault();
    const unit = event.deltaMode === 1 ? LINE_HEIGHT : 1;
    const dx = event.deltaX * unit;
    const dy = event.deltaY * unit;
    if (!event.ctrlKey) {
      view.x -= dx;
      view.y -= dy;
      applyView();
      return;
    }
    const rect = svg.getBoundingClientRect();
    const px = event.clientX - rect.left;
    const py = event.clientY - rect.top;
    // Pinches arrive as many small steps, a mouse wheel as fewer large ones;
    // capping each step keeps a wheel notch from jumping too far.
    const step = clamp(dy, -50, 50);
    const scale = clamp(view.scale * Math.exp(-step * 0.01), MIN_SCALE, MAX_SCALE);
    view.x = px - ((px - view.x) * scale) / view.scale;
    view.y = py - ((py - view.y) * scale) / view.scale;
    view.scale = scale;
    applyView();
  },
  { passive: false },
);

// ---------------------------------------------------------------------------
// Double-click: edit a node or an edge, or add a node on empty space
// ---------------------------------------------------------------------------

svg.addEventListener("dblclick", (event) => {
  // Check what's under the pointer, since pointer capture can make the svg
  // itself the event's target.
  const under = document.elementFromPoint(event.clientX, event.clientY);
  if (under?.closest(".graph-node-badge")) return;
  const nodeEl = under?.closest(".graph-node");
  const objectEl = nodeEl ?? under?.closest(".graph-edge");
  if (objectEl) {
    edit(objectEl);
    return;
  }
  addNodeAt(event.clientX, event.clientY);
});

// Opens the title box for a new node at a point on the screen.
function addNodeAt(clientX, clientY) {
  const rect = svg.getBoundingClientRect();
  const point = toGraph({ clientX, clientY });
  openTitleInput(point, clientX - rect.left, clientY - rect.top);
}

// ---------------------------------------------------------------------------
// Right-click menus and keys
// ---------------------------------------------------------------------------

svg.addEventListener("contextmenu", (event) => {
  event.preventDefault();
  const at = { x: event.clientX, y: event.clientY };
  const under = document.elementFromPoint(event.clientX, event.clientY);
  const nodeEl = under?.closest(".graph-node");
  const edgeEl = under?.closest(".graph-edge");
  const objectEl = nodeEl ?? edgeEl;
  if (objectEl) {
    // On a selected object, the menu acts on the whole selection, each action
    // on the selected objects of its kind; on any other object, on just that
    // one. A node's own actions come first, then other perspectives', then
    // the edges'.
    const selected = selection.has(objectEl);
    const list = selected ? selectedNodes() : nodeEl ? [nodes.get(nodeEl.dataset.nodeId)] : [];
    const edgeList = selected ? selectedEdges() : edgeEl ? [edges.get(edgeEl.dataset.edgeId)] : [];
    const directed = edgeList.filter(isDirected);
    const nodeItems = list.length === 0 ? [] : [
      ...(list.length === 1 && edgeList.length === 0 ? [{ label: "Open", action: () => edit(list[0].el) }] : []),
      { label: list.length === 1 ? "Delete node…" : "Delete nodes…", danger: true, action: () => deleteNodes(list) },
    ];
    openContextMenu({
      ...at,
      groups: [
        { heading: "Node", items: nodeItems },
        {
          heading: "Perspectives",
          items: list.length === 0 ? [] : addNodesTo.map((p) => ({ label: p.label(list.length), action: () => addNodesToPerspective(p, list) })),
        },
        {
          heading: "Relationship",
          items: edgeList.length === 0 ? [] : [
            { label: edgeList.length === 1 ? "Change relationship type…" : `Change relationship type of ${edgeList.length}…`, action: () => changeEdgeTypes(edgeList) },
            ...(directed.length === 0 ? [] : [
              { label: edgeList.length === 1 ? "Reverse direction" : `Reverse direction of ${directed.length}`, action: () => reverseEdges(directed) },
            ]),
            { label: edgeList.length === 1 ? "Delete relationship" : "Delete relationships", danger: true, action: () => deleteEdges(edgeList) },
          ],
        },
        {
          heading: "Graph",
          items: list.length === 0 ? [] : [
            { label: list.length === 1 ? "Focus node" : `Focus ${list.length} nodes`, action: () => focusOn(list) },
          ],
        },
        ...(list.length === 0 ? [] : foldGroups(list)),
      ],
    });
  } else {
    selection.clear();
    openContextMenu({
      ...at,
      items: [
        { label: "Add node here", action: () => addNodeAt(event.clientX, event.clientY) },
        ...(collapsed.size ? [{ label: "Expand all", action: () => { collapsed.clear(); applyVisibility(); fitView(); } }] : []),
      ],
    });
  }
});

onSelectionKeys({
  remove: () => {
    const edgeList = selectedEdges();
    const list = selectedNodes();
    if (list.length) deleteNodes(list, edgeList);
    else if (edgeList.length) deleteEdges(edgeList);
  },
  // Escape during an area selection or a move cancels it, keeping the
  // selection (and the nodes' places) from before.
  clear: () => (gesture?.kind === "area" || gesture?.kind === "move" ? cancelGesture() : selection.clear()),
});

// Enter (or leaving the box) adds the node; Escape, or an empty box, cancels.
function openTitleInput(point, screenX, screenY) {
  const input = document.createElement("input");
  input.type = "text";
  input.className = "input graph-title-input";
  input.maxLength = MAX_TITLE_LENGTH;
  input.placeholder = "Title for the new node";
  input.setAttribute("aria-label", "New node title");
  input.style.setProperty("--x", `${screenX}px`);
  input.style.setProperty("--y", `${screenY}px`);
  wrap.append(input);
  input.focus();

  let finished = false;
  const finish = async (add) => {
    if (finished) return;
    finished = true;
    // Titles are single-line; collapse pasted line breaks and runs of spaces.
    const title = input.value.replace(/\s+/g, " ").trim();
    input.remove();
    if (add && title) await createNode(title, point);
  };
  input.addEventListener("keydown", (event) => {
    if (event.key === "Enter") {
      event.preventDefault();
      finish(true);
    } else if (event.key === "Escape") {
      finish(false);
    }
  });
  input.addEventListener("blur", () => finish(true));
}

async function createNode(title, point) {
  clearError();
  let node;
  try {
    const created = await api("POST", "/api/nodes", { title });
    node = addNode({ id: created.id, title: created.title, x: Math.round(point.x), y: Math.round(point.y) });
  } catch (error) {
    showError(`Could not add the node. ${error.message}`);
    return;
  }
  try {
    await savePosition(node);
  } catch (error) {
    // The node exists; it will be placed automatically next time the graph loads.
    showError(`Added the node, but could not save where it is. ${error.message}`);
  }
}

// ---------------------------------------------------------------------------
// Loading
// ---------------------------------------------------------------------------

async function loadGraph() {
  let graph;
  try {
    graph = await api("GET", "/api/graph");
  } catch (error) {
    showError(`Could not load the graph. ${error.message}`);
    return;
  }

  palette = createPalette({
    list: document.getElementById("palette-tags"),
    composer: document.getElementById("palette-composer"),
    types: graph.relationship_types,
    onChange: paletteChanged,
  });
  perspectivePalette = createPerspectivePalette({
    list: document.getElementById("perspective-tags"),
    perspectives: showsNodesIn,
    onChange: styleNodes,
  });
  perspectivePalette.refresh();

  const placed = placeNewNodes(graph.nodes, graph.edges);
  for (const node of graph.nodes) addNode(node);
  for (const edge of graph.edges) addEdge(edge);
  applyVisibility();
  emptyEl.hidden = nodes.size > 0;
  fitView();

  // Save where new nodes were placed, so they stay put next time.
  const results = await Promise.allSettled(placed.map((n) => savePosition(nodes.get(n.id))));
  const failed = results.find((r) => r.status === "rejected");
  if (failed) showError(`Could not save where new nodes were placed. ${failed.reason.message}`);
}

// Brings the graph up to date after a change that created or deleted nodes
// and edges besides those acted on (e.g. attaching images): adds what's new,
// placed as on loading, and removes what's gone. Nodes keep where they are.
async function syncGraph() {
  let graph;
  try {
    graph = await api("GET", "/api/graph");
  } catch (error) {
    showError(`Could not refresh the graph. ${error.message}`);
    return;
  }
  const nodeIds = new Set(graph.nodes.map((n) => n.id));
  const edgeIds = new Set(graph.edges.map((e) => e.id));
  for (const edge of [...edges.values()]) if (!edgeIds.has(edge.id)) removeEdge(edge);
  for (const node of [...nodes.values()]) if (!nodeIds.has(node.id)) removeNode(node);

  const all = graph.nodes.map((n) => (nodes.has(n.id) ? { ...n, x: nodes.get(n.id).x, y: nodes.get(n.id).y } : n));
  const placed = placeNewNodes(all, graph.edges);
  for (const node of all) if (!nodes.has(node.id)) addNode(node);
  for (const edge of graph.edges) if (!edges.has(edge.id)) addEdge(edge);
  applyVisibility();

  const results = await Promise.allSettled(placed.map((n) => savePosition(nodes.get(n.id))));
  const failed = results.find((r) => r.status === "rejected");
  if (failed) showError(`Could not save where new nodes were placed. ${failed.reason.message}`);
}

// Deleting a relationship type deleted its edges; anything else may change
// which edges are highlighted, their colours, their names, or their
// arrowheads. A type made symmetric or directed changes how the details panel
// writes its edges.
function paletteChanged({ kind, typeId }) {
  if (kind === "delete") {
    for (const edge of [...edges.values()]) if (edge.typeId === typeId) removeEdge(edge);
  }
  styleEdges();
  if (kind === "symmetric") details.refresh();
}

showSources.addEventListener("change", applyVisibility);
enableHelp(document.getElementById("help"), document.getElementById("help-panel"));

addColourMarkers();
applyView();
loadGraph();
