// Collapsing the broader hierarchy, worked out from the edges (spec: Graph,
// Collapse and expand). An edge of the seeded broader type goes from the
// narrower node to the broader one; "narrower" is the same edge read the other
// way. Nothing here is stored, and nothing touches the page.
//
// Edges are objects with source, target, and typeId (node and type ids).

// The seeded broader type, by id since it can be renamed.
export const BROADER_ID = "a4d14461-1cdc-4de2-91b0-60fe35f45516";

/**
 * Each node's immediate narrower nodes.
 * @param {Iterable<{source: string, target: string, typeId: string}>} edges
 * @returns {Map<string, string[]>}
 */
export function narrowerIndex(edges) {
  const index = new Map();
  for (const edge of edges) {
    if (edge.typeId !== BROADER_ID) continue;
    if (!index.has(edge.target)) index.set(edge.target, []);
    index.get(edge.target).push(edge.source);
  }
  return index;
}

/**
 * The immediate broader nodes of the given nodes, not counting the nodes
 * themselves.
 * @param {Iterable<string>} ids
 * @param {Iterable<{source: string, target: string, typeId: string}>} edges
 * @returns {Set<string>}
 */
export function broaderOf(ids, edges) {
  const from = new Set(ids);
  const result = new Set();
  for (const edge of edges) {
    if (edge.typeId === BROADER_ID && from.has(edge.source) && !from.has(edge.target)) result.add(edge.target);
  }
  return result;
}

/**
 * Every node broader than the given nodes, at any depth, not counting the
 * nodes themselves.
 * @param {Iterable<string>} ids
 * @param {Iterable<{source: string, target: string, typeId: string}>} edges
 * @returns {Set<string>}
 */
export function allBroaderOf(ids, edges) {
  const broader = new Map();
  for (const edge of edges) {
    if (edge.typeId !== BROADER_ID) continue;
    if (!broader.has(edge.source)) broader.set(edge.source, []);
    broader.get(edge.source).push(edge.target);
  }
  return reachable(ids, broader);
}

/**
 * Every node narrower than the given nodes, at any depth, not counting the
 * nodes themselves.
 * @param {Iterable<string>} ids
 * @param {Iterable<{source: string, target: string, typeId: string}>} edges
 * @returns {Set<string>}
 */
export function narrowerOf(ids, edges) {
  return reachable(ids, narrowerIndex(edges));
}

// The nodes reachable from ids through next (id -> ids), not counting ids
// themselves. Breadth-first, so a loop of broader edges ends.
function reachable(ids, next) {
  const start = new Set(ids);
  const found = new Set();
  let level = [...start];
  while (level.length) {
    const following = [];
    for (const id of level) {
      for (const other of next.get(id) ?? []) {
        if (!start.has(other) && !found.has(other)) {
          found.add(other);
          following.push(other);
        }
      }
    }
    level = following;
  }
  return found;
}

/**
 * The collapsed nodes, plus the nodes stranded by them: a node outside the
 * hierarchy (none of its edges is broader) whose every neighbour is hidden,
 * such as an image attached to a collapsed node, or a note related only to
 * one. Repeated until nothing more is stranded.
 * @param {Set<string>} collapsed
 * @param {Iterable<{source: string, target: string, typeId: string}>} edges
 * @returns {Set<string>}
 */
export function hiddenByCollapsing(collapsed, edges) {
  const hidden = new Set(collapsed);
  if (hidden.size === 0) return hidden;
  /** @type {Map<string, {neighbours: Set<string>, inHierarchy: boolean}>} */
  const nodes = new Map();
  const entry = (id) => nodes.get(id) ?? nodes.set(id, { neighbours: new Set(), inHierarchy: false }).get(id);
  for (const edge of edges) {
    for (const [id, other] of [[edge.source, edge.target], [edge.target, edge.source]]) {
      const node = entry(id);
      node.neighbours.add(other);
      if (edge.typeId === BROADER_ID) node.inHierarchy = true;
    }
  }
  let changed = true;
  while (changed) {
    changed = false;
    for (const [id, node] of nodes) {
      if (hidden.has(id) || node.inHierarchy) continue;
      if ([...node.neighbours].every((other) => hidden.has(other))) {
        hidden.add(id);
        changed = true;
      }
    }
  }
  return hidden;
}
