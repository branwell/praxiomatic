// Perspectives palette: the other perspectives that show some of the nodes
// (from app/perspectives.js), as tags.
//
// - Click a tag to select or deselect it; several can be selected. The graph
//   highlights the nodes the selected perspectives show.
// - A tag's colour follows its position. Tags can't be added, renamed,
//   reordered, or deleted.
// Tags toggle on a plain click because they're filters, an exception to the
// Interaction Model's click-to-select (spec).
//
// Which nodes each perspective shows is loaded by refresh(), and again when a
// tag is selected, so changes made on other pages show up.

import { showError } from "../shared/ui.js";
import { COLOUR_COUNT } from "./palette.js";

/**
 * Builds the palette.
 * @param {object} options
 * @param {HTMLOListElement} options.list Where the tags go.
 * @param {import("../app/perspectives.js").ShowsNodes[]} options.perspectives
 * @param {() => void} options.onChange Called after the selection, or the nodes
 *   a perspective shows, change.
 */
export function createPerspectivePalette({ list, perspectives, onChange }) {
  const selected = new Set();
  /** @type {Map<string, Set<string>>} perspective name -> ids of nodes it shows */
  const shown = new Map(perspectives.map((p) => [p.name, new Set()]));

  list.replaceChildren(...perspectives.map(renderTag));

  return {
    /** Whether any perspective is selected. */
    hasSelection: () => selected.size > 0,
    /**
     * The colour number (1..COLOUR_COUNT) of the first selected perspective, in
     * palette order, that shows the node; null if none does.
     */
    colourOf: (nodeId) => {
      const index = perspectives.findIndex((p) => selected.has(p.name) && shown.get(p.name).has(nodeId));
      return index < 0 ? null : (index % COLOUR_COUNT) + 1;
    },
    refresh,
  };

  function renderTag(perspective, index) {
    const item = document.createElement("li");
    item.className = `palette-tag rel-color-${(index % COLOUR_COUNT) + 1}`;

    const toggle = document.createElement("button");
    toggle.type = "button";
    toggle.className = "palette-toggle";
    toggle.setAttribute("aria-pressed", "false");
    const swatch = document.createElement("span");
    swatch.className = "palette-swatch";
    const name = document.createElement("span");
    name.className = "palette-name";
    name.textContent = perspective.name;
    toggle.append(swatch, name);
    toggle.addEventListener("click", async () => {
      const on = !selected.has(perspective.name);
      if (on) selected.add(perspective.name);
      else selected.delete(perspective.name);
      toggle.setAttribute("aria-pressed", String(on));
      onChange();
      if (on) await refresh([perspective]);
    });
    item.append(toggle);
    return item;
  }

  /**
   * Reloads which nodes the perspectives show (all of them by default). A
   * perspective that fails to load keeps what it showed before, with an error.
   */
  async function refresh(which = perspectives) {
    const results = await Promise.allSettled(which.map((p) => p.nodeIds()));
    results.forEach((result, i) => {
      if (result.status === "fulfilled") shown.set(which[i].name, new Set(result.value));
    });
    const failed = results.find((r) => r.status === "rejected");
    if (failed) showError(`Could not load which nodes other perspectives show. ${failed.reason.message}`);
    onChange();
  }
}
