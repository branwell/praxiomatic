// Graph's list-perspectives operation: the one graph, as a tile on the
// Perspectives page. It can't be created, renamed, or deleted until there can
// be several graphs.

import { api } from "../shared/api.js";
import { icon } from "../shared/icons.js";

/** @type {import("../app/perspectives.js").PerspectiveList} */
export const graphPerspectiveList = {
  kind: "Graph",
  // Linked dots.
  icon: (className) => icon(className, [
    ["path", { d: "M7.5 7.5l3 8M8 6l9 0M16.5 7.5l-3 8" }],
    ["circle", { cx: 6, cy: 6, r: 2.5 }],
    ["circle", { cx: 18, cy: 6, r: 2.5 }],
    ["circle", { cx: 12, cy: 18, r: 2.5 }],
  ]),
  // The graph's id is its perspective's, seeded in the registry.
  list: async () => (await api("GET", "/api/perspectives"))
    .filter((p) => p.kind === "graph")
    .map((p) => ({ id: p.id, title: "Graph", url: "/graph/index.html" })),
};
