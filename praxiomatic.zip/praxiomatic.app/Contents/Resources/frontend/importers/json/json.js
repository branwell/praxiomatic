// JSON importer page: paste a JSON document of nodes and their property values
// (typically written by an LLM with the parallax-import-json skill), check
// what importing it would create, and import it. Property names with no
// definition yet get one. Nothing is saved until Import, and nothing is kept
// between visits: the JSON lives in the LLM chat.

import { api } from "../../shared/api.js";
import { showError, clearError } from "../../shared/ui.js";

const $ = (id) => document.getElementById(id);
const sourceInput = $("source");
const jsonText = $("json-text");
const checkButton = $("check");
const importButton = $("import");
const preview = $("preview");

// The document last checked without errors, and the text it came from;
// Import sends it only while the source and the JSON are unchanged.
let checked = null; // {key, doc}

checkButton.addEventListener("click", async () => {
  const doc = readDocument();
  if (!doc) return;
  checkButton.disabled = true;
  try {
    const result = await api("POST", "/api/importers/json/check", doc);
    clearError();
    checked = { key: inputKey(), doc };
    renderPreview(doc, result);
  } catch (err) {
    showError(`Can't import this. ${err.message}`);
    hidePreview();
  } finally {
    checkButton.disabled = false;
  }
});

importButton.addEventListener("click", async () => {
  if (!checked || checked.key !== inputKey()) return;
  const page = document.querySelector("main");
  page.inert = true;
  try {
    const result = await api("POST", "/api/importers/json/commit", checked.doc);
    clearError();
    hidePreview();
    sourceInput.value = "";
    jsonText.value = "";
    const parts = [plural(result.nodes.length, "node", "nodes") + " imported"];
    const defs = result.property_definitions_to_create.length;
    if (defs) parts.push(`${plural(defs, "property definition", "property definitions")} created`);
    if (result.source) parts.push(result.source.existing ? "from the existing source" : "from a new source");
    showNotice(parts.join(", ") + ".");
  } catch (err) {
    showError(`Nothing was imported. ${err.message}`);
  } finally {
    page.inert = false;
  }
});

// Any change means the preview no longer matches what Import would send.
for (const input of [sourceInput, jsonText]) {
  input.addEventListener("input", () => {
    if (checked && checked.key !== inputKey()) hidePreview();
  });
}

$("copy-properties").addEventListener("click", async () => {
  try {
    const defs = await api("GET", "/api/property-definitions");
    const lines = defs
      .filter((d) => d.allowed_on_nodes && d.data_type !== "timestamp")
      .sort((a, b) => a.property_name.localeCompare(b.property_name, undefined, { sensitivity: "base" }))
      .map((d) => `- ${d.property_name} (${d.data_type})${d.description ? `: ${d.description}` : ""}`);
    const text = ["Parallax property list (use these names and types first):", ...lines].join("\n");
    await navigator.clipboard.writeText(text);
    clearError();
    showNotice(`Copied ${plural(lines.length, "property", "properties")}. Paste it into the LLM chat.`);
  } catch (err) {
    showError(`Could not copy the property list. ${err.message}`);
  }
});

/**
 * Parses the JSON box, without a surrounding ``` code fence (LLMs often add
 * one), and puts the Source field's text, if any, in its source. Shows an
 * error and returns null if it isn't a JSON object.
 */
function readDocument() {
  const text = jsonText.value.trim().replace(/^```[\w-]*\s*\n([\s\S]*?)\n?```$/, "$1");
  if (!text) {
    showError("Paste the JSON first.");
    return null;
  }
  let doc;
  try {
    doc = JSON.parse(text);
  } catch (err) {
    showError(`This isn't valid JSON. ${err.message}`);
    return null;
  }
  if (!doc || typeof doc !== "object" || Array.isArray(doc)) {
    showError("The JSON must be an object with format and nodes.");
    return null;
  }
  const source = sourceInput.value.trim();
  if (source) doc.source = source;
  return doc;
}

function inputKey() {
  return `${sourceInput.value}\u0000${jsonText.value}`;
}

function renderPreview(doc, result) {
  const defs = result.property_definitions_to_create;
  $("definitions-count").textContent = defs.length ? `(${defs.length})` : "";
  $("definitions-list").replaceChildren(
    ...(defs.length
      ? defs.map((d) => el("li", { textContent: `${d.name} (${d.type})` }))
      : [el("li", { className: "empty-state", textContent: "None: every property name already has a definition." })]),
  );

  $("nodes-count").textContent = `(${result.nodes.length})`;
  $("nodes-list").replaceChildren(...result.nodes.map((n, i) => renderNode(n, doc.nodes[i])));
  $("source-status").textContent = result.source
    ? result.source.existing
      ? "Each node will be connected to the existing source."
      : "Each node will be connected to a new source node."
    : "No source.";
  preview.hidden = false;
}

/** A node to import, with its non-blank values from the document. */
function renderNode(n, docNode) {
  const values = Object.entries(docNode?.properties ?? {}).filter(([, v]) => String(v).trim());
  const count = values.length ? ` · ${plural(values.length, "property", "properties")}` : "";
  if (!values.length) return el("li", { textContent: n.title });
  return el("li", {}, [
    el("details", { className: "json-node" }, [
      el("summary", { textContent: n.title + count }),
      el("dl", { className: "json-values" }, values.flatMap(([k, v]) => [el("dt", { textContent: k }), el("dd", { textContent: v })])),
    ]),
  ]);
}

function hidePreview() {
  checked = null;
  preview.hidden = true;
}

let noticeTimer = 0;

/** Shows a passing message for a few seconds. */
function showNotice(text) {
  const notice = $("notice");
  notice.textContent = text;
  notice.hidden = false;
  clearTimeout(noticeTimer);
  noticeTimer = setTimeout(() => (notice.hidden = true), 6000);
}

/** "1 node", "3 nodes", or "no nodes". */
function plural(count, singular, pluralForm) {
  return `${count || "no"} ${count === 1 ? singular : pluralForm}`;
}

function el(tag, props = {}, children = []) {
  const node = Object.assign(document.createElement(tag), props);
  node.append(...children);
  return node;
}
