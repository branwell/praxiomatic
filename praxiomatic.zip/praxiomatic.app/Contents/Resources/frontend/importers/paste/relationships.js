// Relationships of a proposed node (or of Add to each new node): each goes to
// an existing node, in either direction, with one relationship type and its
// own property values. Nothing is saved here; the page keeps the values.

import { createNodePicker } from "../../shared/node-picker.js";
import { createPropertiesEditor } from "../../shared/properties.js";

/**
 * A relationship to an existing node, as kept in the page's work in progress.
 * @typedef {object} Relationship
 * @property {string} node_id The existing node.
 * @property {"out"|"in"} direction out: this node → node_id; in: node_id → this node.
 * @property {string} relationship_type_id
 * @property {Object<string, string>} properties Values by definition id.
 */

/**
 * Creates a relationships editor.
 * @param {object} options
 * @param {{
 *   nodes: () => {id: string, title: string}[],
 *   types: () => {id: string, relationship_type_name: string, is_symmetric: boolean}[],
 *   defaultTypeId: string,
 * }} options.context The existing nodes and relationship types to choose from.
 * @param {() => void} options.onChange Called when the user changes anything.
 * @param {(message: string) => void} options.onError Shows a message ("" clears it).
 * @returns {{
 *   element: HTMLElement,
 *   load: (relationships: Relationship[]) => void,
 *   values: () => Relationship[],
 * }}
 */
export function createRelationshipsEditor({ context, onChange, onError }) {
  let relationships = [];

  const list = el("div", { className: "paste-relationships" });
  const direction = el("select", { className: "input" }, [
    el("option", { value: "out", textContent: "This node → target" }),
    el("option", { value: "in", textContent: "Target → this node" }),
  ]);
  direction.setAttribute("aria-label", "Direction");
  const type = el("select", { className: "input" });
  type.setAttribute("aria-label", "Relationship type");
  // A symmetric type has no direction to choose.
  const isSymmetric = (typeId) => Boolean(context.types().find((t) => t.id === typeId)?.is_symmetric);
  const showDirection = () => { direction.hidden = isSymmetric(type.value); };
  type.addEventListener("change", showDirection);
  const picker = createNodePicker({ nodes: context.nodes, onPick: addRelationship, placeholder: "Target: type part of a title…" });
  const cancel = el("button", { type: "button", className: "btn btn--ghost", textContent: "Cancel" });
  const adder = el("div", { className: "paste-relationship-adder", hidden: true }, [direction, type, picker.element, cancel]);
  const add = el("button", { type: "button", className: "btn btn--ghost properties-add", textContent: "+ Add relationship" });
  const element = el("div", { className: "field" }, [
    el("span", { className: "field-label", textContent: "Relationships" }),
    list,
    adder,
    add,
  ]);

  add.addEventListener("click", () => {
    const types = [...context.types()].sort((a, b) =>
      a.relationship_type_name.localeCompare(b.relationship_type_name, undefined, { sensitivity: "base" }),
    );
    const chosen = type.value || context.defaultTypeId;
    type.replaceChildren(...types.map((t) => el("option", { value: t.id, textContent: t.relationship_type_name })));
    type.value = types.some((t) => t.id === chosen) ? chosen : context.defaultTypeId;
    showDirection();
    adder.hidden = false;
    add.hidden = true;
    picker.input.focus();
  });
  cancel.addEventListener("click", closeAdder);

  function closeAdder() {
    adder.hidden = true;
    add.hidden = false;
    picker.input.value = "";
  }

  function addRelationship(node) {
    const r = { node_id: node.id, direction: isSymmetric(type.value) ? "out" : direction.value, relationship_type_id: type.value, properties: {} };
    if (relationships.some((x) => sameRelationship(x, r, context.types()))) {
      onError("That relationship is already in the list.");
      return;
    }
    onError("");
    relationships.push(r);
    render();
    closeAdder();
    onChange();
  }

  function render() {
    list.replaceChildren(...relationships.map(renderRow));
    if (!relationships.length) list.append(el("p", { className: "properties-empty", textContent: "No relationships." }));
  }

  function renderRow(r) {
    const type = context.types().find((t) => t.id === r.relationship_type_id);
    const target = context.nodes().find((n) => n.id === r.node_id)?.title ?? "(deleted node)";
    // A symmetric type has no direction: always this node first, joined by —.
    const [from, to] = r.direction === "out" || type?.is_symmetric ? ["This node", target] : [target, "this node"];
    const link = type?.is_symmetric ? "—" : "→";
    const summary = el("span", { className: "relationship-summary" }, [
      `${from} ${link} `,
      el("span", { className: "relationship-type", textContent: type?.relationship_type_name ?? "?" }),
      ` ${link} ${to}`,
    ]);
    const toggle = el("button", { type: "button", className: "btn btn--ghost paste-relationship-toggle" });
    const remove = el("button", { type: "button", className: "dialog-image-remove", textContent: "×" });
    remove.setAttribute("aria-label", "Remove relationship");
    remove.title = "Remove";
    const props = el("div", { className: "paste-relationship-properties", hidden: true });
    const row = el("div", { className: "paste-relationship" }, [
      el("div", { className: "paste-relationship-line" }, [summary, toggle, remove]),
      props,
    ]);
    row.title = "Double-click to show its properties";

    const updateToggle = () => {
      const count = Object.keys(r.properties).length;
      toggle.textContent = `Properties${count ? ` (${count})` : ""}`;
      toggle.setAttribute("aria-expanded", String(!props.hidden));
    };
    let editor = null;
    const toggleProperties = async () => {
      if (props.hidden && !editor) {
        editor = createPropertiesEditor("edge", onError, {
          onChange: () => {
            r.properties = editor.values();
            updateToggle();
            onChange();
          },
        });
        try {
          await editor.load(r.properties);
        } catch (err) {
          editor = null;
          onError(`Could not load the properties. ${err.message}`);
          return;
        }
        props.append(editor.element);
      }
      props.hidden = !props.hidden;
      updateToggle();
    };
    toggle.addEventListener("click", toggleProperties);
    summary.addEventListener("dblclick", toggleProperties);
    remove.addEventListener("click", () => {
      relationships = relationships.filter((x) => x !== r);
      render();
      onChange();
    });
    updateToggle();
    return row;
  }

  function load(values) {
    relationships = values.map((r) => ({ ...r, properties: { ...r.properties } }));
    closeAdder();
    render();
  }

  function values() {
    return relationships.map((r) => ({ ...r, properties: { ...r.properties } }));
  }

  return { element, load, values };
}

/**
 * Whether two relationships go to the same node with the same type, in the
 * same direction unless the type is symmetric (in types, the relationship
 * types as the API lists them).
 */
export function sameRelationship(a, b, types) {
  if (a.node_id !== b.node_id || a.relationship_type_id !== b.relationship_type_id) return false;
  return a.direction === b.direction || Boolean(types.find((t) => t.id === a.relationship_type_id)?.is_symmetric);
}

function el(tag, props = {}, children = []) {
  const node = Object.assign(document.createElement(tag), props);
  node.append(...children);
  return node;
}
