// Paste importer page: paste text, carve it into proposed nodes, give them
// properties and relationships to existing nodes, and import them all at once.
// With a source, each imported node is connected to the source's node by
// source_is (the server reuses the node of an earlier import from the same
// source). Nothing is data until imported; the work in progress (the source,
// the paste area, the proposed nodes, and Add to each new node) is saved on
// the server as you go.

import { api } from "../../shared/api.js";
import { showError, clearError } from "../../shared/ui.js";
import { confirmAction } from "../../shared/confirm.js";
import { createPropertiesEditor } from "../../shared/properties.js";
import { isAdditive } from "../../shared/selection.js";
import { createGraphPreview } from "../graph-preview.js";
import { createRelationshipsEditor, sameRelationship } from "./relationships.js";

const RELATED_TO_ID = "ea272bfa-0775-4290-afd4-ba8ce5016218";
const MAX_TITLE_LENGTH = 256;
const SAVE_DELAY_MS = 1000;

/**
 * The work in progress, saved as one JSON document (tbl_wip_imp_paste.state).
 * @typedef {object} Work
 * @property {string} source_text Where the text came from; "" for none.
 * @property {string} paste_text
 * @property {ProposedNode[]} proposed_nodes In the order proposed.
 * @property {{properties: Object<string, string>, relationships: import("./relationships.js").Relationship[]}} each_new_node
 * @property {string|null} selected_key The proposed node shown in the editor.
 *
 * @typedef {object} ProposedNode
 * @property {string} key Identifies it on this page only.
 * @property {string} title
 * @property {string} content
 * @property {Object<string, string>} properties
 * @property {import("./relationships.js").Relationship[]} relationships
 */

/** @type {Work} */
let work = emptyWork();
let nodes = []; // existing nodes: [{id, title}], for choosing targets
let types = []; // relationship types
// Saving the work: timer, the pending save; current, the save on its way (a
// promise); dirty, whether there are changes not saved yet.
const save = { timer: 0, current: Promise.resolve(), dirty: false };

const $ = (id) => document.getElementById(id);
const sourceText = $("source");
const clearSource = $("clear-source");
const pasteText = $("paste-text");
const proposeSelection = $("propose-selection");
const list = $("proposed-list");
const editor = $("editor");
const nodeTitle = $("node-title");
const nodeContent = $("node-content");
const importButton = $("import");

const context = { nodes: () => nodes, types: () => types, defaultTypeId: RELATED_TO_ID };
const onError = (message) => (message ? showError(message) : clearError());

const eachProperties = createPropertiesEditor("node", onError, {
  onChange: () => {
    work.each_new_node.properties = eachProperties.values();
    changed();
  },
});
const eachRelationships = createRelationshipsEditor({
  context,
  onError,
  onChange: () => {
    work.each_new_node.relationships = eachRelationships.values();
    changed();
  },
});
const nodeProperties = createPropertiesEditor("node", onError, {
  onChange: () => {
    const node = selectedNode();
    if (!node) return;
    node.properties = nodeProperties.values();
    renderList();
    changed();
  },
});
const nodeRelationships = createRelationshipsEditor({
  context,
  onError,
  onChange: () => {
    const node = selectedNode();
    if (!node) return;
    node.relationships = nodeRelationships.values();
    renderList();
    changed();
  },
});
$("each-properties").append(eachProperties.element);
$("each-relationships").append(eachRelationships.element);
$("node-properties").append(nodeProperties.element);
$("node-relationships").append(nodeRelationships.element);
const preview = createGraphPreview({ onNodeClick: select });
$("preview").append(preview.element);
const previewSource = $("preview-source"); // not saved: off on every visit
previewSource.addEventListener("change", renderPreview);

load();

async function load() {
  try {
    const [saved, nodeList, typeList, definitions] = await Promise.all([
      api("GET", "/api/importers/paste/work"),
      api("GET", "/api/nodes"),
      api("GET", "/api/relationship-types"),
      api("GET", "/api/property-definitions"),
    ]);
    nodes = nodeList;
    types = typeList;
    work = normalizeWork(saved.state);
    const dropped = dropMissing(work, definitions);
    if (dropped.length) {
      showNotice(`Removed ${dropped.join(" and ")} that referred to deleted data.`);
      changed();
    }
    setSourceText(work.source_text, false);
    pasteText.value = work.paste_text;
    await eachProperties.load(work.each_new_node.properties);
    eachRelationships.load(work.each_new_node.relationships);
    renderList();
    await showEditor();
  } catch (err) {
    showError(`Could not load the importer. ${err.message}`);
  }
}

// ---------------------------------------------------------------------------
// Proposing nodes

$("propose-all").addEventListener("click", () => {
  if (!propose(pasteText.value)) {
    showError("Nothing to make a node from: the paste area is empty.");
    return;
  }
  setPasteText("");
});

proposeSelection.addEventListener("click", proposeFromSelection);

function proposeFromSelection() {
  const { selectionStart: start, selectionEnd: end, value } = pasteText;
  if (!propose(value.slice(start, end))) {
    showError("Nothing to make a node from: the selection is blank.");
    return;
  }
  // Cut in place, so the cursor stays where the selection was and the box
  // doesn't scroll.
  pasteText.setRangeText("", start, end, "start");
  pasteText.focus();
  setPasteText(pasteText.value);
}

// ⌘S (Ctrl+S elsewhere) is Selection → node, from anywhere on the page, even
// while typing in a field; it replaces the browser's Save.
document.addEventListener("keydown", (event) => {
  if (!isAdditive(event) || event.shiftKey || event.altKey || event.key.toLowerCase() !== "s") return;
  if (document.querySelector("dialog[open]")) return;
  event.preventDefault();
  proposeFromSelection();
});

sourceText.addEventListener("input", () => {
  work.source_text = sourceText.value;
  clearSource.hidden = !sourceText.value;
  renderPreview();
  changed();
});

clearSource.addEventListener("click", () => {
  setSourceText("");
  sourceText.focus();
});

function setSourceText(text, save = true) {
  sourceText.value = work.source_text = text;
  clearSource.hidden = !text;
  renderPreview();
  if (save) changed();
}

pasteText.addEventListener("input", () => {
  work.paste_text = pasteText.value;
  changed();
});
// The selection can change without an input event (pointer, Shift+arrows).
document.addEventListener("selectionchange", updateSelectionButton);
pasteText.addEventListener("select", updateSelectionButton);

function updateSelectionButton() {
  proposeSelection.disabled = pasteText.selectionStart === pasteText.selectionEnd;
}

function setPasteText(text) {
  if (pasteText.value !== text) pasteText.value = text; // setting it moves the cursor to the end
  work.paste_text = text;
  updateSelectionButton();
  changed();
}

/**
 * Proposes a node from text, starting with a copy of Add to each new node, and
 * shows it in the editor: the first non-blank line is its title, and the lines
 * after it its content. A first line too long for a title is cut, and the
 * content is then the whole text, so nothing is lost. Returns false,
 * proposing nothing, for blank text.
 */
function propose(text) {
  const lines = text.split(/\r?\n/);
  const index = lines.findIndex((line) => line.trim());
  if (index < 0) return false;
  clearError();
  const first = [...lines[index].trim()];
  const cut = first.length > MAX_TITLE_LENGTH;
  const node = {
    key: crypto.randomUUID(),
    title: first.slice(0, MAX_TITLE_LENGTH).join(""),
    content: cut ? text.trim() : lines.slice(index + 1).join("\n").trim(),
    properties: { ...work.each_new_node.properties },
    relationships: work.each_new_node.relationships.map(copyRelationship),
  };
  work.proposed_nodes.push(node);
  select(node.key);
  return true;
}

// ---------------------------------------------------------------------------
// Nodes to import

function renderList() {
  const proposed = work.proposed_nodes;
  $("proposed-count").textContent = proposed.length ? `(${proposed.length})` : "";
  importButton.disabled = proposed.length === 0;
  list.replaceChildren(...proposed.map(renderItem));
  if (!proposed.length) list.append(el("li", { className: "empty-state", textContent: "No nodes yet: make them from the paste." }));
  renderPreview();
}

// Draws what Import would create: the proposed nodes, the existing nodes their
// relationships reach, and, with Show source, the source with its source_is
// relationships.
function renderPreview() {
  const proposed = work.proposed_nodes;
  $("preview-section").hidden = proposed.length === 0;
  if (!proposed.length) return;

  const titles = new Map(nodes.map((n) => [n.id, n.title]));
  const typesById = new Map(types.map((t) => [t.id, t]));
  const shown = new Map();
  const edges = [];
  for (const node of proposed) {
    shown.set(node.key, { id: node.key, title: node.title, kind: "new", current: node.key === work.selected_key });
    for (const r of node.relationships) {
      if (!shown.has(r.node_id)) shown.set(r.node_id, { id: r.node_id, title: titles.get(r.node_id) ?? "(unknown node)", kind: "existing" });
      const [source, target] = r.direction === "in" ? [r.node_id, node.key] : [node.key, r.node_id];
      const type = typesById.get(r.relationship_type_id);
      edges.push({ source, target, label: type?.relationship_type_name ?? "", symmetric: Boolean(type?.is_symmetric) });
    }
  }
  const sourceTitle = work.source_text.trim();
  if (sourceTitle && previewSource.checked) {
    shown.set("source", { id: "source", title: sourceTitle, kind: "source" });
    for (const node of proposed) edges.push({ source: node.key, target: "source", label: "source_is" });
  }
  preview.render({ nodes: [...shown.values()], edges });
}

function renderItem(node, index) {
  const counts = [
    plural(Object.keys(node.properties).length, "property", "properties"),
    plural(node.relationships.length, "relationship", "relationships"),
  ].filter(Boolean);
  const show = el("button", { type: "button", className: "paste-item-show" }, [
    el("span", { className: "paste-item-title", textContent: node.title.trim() || "(no title)" }),
    el("span", { className: "meta", textContent: counts.join(" · ") }),
  ]);
  show.title = "Show in the editor";
  const remove = el("button", { type: "button", className: "dialog-image-remove", textContent: "×" });
  remove.setAttribute("aria-label", `Remove node ${index + 1}`);
  remove.title = "Remove (its text goes back to the paste area)";
  const item = el("li", { className: "paste-item" }, [show, remove]);
  if (node.key === work.selected_key) {
    item.classList.add("is-current");
    show.setAttribute("aria-current", "true");
  }
  show.addEventListener("click", () => select(node.key));
  remove.addEventListener("click", () => removeNode(node));
  return item;
}

function removeNode(node) {
  work.proposed_nodes = work.proposed_nodes.filter((n) => n !== node);
  const text = [node.title.trim(), node.content].filter(Boolean).join("\n");
  if (text) {
    const rest = pasteText.value.replace(/\s+$/, "");
    setPasteText(rest ? `${rest}\n${text}` : text);
  }
  if (work.selected_key === node.key) select(null);
  else {
    renderList();
    changed();
  }
}

function selectedNode() {
  return work.proposed_nodes.find((n) => n.key === work.selected_key) ?? null;
}

function select(key) {
  work.selected_key = key;
  renderList();
  showEditor();
  changed();
}

async function showEditor() {
  const node = selectedNode();
  editor.hidden = !node;
  if (!node) return;
  nodeTitle.value = node.title;
  nodeContent.value = node.content;
  nodeRelationships.load(node.relationships);
  try {
    await nodeProperties.load(node.properties);
  } catch (err) {
    showError(`Could not load the properties. ${err.message}`);
  }
}

nodeTitle.addEventListener("input", () => {
  const node = selectedNode();
  if (!node) return;
  node.title = nodeTitle.value;
  renderList();
  changed();
});

nodeContent.addEventListener("input", () => {
  const node = selectedNode();
  if (!node) return;
  node.content = nodeContent.value;
  changed();
});

// ---------------------------------------------------------------------------
// Add to each new node

$("apply-all").addEventListener("click", () => {
  const proposed = work.proposed_nodes;
  if (!proposed.length) {
    showNotice("There are no nodes to apply it to yet.");
    return;
  }
  for (const node of proposed) {
    Object.assign(node.properties, work.each_new_node.properties);
    for (const r of work.each_new_node.relationships) {
      if (!node.relationships.some((x) => sameRelationship(x, r, types))) node.relationships.push(copyRelationship(r));
    }
  }
  renderList();
  showEditor();
  changed();
  showNotice(`Applied to ${plural(proposed.length, "node", "nodes")}.`);
});

// ---------------------------------------------------------------------------
// Import and Clear

importButton.addEventListener("click", async () => {
  const proposed = work.proposed_nodes;
  const untitled = proposed.findIndex((n) => !n.title.trim());
  if (untitled >= 0) {
    select(proposed[untitled].key);
    showError(`Node ${untitled + 1} needs a title.`);
    nodeTitle.focus();
    return;
  }

  const after = { ...work, proposed_nodes: [], selected_key: null };
  const body = {
    source: work.source_text.trim(),
    nodes: proposed.map((n) => ({
      title: n.title,
      content: n.content,
      properties: n.properties,
      edges: n.relationships.map((r) => ({
        node_id: r.node_id,
        direction: r.direction,
        relationship_type_id: r.relationship_type_id,
        properties: r.properties,
      })),
    })),
    state: after,
  };

  // The page can't change while importing, and a save still on its way must
  // land first: arriving after the import, it would bring the nodes back.
  const page = document.querySelector("main");
  page.inert = true;
  importButton.disabled = true;
  clearTimeout(save.timer);
  await save.current;
  try {
    const result = await api("POST", "/api/importers/paste/commit", body);
    save.dirty = false;
    setSaveStatus("Saved.");
    work = after;
    clearError();
    renderList();
    showEditor();
    const from = result.source ? (result.source.existing ? " from the existing source" : " from a new source") : "";
    showNotice(`${plural(result.nodes.length, "node", "nodes")} imported${from}.`);
    nodes = await api("GET", "/api/nodes"); // so the new nodes can be targets
  } catch (err) {
    const match = /node (\d+)/.exec(err.message);
    const index = match ? Number(match[1]) - 1 : -1;
    if (proposed[index]) select(proposed[index].key);
    showError(`Nothing was imported. ${err.message}`);
    renderList();
  } finally {
    page.inert = false;
  }
});

$("clear").addEventListener("click", async () => {
  const ok = await confirmAction({
    title: "Clear everything?",
    message: "This empties the source, the paste area, Nodes to import, and Add to each new node. This can't be undone.",
    confirmLabel: "Clear all",
  });
  if (!ok) return;
  work.proposed_nodes = [];
  work.each_new_node = { properties: {}, relationships: [] };
  await eachProperties.load(work.each_new_node.properties);
  eachRelationships.load(work.each_new_node.relationships);
  setSourceText("", false);
  setPasteText("");
  select(null);
});

// ---------------------------------------------------------------------------
// Saving the work in progress

/** Records that the work changed, and saves it shortly. */
function changed() {
  save.dirty = true;
  setSaveStatus("Not saved yet…");
  clearTimeout(save.timer);
  save.timer = setTimeout(flush, SAVE_DELAY_MS);
}

/** Saves the work now if it has changed, one save at a time. */
function flush() {
  clearTimeout(save.timer);
  save.current = save.current.then(async () => {
    if (!save.dirty) return;
    save.dirty = false;
    try {
      await api("PUT", "/api/importers/paste/work", { state: work });
      if (!save.dirty) setSaveStatus("Saved.");
    } catch (err) {
      save.dirty = true; // tried again on the next change
      setSaveStatus(`Latest changes aren't saved. ${err.message}`);
    }
  });
  return save.current;
}

document.addEventListener("visibilitychange", () => {
  if (document.visibilityState === "hidden") flush();
});
window.addEventListener("beforeunload", (event) => {
  if (save.dirty) event.preventDefault();
});

function setSaveStatus(text) {
  $("save-status").textContent = text;
}

// ---------------------------------------------------------------------------
// Helpers

function emptyWork() {
  return { source_text: "", paste_text: "", proposed_nodes: [], each_new_node: { properties: {}, relationships: [] }, selected_key: null };
}

/** Fills in anything missing from saved work (none saved yet, or an older shape). */
function normalizeWork(state) {
  const w = { ...emptyWork(), ...(state ?? {}) };
  w.source_text = String(w.source_text ?? "");
  w.paste_text = String(w.paste_text ?? "");
  w.each_new_node = {
    properties: { ...(w.each_new_node?.properties ?? {}) },
    relationships: (w.each_new_node?.relationships ?? []).map(copyRelationship),
  };
  w.proposed_nodes = (w.proposed_nodes ?? []).map((n) => ({
    key: n.key ?? crypto.randomUUID(),
    title: String(n.title ?? ""),
    content: String(n.content ?? ""),
    properties: { ...(n.properties ?? {}) },
    relationships: (n.relationships ?? []).map(copyRelationship),
  }));
  if (!w.proposed_nodes.some((n) => n.key === w.selected_key)) w.selected_key = null;
  return w;
}

/**
 * Removes relationships whose node or relationship type no longer exists, and
 * property values whose definition doesn't. Returns what was removed, as
 * phrases (e.g. "2 relationships"), for a message.
 */
function dropMissing(w, definitions) {
  const nodeIds = new Set(nodes.map((n) => n.id));
  const typeIds = new Set(types.map((t) => t.id));
  const definitionIds = new Set(definitions.map((d) => d.id));
  let relationships = 0;
  let properties = 0;
  const keepProperties = (values) => {
    const kept = {};
    for (const [id, value] of Object.entries(values)) {
      if (definitionIds.has(id)) kept[id] = value;
      else properties++;
    }
    return kept;
  };
  const keepRelationships = (list) =>
    list
      .filter((r) => {
        const ok = nodeIds.has(r.node_id) && typeIds.has(r.relationship_type_id);
        if (!ok) relationships++;
        return ok;
      })
      .map((r) => ({ ...r, properties: keepProperties(r.properties) }));
  for (const holder of [w.each_new_node, ...w.proposed_nodes]) {
    holder.properties = keepProperties(holder.properties);
    holder.relationships = keepRelationships(holder.relationships);
  }
  return [plural(relationships, "relationship", "relationships"), plural(properties, "property value", "property values")].filter(Boolean);
}

function copyRelationship(r) {
  return {
    node_id: r.node_id,
    direction: r.direction === "in" ? "in" : "out",
    relationship_type_id: r.relationship_type_id || RELATED_TO_ID,
    properties: { ...(r.properties ?? {}) },
  };
}

let noticeTimer = 0;

/** Shows a passing message for a few seconds. */
function showNotice(text) {
  const notice = $("notice");
  notice.textContent = text;
  notice.hidden = false;
  clearTimeout(noticeTimer);
  noticeTimer = setTimeout(() => (notice.hidden = true), 6000);
}

/** "1 node", "3 nodes", or "" for none. */
function plural(count, singular, pluralForm) {
  if (!count) return "";
  return `${count} ${count === 1 ? singular : pluralForm}`;
}

function el(tag, props = {}, children = []) {
  const node = Object.assign(document.createElement(tag), props);
  node.append(...children);
  return node;
}
