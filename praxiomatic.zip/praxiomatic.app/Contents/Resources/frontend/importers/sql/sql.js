// SQL importer page: paste (or load) the SQL that defines a database, check
// what importing it would create, update, and mark dropped, pair renamed
// objects, and import it. Importing the same database again updates its nodes
// in place. Nothing is saved until Import, and nothing is kept between visits.

import { api } from "../../shared/api.js";
import { showError, clearError } from "../../shared/ui.js";
import { createGraphPreview } from "../graph-preview.js";

const $ = (id) => document.getElementById(id);
const databaseInput = $("database");
const dialectInput = $("dialect");
const sourceInput = $("source");
const sqlText = $("sql-text");
const checkButton = $("check");
const importButton = $("import");
const fileInput = $("file");
const previewSection = $("preview");
const summary = $("summary");

// The order sql_types are listed in.
const TYPE_ORDER = ["database", "table", "column", "view", "index", "trigger"];

const graph = createGraphPreview();
$("graph").append(graph.element);

// Renames the user paired: node id -> the import_id it takes, with titles for
// the list.
let renames = new Map(); // nodeId -> {importId, from, to}
// The request last checked without errors, and the inputs it came from;
// Import sends it only while they're unchanged.
let checked = null; // {key, request}

checkButton.addEventListener("click", check);

importButton.addEventListener("click", async () => {
  if (!checked || checked.key !== inputKey()) return;
  const page = document.querySelector("main");
  page.inert = true;
  try {
    const result = await api("POST", "/api/importers/sql/commit", checked.request);
    clearError();
    hidePreview();
    sqlText.value = "";
    renames = new Map();
    renderSummary(result);
  } catch (err) {
    showError(`Nothing was imported. ${err.message}`);
  } finally {
    page.inert = false;
  }
});

// Any change means the preview no longer matches what Import would send, and
// the renames may no longer apply.
for (const input of [databaseInput, dialectInput, sourceInput, sqlText]) {
  input.addEventListener("input", () => {
    summary.hidden = true;
    if (input !== sourceInput) renames = new Map();
    if (checked && checked.key !== inputKey()) hidePreview();
  });
}

$("choose-file").addEventListener("click", () => fileInput.click());
fileInput.addEventListener("change", async () => {
  const file = fileInput.files[0];
  fileInput.value = "";
  if (!file) return;
  try {
    sqlText.value = await file.text();
  } catch (err) {
    showError(`Could not read ${file.name}. ${err.message}`);
    return;
  }
  if (!databaseInput.value.trim()) databaseInput.value = file.name.replace(/\.sql$/i, "");
  sqlText.dispatchEvent(new Event("input"));
});

async function check() {
  const request = readRequest();
  if (!request) return;
  checkButton.disabled = true;
  try {
    const result = await api("POST", "/api/importers/sql/check", request);
    clearError();
    checked = { key: inputKey(), request };
    renderPreview(result);
  } catch (err) {
    showError(`Can't import this. ${err.message}`);
    hidePreview();
  } finally {
    checkButton.disabled = false;
  }
}

/** The request for the inputs, or null (with an error shown) if incomplete. */
function readRequest() {
  const database = databaseInput.value.trim();
  if (!database) {
    showError("Give the database a name.");
    databaseInput.focus();
    return null;
  }
  if (!sqlText.value.trim()) {
    showError("Paste the SQL first, or choose a file.");
    return null;
  }
  return {
    dialect: dialectInput.value,
    database,
    sql: sqlText.value,
    source: sourceInput.value.trim(),
    renames: [...renames].map(([nodeId, r]) => ({ node_id: nodeId, import_id: r.importId })),
  };
}

function inputKey() {
  const pairs = [...renames].map(([id, r]) => `${id}=${r.importId}`).join(",");
  return [databaseInput.value, dialectInput.value, sourceInput.value, sqlText.value, pairs].join("\u0000");
}

function renderPreview(result) {
  const db = result.database.existing ? "updates the existing database" : "creates a new database";
  const source = result.source ? (result.source.existing ? ", connected to the existing source" : ", connected to a new source") : "";
  const edges = result.edges;
  const edgeText = [
    edges.create && plural(edges.create, "relationship", "relationships") + " to create",
    edges.update && `${edges.update} to update`,
    edges.delete && `${edges.delete} to delete`,
  ].filter(Boolean);
  const unchanged = result.unchanged_count ? ` ${plural(result.unchanged_count, "object is", "objects are")} unchanged.` : "";
  const still = result.still_dropped_count ? ` ${plural(result.still_dropped_count, "object stays", "objects stay")} marked dropped.` : "";
  $("status").textContent = `Importing ${db}${source}.${unchanged}${still}${edgeText.length ? " " + edgeText.join(", ") + "." : ""}`;
  graph.render(result.preview);

  $("renames-section").hidden = renames.size === 0;
  $("renames-count").textContent = renames.size ? `(${renames.size})` : "";
  $("renames-list").replaceChildren(...[...renames].map(([nodeId, r]) => renderRename(nodeId, r)));

  renderList("create", result.create, (item) => itemLabel(item), "Nothing new.");
  renderList("update", result.update, renderUpdate, "Nothing to update.");
  renderList("dropped", result.dropped, (item) => renderDropped(item, result.create), "Nothing dropped.");
  previewSection.hidden = false;
}

function renderList(name, items, render, empty) {
  $(`${name}-count`).textContent = items.length ? `(${items.length})` : "";
  $(`${name}-list`).replaceChildren(
    ...(items.length
      ? sortByType(items).map((item) => el("li", {}, [render(item)]))
      : [el("li", { className: "empty-state", textContent: empty })]),
  );
}

function sortByType(items) {
  const rank = (t) => (TYPE_ORDER.indexOf(t) + 1 || TYPE_ORDER.length + 1);
  return [...items].sort((a, b) => rank(a.sql_type) - rank(b.sql_type));
}

function itemLabel(item) {
  return el("span", {}, [el("span", { className: "sql-type", textContent: item.sql_type }), ` ${item.title}`]);
}

/** An updated object, expanding to its changes. */
function renderUpdate(item) {
  return el("details", { className: "json-node" }, [
    el("summary", {}, [itemLabel(item), ` · ${plural(item.changes.length, "change", "changes")}`]),
    renderChanges(item.changes),
  ]);
}

function renderChanges(changes) {
  return el("ul", { className: "sql-changes" }, changes.map((c) => el("li", {}, [
    el("span", { className: "sql-change-field", textContent: `${c.field}: ` }),
    c.field === "content" ? "the SQL changed" : `${c.old || "(none)"} → ${c.new || "(none)"}`,
  ])));
}

/**
 * A dropped object, with a choice of the new objects it could be renamed to:
 * the same sql_type, and for a column, in the same table.
 */
function renderDropped(item, created) {
  const paired = new Set([...renames.values()].map((r) => r.importId));
  const candidates = created.filter((c) => c.sql_type === item.sql_type && !paired.has(c.import_id)
    && (item.sql_type !== "column" || (c.parent_node_id && c.parent_node_id === item.parent_node_id)));
  const row = el("div", { className: "sql-dropped" }, [itemLabel(item)]);
  if (!candidates.length) return row;
  const select = el("select", { className: "input" }, [
    el("option", { value: "", textContent: "Dropped" }),
    ...candidates.map((c) => el("option", { value: c.import_id, textContent: `Renamed to ${c.title}` })),
  ]);
  select.setAttribute("aria-label", `What happened to ${item.title}`);
  select.addEventListener("change", () => {
    const target = candidates.find((c) => c.import_id === select.value);
    if (!target) return;
    renames.set(item.node_id, { importId: target.import_id, from: item.title, to: target.title, type: item.sql_type });
    check();
  });
  row.append(select);
  return row;
}

function renderRename(nodeId, r) {
  const remove = el("button", { type: "button", className: "dialog-image-remove", textContent: "×", title: "Not a rename" });
  remove.setAttribute("aria-label", `Unpair ${r.from}`);
  remove.addEventListener("click", () => {
    renames.delete(nodeId);
    check();
  });
  return el("li", { className: "sql-rename" }, [
    el("span", {}, [el("span", { className: "sql-type", textContent: r.type }), ` ${r.from} → ${r.to}`]),
    remove,
  ]);
}

/**
 * What the import did: its counts, then every value it changed (an edit made
 * in Parallax to a SQL node's title, content, or sql_ properties is replaced
 * by the import, so this is where it shows).
 */
function renderSummary(result) {
  const parts = [
    `${result.create.length} created`,
    `${result.update.length} updated`,
    `${result.dropped.length} marked dropped`,
  ];
  $("summary-status").textContent = parts.join(", ") + ".";
  $("summary-list").replaceChildren(
    ...(result.update.length
      ? sortByType(result.update).map((item) => el("li", {}, [itemLabel(item), renderChanges(item.changes)]))
      : [el("li", { className: "empty-state", textContent: "No values were changed." })]),
  );
  summary.hidden = false;
}

function hidePreview() {
  checked = null;
  previewSection.hidden = true;
}

/** "1 table", "3 tables", or "no tables". */
function plural(count, singular, pluralForm) {
  return `${count || "no"} ${count === 1 ? singular : pluralForm}`;
}

function el(tag, props = {}, children = []) {
  const node = Object.assign(document.createElement(tag), props);
  node.append(...children);
  return node;
}
