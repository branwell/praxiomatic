// A small, read-only graph of what an import would create: its new nodes, the
// existing nodes they connect to, its source, and every relationship, drawn as
// boxes joined by labelled arrows. Shared by importers. It's laid out afresh on
// every render (deterministically, by shared/layout.js) and fitted to its box,
// so it has no pan or zoom. Nothing in it is data yet, so nothing is
// selectable: clicking a new node only reports it.

import { placeNewNodes } from "../shared/layout.js";

const SVG_NS = "http://www.w3.org/2000/svg";

// Box geometry, in graph units.
const NODE_HEIGHT = 28;
const NODE_PADDING = 10; // space either side of the title
const MIN_NODE_WIDTH = 40;
const MAX_TITLE_LENGTH = 24; // longer titles are cut with "…" (whole in the tooltip)
const FALLBACK_CHAR_WIDTH = 7.5; // when the text can't be measured
const FAN_SPACING = 26; // how far apart edges between the same two nodes bend
const MARGIN = 20; // around the graph inside the box
const MAX_HEIGHT = 420; // the box's tallest, in pixels

/**
 * A node in the preview.
 * @typedef {object} PreviewNode
 * @property {string} id
 * @property {string} title
 * @property {"new"|"existing"|"source"} kind
 * @property {boolean} [current] Highlighted (e.g. the node shown in an editor).
 */

/**
 * An edge in the preview, from source to target.
 * @typedef {object} PreviewEdge
 * @property {string} source A node id.
 * @property {string} target A node id.
 * @property {string} label The relationship type's name.
 * @property {boolean} [symmetric] Whether the type is symmetric: drawn with
 *   no arrowhead.
 */

/**
 * Creates a graph preview.
 * @param {object} [options]
 * @param {(id: string) => void} [options.onNodeClick] Called with a new node's id when it's clicked.
 * @returns {{element: SVGSVGElement, render: (graph: {nodes: PreviewNode[], edges: PreviewEdge[]}) => void}}
 */
export function createGraphPreview({ onNodeClick = () => {} } = {}) {
  const element = svgEl("svg", { class: "graph-preview", role: "img", "aria-label": "Preview of what will be imported" });
  const marker = svgEl("marker", {
    id: "graph-preview-arrow",
    viewBox: "0 0 10 10",
    refX: 10,
    refY: 5,
    markerUnits: "userSpaceOnUse",
    markerWidth: 9,
    markerHeight: 9,
    orient: "auto",
  });
  marker.append(svgEl("path", { class: "graph-preview-arrowhead", d: "M0,0 L10,5 L0,10 z" }));
  const defs = svgEl("defs");
  defs.append(marker);
  const edgesEl = svgEl("g");
  const nodesEl = svgEl("g");
  element.append(defs, edgesEl, nodesEl);

  /**
   * Draws the graph, replacing what was there. The element must be shown (not
   * display: none) so titles can be measured.
   */
  function render({ nodes, edges }) {
    const placed = nodes.map((n) => ({ ...n, x: null, y: null, width: MIN_NODE_WIDTH }));
    const byId = new Map(placed.map((n) => [n.id, n]));
    const shown = edges.filter((e) => byId.has(e.source) && byId.has(e.target));
    placeNewNodes(placed, shown.map((e) => ({ source_node_id: e.source, target_node_id: e.target })));

    nodesEl.replaceChildren(...placed.map(drawNode));
    edgesEl.replaceChildren(...shown.map((e) => drawEdge(e, byId, shown)));
    fit(placed);
  }

  function drawNode(node) {
    const el = svgEl("g", { class: `graph-preview-node is-${node.kind}` });
    el.classList.toggle("is-current", Boolean(node.current));
    const tooltip = svgEl("title");
    tooltip.textContent = node.title;
    const box = svgEl("rect", { class: "graph-preview-box", rx: 3 });
    const label = svgEl("text", { class: "graph-preview-label", x: node.x, y: node.y });
    label.textContent = cut(node.title);
    el.append(tooltip, box, label);
    nodesEl.append(el); // attached now so the title can be measured
    const textWidth = label.getComputedTextLength() || label.textContent.length * FALLBACK_CHAR_WIDTH;
    node.width = Math.max(MIN_NODE_WIDTH, textWidth + 2 * NODE_PADDING);
    box.setAttribute("x", node.x - node.width / 2);
    box.setAttribute("y", node.y - NODE_HEIGHT / 2);
    box.setAttribute("width", node.width);
    box.setAttribute("height", NODE_HEIGHT);
    if (node.kind === "new") el.addEventListener("click", () => onNodeClick(node.id));
    return el;
  }

  // One edge between two nodes is straight; several fan out as curves, as in
  // the Graph perspective. The label sits at the middle of the line or curve.
  function drawEdge(edge, byId, all) {
    const source = byId.get(edge.source);
    const target = byId.get(edge.target);
    const pair = all.filter(
      (e) => (e.source === edge.source && e.target === edge.target) || (e.source === edge.target && e.target === edge.source),
    );
    const offset = (pair.indexOf(edge) - (pair.length - 1) / 2) * FAN_SPACING;
    const [a, b] = edge.source < edge.target ? [source, target] : [target, source];
    const length = Math.hypot(b.x - a.x, b.y - a.y) || 1;
    const normal = { x: -(b.y - a.y) / length, y: (b.x - a.x) / length };
    const control = {
      x: (source.x + target.x) / 2 + normal.x * offset * 2,
      y: (source.y + target.y) / 2 + normal.y * offset * 2,
    };
    const start = boxEdgePoint(source, control);
    const end = boxEdgePoint(target, control);
    const d = offset === 0
      ? `M${start.x} ${start.y} L${end.x} ${end.y}`
      : `M${start.x} ${start.y} Q${control.x} ${control.y} ${end.x} ${end.y}`;
    // A quadratic curve's middle is a quarter of each end plus half the control.
    const middle = offset === 0
      ? { x: (start.x + end.x) / 2, y: (start.y + end.y) / 2 }
      : { x: (start.x + end.x) / 4 + control.x / 2, y: (start.y + end.y) / 4 + control.y / 2 };

    const el = svgEl("g", { class: "graph-preview-edge" });
    el.classList.toggle("is-symmetric", Boolean(edge.symmetric));
    const tooltip = svgEl("title");
    const link = edge.symmetric ? "—" : "→";
    tooltip.textContent = `${source.title} ${link} ${edge.label} ${link} ${target.title}`;
    const line = svgEl("path", { class: "graph-preview-line", d });
    const label = svgEl("text", { class: "graph-preview-edge-label", x: middle.x, y: middle.y });
    label.textContent = edge.label;
    el.append(tooltip, line, label);
    return el;
  }

  // Fits the whole graph into the box, keeping its proportions. The box is as
  // tall as the graph (up to MAX_HEIGHT), so it's never drawn larger than life.
  function fit(nodes) {
    if (!nodes.length) return;
    const left = Math.min(...nodes.map((n) => n.x - n.width / 2)) - MARGIN;
    const right = Math.max(...nodes.map((n) => n.x + n.width / 2)) + MARGIN;
    const top = Math.min(...nodes.map((n) => n.y - NODE_HEIGHT / 2)) - MARGIN;
    const bottom = Math.max(...nodes.map((n) => n.y + NODE_HEIGHT / 2)) + MARGIN;
    element.setAttribute("viewBox", `${left} ${top} ${right - left} ${bottom - top}`);
    element.setAttribute("height", Math.min(bottom - top, MAX_HEIGHT));
  }

  return { element, render };
}

function cut(title) {
  const text = title.trim() || "(no title)";
  return text.length > MAX_TITLE_LENGTH ? `${text.slice(0, MAX_TITLE_LENGTH - 1)}…` : text;
}

// Where the line from node's centre towards other's centre leaves node's box.
function boxEdgePoint(node, other) {
  const dx = other.x - node.x;
  const dy = other.y - node.y;
  if (dx === 0 && dy === 0) return { x: node.x, y: node.y };
  const scale = Math.min(node.width / 2 / Math.abs(dx), NODE_HEIGHT / 2 / Math.abs(dy));
  return { x: node.x + dx * scale, y: node.y + dy * scale };
}

function svgEl(tag, attrs = {}) {
  const el = document.createElementNS(SVG_NS, tag);
  for (const [name, value] of Object.entries(attrs)) el.setAttribute(name, value);
  return el;
}
