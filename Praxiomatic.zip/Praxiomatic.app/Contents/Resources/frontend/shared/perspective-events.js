// Tells the page that its perspectives changed (one was renamed, deleted, or
// moved), so whatever lists them (the perspectives sidebar, the Perspectives
// page) can reload. Within the page only; other tabs see it when they reload.

const EVENT = "parallax:perspectives-changed";

export function notifyPerspectivesChanged() {
  window.dispatchEvent(new Event(EVENT));
}

/** @param {() => void} handler */
export function onPerspectivesChanged(handler) {
  window.addEventListener(EVENT, handler);
}
