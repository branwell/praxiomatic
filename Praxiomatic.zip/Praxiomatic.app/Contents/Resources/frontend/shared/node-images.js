// Images attached to nodes, shared by the core node dialog and node panel: which
// pasted files can be attached, and how an attached image is shown.

// The images that can be attached (spec: Assets), and their size limit.
const IMAGE_TYPES = new Set(["image/png", "image/jpeg", "image/gif", "image/webp"]);
const MAX_IMAGE_BYTES = 20 * 1024 * 1024;

/**
 * The image files in a paste, sorted into those that can be attached and
 * messages for those that can't.
 * @param {ClipboardEvent} event
 * @returns {{files: File[], refused: string[]}} Both empty if the paste has no images.
 */
export function pastedImages(event) {
  const files = [];
  const refused = [];
  for (const file of event.clipboardData?.files ?? []) {
    if (!file.type.startsWith("image/")) continue;
    if (!IMAGE_TYPES.has(file.type)) refused.push(`${file.name} isn't a PNG, JPEG, GIF, or WebP image.`);
    else if (file.size > MAX_IMAGE_BYTES) refused.push(`${file.name} is over 20 MB.`);
    else files.push(file);
  }
  return { files, refused };
}

/**
 * An asset's image, which opens full size in the image viewer when clicked.
 * The viewer is part of the page, not a new tab or window, so it works the
 * same in a browser and in a window with no tabs or back button.
 */
export function imageLink(assetId, title) {
  const src = `/api/assets/${encodeURIComponent(assetId)}`;
  const img = Object.assign(document.createElement("img"), { src, alt: title });
  const open = Object.assign(document.createElement("button"), { type: "button", className: "image-open" });
  open.title = "View full size";
  open.append(img);
  open.addEventListener("click", () => showImage(src, title));
  return open;
}

// Shows an image over the page, as large as fits the window (never enlarged).
// A click anywhere, the ×, or Escape closes it. It's a modal dialog, so it
// shows above an open dialog too, and blocks shortcuts while open.
function showImage(src, title) {
  const viewer = Object.assign(document.createElement("dialog"), { className: "image-viewer" });
  viewer.setAttribute("aria-label", title);
  const img = Object.assign(document.createElement("img"), { src, alt: title });
  const close = Object.assign(document.createElement("button"), {
    type: "button", className: "image-viewer-close", textContent: "×", title: "Close (Escape)",
  });
  close.setAttribute("aria-label", "Close");
  viewer.append(img, close);
  viewer.addEventListener("click", () => viewer.close());
  viewer.addEventListener("close", () => viewer.remove());
  document.body.append(viewer);
  viewer.showModal();
  close.focus();
}
