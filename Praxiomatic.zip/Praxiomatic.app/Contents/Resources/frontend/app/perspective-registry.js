// Every perspective of every kind, in the user's order from the registry
// (/api/perspectives), and moving one in that order. Shared by the
// Perspectives page and the perspectives sidebar, so both list them the same.

import { api } from "../shared/api.js";
import { notifyPerspectivesChanged } from "../shared/perspective-events.js";
import { perspectiveLists } from "./perspectives.js";

/**
 * A perspective and its kind.
 * @typedef {object} PerspectiveEntry
 * @property {import("./perspectives.js").PerspectiveList} provider Its kind.
 * @property {{id: string, title: string, url: string}} item
 */

/**
 * Loads every kind's perspectives, in the registry's order; any it doesn't
 * list go last, by title. Each kind loads on its own, so one that fails still
 * leaves the others listed.
 * @returns {Promise<{entries: PerspectiveEntry[], failed: string[]}>} failed
 *   says what couldn't be loaded, one message per kind (or the order).
 */
export async function loadPerspectives() {
  const [orderResult, ...results] = await Promise.allSettled([
    api("GET", "/api/perspectives"),
    ...perspectiveLists.map((provider) => provider.list()),
  ]);
  const entries = [];
  const failed = [];
  results.forEach((result, i) => {
    const provider = perspectiveLists[i];
    if (result.status === "fulfilled") {
      for (const item of result.value) entries.push({ provider, item });
    } else {
      failed.push(`${provider.kind}: ${result.reason.message}`);
    }
  });
  if (orderResult.status === "rejected") failed.push(`Order: ${orderResult.reason.message}`);
  const position = new Map((orderResult.value ?? []).map((p, i) => [p.id, i]));
  const at = (entry) => position.get(entry.item.id) ?? Infinity;
  entries.sort((a, b) => at(a) - at(b) || a.item.title.localeCompare(b.item.title));
  return { entries, failed };
}

/**
 * Moves a perspective to just before another (last, if beforeId is null) and
 * tells the page. Throws if it can't be saved.
 * @param {string} id
 * @param {string | null} beforeId
 */
export async function movePerspective(id, beforeId) {
  await api("POST", `/api/perspectives/${encodeURIComponent(id)}/move`, { before_id: beforeId });
  notifyPerspectivesChanged();
}
