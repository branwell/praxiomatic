// The perspectives sidebar (spec: UI): a column at the left of every page,
// below the site header, linking to every perspective so one click switches
// between them. It lists them in the user's order, all together or grouped by
// kind, and marks the one shown. In the All view a link is dragged to reorder,
// as tiles are on the Perspectives page. It can be collapsed to a narrow strip;
// whether it is, and its grouping, are remembered in this browser.
//
// Each page has an empty <nav id="pv-sidebar" class="pv-sidebar"> after its
// site header, so the page is laid out with the sidebar before this runs.

import { icon } from "../shared/icons.js";
import { onPerspectivesChanged } from "../shared/perspective-events.js";
import { loadPerspectives, movePerspective } from "./perspective-registry.js";

const STORAGE_KEY = "parallax.perspectiveSidebar";
const GROUPINGS = [
  { value: "all", label: "All" },
  { value: "kind", label: "By kind" },
];

const sidebar = document.getElementById("pv-sidebar");

// A per-browser preference: if storage is unavailable, the defaults apply.
function readPrefs() {
  const prefs = { collapsed: false, grouping: "all" };
  try {
    const saved = JSON.parse(localStorage.getItem(STORAGE_KEY)) ?? {};
    if (typeof saved.collapsed === "boolean") prefs.collapsed = saved.collapsed;
    if (GROUPINGS.some((g) => g.value === saved.grouping)) prefs.grouping = saved.grouping;
  } catch {
    // Use the defaults.
  }
  return prefs;
}

function savePrefs() {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(prefs));
  } catch {
    // Not remembered; the sidebar still works.
  }
}

const prefs = readPrefs();
let entries = [];

// ---------------------------------------------------------------------------
// Frame: the grouping toggle and the collapse button above the links.
// ---------------------------------------------------------------------------

const groupingEl = document.createElement("div");
groupingEl.className = "pv-sidebar-grouping";
groupingEl.setAttribute("role", "group");
groupingEl.setAttribute("aria-label", "Group perspectives");
const groupingButtons = GROUPINGS.map(({ value, label }) => {
  const button = Object.assign(document.createElement("button"), { type: "button", textContent: label });
  button.dataset.grouping = value;
  button.addEventListener("click", () => {
    if (prefs.grouping === value) return;
    prefs.grouping = value;
    savePrefs();
    render();
  });
  return button;
});
groupingEl.append(...groupingButtons);

const toggle = Object.assign(document.createElement("button"), { type: "button", className: "pv-sidebar-toggle" });
toggle.setAttribute("aria-controls", "pv-sidebar-body");
toggle.addEventListener("click", () => {
  prefs.collapsed = !prefs.collapsed;
  savePrefs();
  renderCollapsed();
});

const bar = document.createElement("div");
bar.className = "pv-sidebar-bar";
bar.append(groupingEl, toggle);

const errorEl = Object.assign(document.createElement("p"), { className: "pv-sidebar-error", hidden: true });
errorEl.setAttribute("role", "alert");

const body = Object.assign(document.createElement("div"), { className: "pv-sidebar-body", id: "pv-sidebar-body" });

const inner = document.createElement("div");
inner.className = "pv-sidebar-inner";
inner.append(bar, errorEl, body);

function renderCollapsed() {
  sidebar.classList.toggle("is-collapsed", prefs.collapsed);
  toggle.setAttribute("aria-expanded", String(!prefs.collapsed));
  const label = prefs.collapsed ? "Show perspectives" : "Hide perspectives";
  toggle.setAttribute("aria-label", label);
  toggle.title = label;
  // A chevron pointing the way the sidebar will move.
  toggle.replaceChildren(icon("pv-sidebar-toggle-icon", [
    ["path", { d: prefs.collapsed ? "M9 6l6 6-6 6" : "M15 6l-6 6 6 6" }],
  ]));
}

function showSidebarError(message) {
  errorEl.textContent = message;
  errorEl.hidden = !message;
}

// ---------------------------------------------------------------------------
// Links
// ---------------------------------------------------------------------------

// Whether a perspective's URL is this page (/graph/ and /graph/index.html are
// the same page).
function isCurrent(url) {
  const target = new URL(url, window.location.href);
  const path = (pathname) => pathname.replace(/index\.html$/, "");
  return path(target.pathname) === path(window.location.pathname) && target.search === window.location.search;
}

function renderLink({ provider, item }, draggable) {
  const li = document.createElement("li");
  li.dataset.id = item.id;
  const link = Object.assign(document.createElement("a"), { className: "pv-sidebar-link", href: item.url, draggable });
  link.title = `${item.title} (${provider.kind})`;
  if (isCurrent(item.url)) link.setAttribute("aria-current", "page");
  const title = Object.assign(document.createElement("span"), { className: "pv-sidebar-title", textContent: item.title });
  link.append(provider.icon("pv-sidebar-icon"), title);
  li.append(link);
  return li;
}

function renderList(list, draggable) {
  const ol = document.createElement("ol");
  ol.className = "pv-sidebar-links";
  ol.append(...list.map((entry) => renderLink(entry, draggable)));
  return ol;
}

// By kind: a heading per kind, in the order the kinds first appear in the
// user's order, and the user's order within each.
function renderGroups() {
  const groups = new Map();
  for (const entry of entries) {
    if (!groups.has(entry.provider)) groups.set(entry.provider, []);
    groups.get(entry.provider).push(entry);
  }
  return [...groups].map(([provider, list]) => {
    const section = document.createElement("section");
    section.className = "pv-sidebar-group";
    const heading = Object.assign(document.createElement("h2"), { className: "pv-sidebar-heading", textContent: provider.kind });
    section.append(heading, renderList(list, false));
    return section;
  });
}

function render() {
  for (const button of groupingButtons) {
    button.setAttribute("aria-pressed", String(button.dataset.grouping === prefs.grouping));
  }
  resetDrag();
  if (prefs.grouping === "kind") body.replaceChildren(...renderGroups());
  else body.replaceChildren(renderList(entries, true));
}

async function load() {
  const result = await loadPerspectives();
  entries = result.entries;
  showSidebarError(result.failed.length > 0 ? "Could not load some perspectives." : "");
  render();
}

// ---------------------------------------------------------------------------
// Reordering by drag and drop, in the All view only. A dashed placeholder
// shows where the link will land; dropping saves it there, and it goes back if
// saving fails. Dropping outside the list, or Escape, leaves it where it was.
// ---------------------------------------------------------------------------

const placeholder = document.createElement("li");
placeholder.className = "pv-sidebar-placeholder";
placeholder.setAttribute("aria-hidden", "true");
let dragged = null;
let origin = null;

// The first link whose middle is below the pointer.
function itemAfter(list, y) {
  return [...list.children].find((li) => {
    if (li === dragged || li === placeholder) return false;
    const box = li.getBoundingClientRect();
    return y < box.top + box.height / 2;
  }) ?? null;
}

body.addEventListener("dragstart", (event) => {
  const li = event.target.closest?.(".pv-sidebar-links li");
  if (!li || prefs.grouping !== "all") return;
  dragged = li;
  origin = li.nextElementSibling;
  event.dataTransfer.effectAllowed = "move";
  event.dataTransfer.setData("text/plain", li.textContent);
  // Change the page after the browser has captured the drag image.
  requestAnimationFrame(() => {
    if (dragged !== li) return;
    li.classList.add("dragging");
    if (!placeholder.isConnected) li.parentElement.insertBefore(placeholder, origin);
  });
});

body.addEventListener("dragover", (event) => {
  if (!dragged) return;
  event.preventDefault();
  event.dataTransfer.dropEffect = "move";
  const list = dragged.parentElement;
  const before = itemAfter(list, event.clientY);
  if (placeholder.nextElementSibling !== before || !placeholder.isConnected) list.insertBefore(placeholder, before);
});

body.addEventListener("drop", async (event) => {
  if (!dragged) return;
  event.preventDefault();
  const li = dragged;
  const from = origin;
  const list = li.parentElement;
  placeholder.replaceWith(li);
  resetDrag();
  if (li.nextElementSibling === from) return;

  showSidebarError("");
  try {
    // Saving tells the page, which reloads the sidebar (and the Perspectives
    // page's tiles) in the new order.
    await movePerspective(li.dataset.id, li.nextElementSibling?.dataset.id ?? null);
  } catch (error) {
    list.insertBefore(li, from);
    showSidebarError(`Could not move the perspective. ${error.message}`);
  }
});

// Fires after a drop, or when a drag is cancelled (e.g. dropped outside).
body.addEventListener("dragend", resetDrag);

function resetDrag() {
  placeholder.remove();
  dragged?.classList.remove("dragging");
  dragged = null;
  origin = null;
}

if (sidebar) {
  sidebar.append(inner);
  renderCollapsed();
  render();
  onPerspectivesChanged(load);
  load();
}
